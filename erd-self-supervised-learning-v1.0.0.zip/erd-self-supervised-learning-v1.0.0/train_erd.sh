#!/bin/bash
# ERD自监督学习统一训练脚本
# 替代多个独立训练脚本，提供统一接口

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 显示使用说明
show_usage() {
    echo "🧠 ERD自监督学习统一训练脚本"
    echo "============================="
    echo ""
    echo "用法: $0 [配置类型] [选项]"
    echo ""
    echo "配置类型:"
    echo "  conservative      保守配置 (推荐，最稳定)"
    echo "  memory_optimized  内存优化配置"
    echo "  original          原始配置"
    echo "  5table_experiment 5表精准实验配置"
    echo "  complete_schema   完整Schema配置 (新，解决省略字段问题)"
    echo ""
    echo "选项:"
    echo "  --samples N      训练样本数量 (默认: 3000)"
    echo "  --help           显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 conservative                    # 使用保守配置"
    echo "  $0 memory_optimized --samples 5000 # 内存优化，5000样本"
    echo "  $0 original                        # 原始配置"
    echo ""
}

# 解析参数
CONFIG_TYPE=${1:-conservative}
MAX_SAMPLES=3000

# 解析选项
shift
while [[ $# -gt 0 ]]; do
    case $1 in
        --samples)
            MAX_SAMPLES="$2"
            shift 2
            ;;
        --help)
            show_usage
            exit 0
            ;;
        *)
            log_error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
done

echo "🧠 ERD自监督学习统一训练"
echo "========================"

# 检测Python路径
log_step "检测Python环境..."
PYTHON_CMD=""
if [ -f "/root/miniconda/bin/python" ]; then
    PYTHON_CMD="/root/miniconda/bin/python"
elif [ -f "/root/miniconda3/bin/python" ]; then
    PYTHON_CMD="/root/miniconda3/bin/python"
elif [ -f "erd_env/bin/python" ]; then
    PYTHON_CMD="$(pwd)/erd_env/bin/python"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    log_error "未找到Python环境"
    exit 1
fi

log_info "使用Python: $PYTHON_CMD"

# 选择配置文件
log_step "选择训练配置..."
case $CONFIG_TYPE in
    conservative)
        CONFIG_FILE="config/qwen_3b_conservative.yaml"
        log_info "✅ 使用保守配置 (最稳定)"
        log_info "  • 批次大小: 1"
        log_info "  • 梯度累积: 32"
        log_info "  • 序列长度: 512"
        log_info "  • 混合精度: 禁用"
        log_info "  • 梯度检查点: 禁用"
        log_info "  • 早停机制: 3次无改善自动停止 (防过拟合)"
        ;;
    memory_optimized)
        CONFIG_FILE="config/qwen_3b_memory_optimized.yaml"
        log_info "✅ 使用内存优化配置"
        log_info "  • 批次大小: 2"
        log_info "  • 梯度累积: 16"
        log_info "  • 序列长度: 1024"
        log_info "  • 混合精度: fp16"
        log_info "  • 早停机制: 3次无改善自动停止 (防过拟合)"
        ;;
    original)
        CONFIG_FILE="config/qwen_3b_config.yaml"
        log_info "✅ 使用原始配置"
        log_info "  • 早停机制: 3次无改善自动停止 (防过拟合)"
        log_warn "⚠️  可能遇到内存问题，建议使用conservative配置"
        ;;
    5table_experiment)
        CONFIG_FILE="config/qwen_3b_5table_experiment.yaml"
        log_info "✅ 使用5表精准实验配置"
        log_info "  • 实验类型: 5张核心表关系学习"
        log_info "  • 训练样本: 743个高质量样本"
        log_info "  • 批次大小: 2"
        log_info "  • 梯度累积: 8"
        log_info "  • 最大步数: 300"
        log_info "  • 学习率: 3e-4"
        log_info "  • 早停机制: 8次无改善自动停止"
        log_info "  • 目标表: 采购订单、项目、材料相关表"
        ;;
    complete_schema)
        CONFIG_FILE="config/qwen_3b_complete_schema.yaml"
        log_info "✅ 使用完整Schema配置"
        log_info "  • 实验类型: 完整字段信息训练"
        log_info "  • 训练样本: 520个完整Schema样本"
        log_info "  • 批次大小: 1"
        log_info "  • 梯度累积: 16"
        log_info "  • 最大步数: 260"
        log_info "  • 学习率: 2e-4"
        log_info "  • LoRA rank: 16 (增强)"
        log_info "  • 解决问题: 不再输出省略字段表示"
        log_info "  • 输入长度: 约1500字符 (完整Schema)"
        ;;
    *)
        log_error "未知配置类型: $CONFIG_TYPE"
        show_usage
        exit 1
        ;;
esac

# 检查配置文件
if [ ! -f "$CONFIG_FILE" ]; then
    log_error "配置文件不存在: $CONFIG_FILE"
    exit 1
fi

# 检查数据文件
if [ "$CONFIG_TYPE" = "5table_experiment" ]; then
    # 检查5表训练数据
    if [ ! -f "data/5table_training_data_fixed.json" ]; then
        log_error "5表训练数据文件不存在: data/5table_training_data_fixed.json"
        exit 1
    fi
    log_info "✅ 5表训练数据文件检查通过"
elif [ "$CONFIG_TYPE" = "complete_schema" ]; then
    # 检查完整Schema训练数据
    if [ ! -f "data/5table_training_data_complete_schema_fixed.json" ]; then
        log_error "完整Schema训练数据文件不存在: data/5table_training_data_complete_schema_fixed.json"
        exit 1
    fi
    log_info "✅ 完整Schema训练数据文件检查通过"
else
    # 检查ERD数据文件
    if [ ! -f "data/erd/cost_erd.json" ]; then
        log_error "ERD数据文件不存在: data/erd/cost_erd.json"
        exit 1
    fi
    log_info "✅ ERD数据文件检查通过"
fi

# 设置训练环境变量
log_step "设置训练环境..."

# 完全禁用wandb
export WANDB_DISABLED=true
export WANDB_MODE=disabled
export WANDB_SILENT=true

# SwanLab配置
export SWANLAB_LOG_LEVEL=INFO
export SWANLAB_OFFLINE=false

# CUDA内存优化
export PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True,max_split_size_mb:256"
export CUDA_LAUNCH_BLOCKING=0
export TOKENIZERS_PARALLELISM=false

# 禁用一些可能导致问题的优化
export TORCH_USE_CUDA_DSA=0
export TORCH_ALLOW_TF32_CUBLAS_OVERRIDE=0

log_info "✅ 环境变量设置完成"

# 清理GPU内存
log_step "清理GPU内存..."
if command -v nvidia-smi &> /dev/null; then
    log_info "当前GPU状态:"
    nvidia-smi --query-gpu=memory.used,memory.free,memory.total --format=csv,noheader,nounits
fi

$PYTHON_CMD -c "
import torch
if torch.cuda.is_available():
    torch.cuda.empty_cache()
    print('✅ GPU缓存已清理')
else:
    print('⚠️  CUDA不可用')
" 2>/dev/null || log_warn "GPU内存清理失败"

# 安装SwanLab（如果需要）
log_step "检查SwanLab依赖..."
if ! $PYTHON_CMD -c "import swanlab" 2>/dev/null; then
    log_info "安装SwanLab..."
    $PYTHON_CMD -m pip install swanlab>=0.3.0 -i https://mirrors.aliyun.com/pypi/simple/
fi

# 启动训练
log_step "启动ERD自监督学习训练..."
log_info "配置: $CONFIG_FILE"
log_info "样本数: $MAX_SAMPLES"

$PYTHON_CMD examples/train_model.py \
    --erd_file data/erd/cost_erd.json \
    --max_samples $MAX_SAMPLES \
    --config $CONFIG_FILE \
    --output_dir data/generated

echo ""
log_info "✅ 训练启动完成"
log_info "📊 训练进度信息将定期显示，包括:"
log_info "  • 当前步数和完成百分比"
log_info "  • 已用时间和平均步时间"
log_info "  • 预估剩余时间和完成时间"
log_info "  • 当前损失值"
log_info "🔗 可以通过SwanLab面板监控详细训练指标"
echo ""
log_info "🚀 训练完成后可以运行验证:"
log_info "  ./verify_erd_model.sh --lora-path data/models/erd_conservative"
