#!/bin/bash
# ERD项目模型缓存管理脚本
# 作者：Claude 4.0 sonnet
# 功能：管理Qwen2.5-3B模型缓存，避免重复下载

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 配置
MODEL_NAME="Qwen/Qwen2.5-3B-Instruct"
MODELSCOPE_NAME="qwen/Qwen2.5-3B-Instruct"
CACHE_BASE_DIR="/root/lanyun-tmp/modelscope_cache"
CACHE_MODEL_DIR="$CACHE_BASE_DIR/models--Qwen--Qwen2.5-3B-Instruct"

# 检查模型缓存状态
check_cache_status() {
    log_step "检查模型缓存状态..."
    
    if [ ! -d "$CACHE_BASE_DIR" ]; then
        log_warn "缓存基础目录不存在: $CACHE_BASE_DIR"
        return 1
    fi
    
    if [ ! -d "$CACHE_MODEL_DIR" ]; then
        log_warn "模型缓存目录不存在: $CACHE_MODEL_DIR"
        return 1
    fi
    
    # 检查必要的模型文件
    local required_files=(
        "config.json"
        "generation_config.json"
        "model.safetensors.index.json"
        "tokenizer.json"
        "tokenizer_config.json"
        "vocab.json"
        "merges.txt"
    )
    
    local missing_files=()
    for file in "${required_files[@]}"; do
        if [ ! -f "$CACHE_MODEL_DIR/$file" ]; then
            missing_files+=("$file")
        fi
    done
    
    if [ ${#missing_files[@]} -eq 0 ]; then
        log_info "✅ 模型缓存完整"
        
        # 显示缓存信息
        local cache_size=$(du -sh "$CACHE_MODEL_DIR" 2>/dev/null | cut -f1)
        local file_count=$(find "$CACHE_MODEL_DIR" -type f | wc -l)
        
        echo ""
        echo "📊 缓存信息:"
        echo "  • 路径: $CACHE_MODEL_DIR"
        echo "  • 大小: $cache_size"
        echo "  • 文件数: $file_count"
        echo ""
        
        return 0
    else
        log_warn "❌ 模型缓存不完整，缺少文件:"
        for file in "${missing_files[@]}"; do
            echo "    - $file"
        done
        return 1
    fi
}

# 创建缓存目录
create_cache_dir() {
    log_step "创建缓存目录..."
    
    if [ ! -d "$CACHE_BASE_DIR" ]; then
        mkdir -p "$CACHE_BASE_DIR"
        log_info "✅ 创建缓存基础目录: $CACHE_BASE_DIR"
    fi
    
    if [ ! -d "$CACHE_MODEL_DIR" ]; then
        mkdir -p "$CACHE_MODEL_DIR"
        log_info "✅ 创建模型缓存目录: $CACHE_MODEL_DIR"
    fi
}

# 下载模型到缓存
download_model() {
    log_step "下载模型到缓存..."
    
    # 检查Python环境
    local python_cmd=""
    if [ -f "/root/miniconda/bin/python" ]; then
        python_cmd="/root/miniconda/bin/python"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        python_cmd="/root/miniconda3/bin/python"
    elif command -v python3 &> /dev/null; then
        python_cmd="python3"
    else
        log_error "未找到Python环境"
        return 1
    fi
    
    log_info "使用Python: $python_cmd"
    
    # 检查ModelScope是否安装
    if ! $python_cmd -c "import modelscope" 2>/dev/null; then
        log_warn "ModelScope未安装，正在安装..."
        $python_cmd -m pip install modelscope -i https://mirrors.aliyun.com/pypi/simple/
    fi
    
    # 下载模型
    log_info "开始下载模型: $MODELSCOPE_NAME"
    log_info "缓存目录: $CACHE_BASE_DIR"
    
    $python_cmd -c "
from modelscope import snapshot_download
import os

cache_dir = '$CACHE_BASE_DIR'
model_name = '$MODELSCOPE_NAME'

print(f'下载模型: {model_name}')
print(f'缓存目录: {cache_dir}')

try:
    model_dir = snapshot_download(model_name, cache_dir=cache_dir)
    print(f'✅ 模型下载成功: {model_dir}')
except Exception as e:
    print(f'❌ 模型下载失败: {e}')
    exit(1)
"
    
    if [ $? -eq 0 ]; then
        log_info "✅ 模型下载完成"
        return 0
    else
        log_error "❌ 模型下载失败"
        return 1
    fi
}

# 清理缓存
clean_cache() {
    log_step "清理模型缓存..."
    
    if [ -d "$CACHE_MODEL_DIR" ]; then
        local cache_size=$(du -sh "$CACHE_MODEL_DIR" 2>/dev/null | cut -f1)
        log_warn "即将删除缓存目录: $CACHE_MODEL_DIR (大小: $cache_size)"
        
        read -p "确认删除? (y/N): " -n 1 -r
        echo
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$CACHE_MODEL_DIR"
            log_info "✅ 缓存已清理"
        else
            log_info "取消清理操作"
        fi
    else
        log_info "缓存目录不存在，无需清理"
    fi
}

# 显示使用说明
show_usage() {
    echo "ERD项目模型缓存管理脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --check       检查缓存状态"
    echo "  --download    下载模型到缓存"
    echo "  --clean       清理缓存"
    echo "  --setup       设置缓存（创建目录并下载）"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 --check                    # 检查缓存状态"
    echo "  $0 --setup                    # 完整设置缓存"
    echo "  $0 --download                 # 仅下载模型"
    echo "  $0 --clean                    # 清理缓存"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --check)
            check_cache_status
            ;;
        --download)
            create_cache_dir
            download_model
            ;;
        --clean)
            clean_cache
            ;;
        --setup)
            log_info "🚀 设置模型缓存..."
            create_cache_dir
            if ! check_cache_status; then
                download_model
                check_cache_status
            fi
            ;;
        --help|"")
            show_usage
            ;;
        *)
            log_error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
