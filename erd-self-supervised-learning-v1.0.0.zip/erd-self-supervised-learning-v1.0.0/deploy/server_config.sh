#!/bin/bash

# ERD训练服务器配置文件
# 作者：Claude 4.0 sonnet
# 功能：集中管理服务器连接和配置信息

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# 默认服务器配置（请根据实际情况修改）
export ERD_SERVER_HOST="qhdlink.lanyun.net"
export ERD_SERVER_USER="root"
export ERD_SERVER_PORT="52187"
export ERD_SERVER_PASSWORD="tmdxygt4pcjxf22w"  # 留空使用SSH密钥
export ERD_SERVER_PATH="/root/lanyun-tmp/erd"

# SSH连接配置
export ERD_USE_SSHPASS="no"  # 是否使用密码连接
export ERD_SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=30"

# 训练配置 - RTX 4090优化
export ERD_GPU_TYPE="RTX_4090"
export ERD_CUDA_DEVICE="0"
export ERD_GPU_MEMORY_UTILIZATION="0.85"
export ERD_MAX_BATCH_SIZE="16"

# 模型配置
export ERD_MODEL_NAME="Qwen/Qwen2.5-3B-Instruct"
export ERD_MAX_SAMPLES="8000"
export ERD_MAX_STEPS="1000"
export ERD_LEARNING_RATE="2e-4"

# 环境配置
export ERD_PYTHON_ENV="erd_env"
export ERD_CONDA_ENV=""  # 如果使用conda环境

# pip镜像源配置
export PIP_INDEX_URL="https://mirrors.aliyun.com/pypi/simple/"
export PIP_TRUSTED_HOST="mirrors.aliyun.com"
export PIP_TIMEOUT="120"

# HuggingFace配置
export HF_ENDPOINT="https://hf-mirror.com"
export HF_HUB_CACHE="/root/.cache/huggingface"

# 训练优化配置
export PYTORCH_CUDA_ALLOC_CONF="max_split_size_mb:512"
export CUDA_LAUNCH_BLOCKING="0"
export TOKENIZERS_PARALLELISM="false"

# 日志配置
export ERD_LOG_LEVEL="INFO"
export ERD_LOG_DIR="logs"

# 显示配置信息
show_config() {
    echo -e "${CYAN}📋 ERD训练服务器配置${NC}"
    echo "================================"
    echo ""
    echo "🌐 服务器连接:"
    echo "  • 主机: $ERD_SERVER_HOST"
    echo "  • 用户: $ERD_SERVER_USER"
    echo "  • 端口: $ERD_SERVER_PORT"
    echo "  • 路径: $ERD_SERVER_PATH"
    echo ""
    echo "🖥️  硬件配置:"
    echo "  • GPU类型: $ERD_GPU_TYPE"
    echo "  • CUDA设备: $ERD_CUDA_DEVICE"
    echo "  • 显存利用率: $ERD_GPU_MEMORY_UTILIZATION"
    echo "  • 批次大小: $ERD_MAX_BATCH_SIZE"
    echo ""
    echo "🧠 模型配置:"
    echo "  • 基础模型: $ERD_MODEL_NAME"
    echo "  • 训练样本: $ERD_MAX_SAMPLES"
    echo "  • 最大步数: $ERD_MAX_STEPS"
    echo "  • 学习率: $ERD_LEARNING_RATE"
    echo ""
    echo "🔧 环境配置:"
    echo "  • Python环境: $ERD_PYTHON_ENV"
    echo "  • pip镜像: $PIP_INDEX_URL"
    echo "  • HF镜像: $HF_ENDPOINT"
    echo ""
}

# 测试服务器连接
test_connection() {
    echo -e "${BLUE}🔍 测试服务器连接...${NC}"
    
    if [ "$ERD_USE_SSHPASS" = "yes" ] && [ -n "$ERD_SERVER_PASSWORD" ]; then
        # 使用密码连接
        if command -v sshpass &> /dev/null; then
            if sshpass -p "$ERD_SERVER_PASSWORD" ssh -p "$ERD_SERVER_PORT" \
                $ERD_SSH_OPTS "$ERD_SERVER_USER@$ERD_SERVER_HOST" "echo 'SSH连接测试成功'" 2>/dev/null; then
                echo -e "${GREEN}✅ 服务器连接测试成功${NC}"
                return 0
            else
                echo -e "${RED}❌ 服务器连接测试失败${NC}"
                return 1
            fi
        else
            echo -e "${RED}❌ 需要安装sshpass${NC}"
            return 1
        fi
    else
        # 使用SSH密钥连接
        if ssh -p "$ERD_SERVER_PORT" $ERD_SSH_OPTS \
            "$ERD_SERVER_USER@$ERD_SERVER_HOST" "echo 'SSH连接测试成功'" 2>/dev/null; then
            echo -e "${GREEN}✅ 服务器连接测试成功${NC}"
            return 0
        else
            echo -e "${RED}❌ 服务器连接测试失败${NC}"
            echo "请检查SSH密钥配置或设置密码连接"
            return 1
        fi
    fi
}

# 检测服务器环境
detect_server_env() {
    echo -e "${BLUE}🔍 检测服务器环境...${NC}"
    
    local ssh_cmd=""
    if [ "$ERD_USE_SSHPASS" = "yes" ] && [ -n "$ERD_SERVER_PASSWORD" ]; then
        ssh_cmd="sshpass -p '$ERD_SERVER_PASSWORD' ssh -p $ERD_SERVER_PORT $ERD_SSH_OPTS $ERD_SERVER_USER@$ERD_SERVER_HOST"
    else
        ssh_cmd="ssh -p $ERD_SERVER_PORT $ERD_SSH_OPTS $ERD_SERVER_USER@$ERD_SERVER_HOST"
    fi
    
    # 检测操作系统
    local os_info=$(eval "$ssh_cmd 'cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d\"\\\"\" -f2 || echo \"Unknown\"'")
    echo "  • 操作系统: $os_info"
    
    # 检测Python版本
    local python_version=$(eval "$ssh_cmd 'python3 --version 2>&1 || echo \"Not installed\"'")
    echo "  • Python版本: $python_version"
    
    # 检测GPU信息
    local gpu_info=$(eval "$ssh_cmd 'nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>/dev/null || echo \"No GPU\"'")
    echo "  • GPU信息: $gpu_info"
    
    # 检测CUDA版本
    local cuda_version=$(eval "$ssh_cmd 'nvcc --version 2>/dev/null | grep \"release\" | grep -o \"V[0-9.]*\" || echo \"Not installed\"'")
    echo "  • CUDA版本: $cuda_version"
    
    # 检测可用空间
    local disk_space=$(eval "$ssh_cmd 'df -h / | tail -1 | awk \"{print \\$4}\"'")
    echo "  • 可用空间: $disk_space"
    
    echo ""
}

# 生成部署命令
generate_deploy_commands() {
    echo -e "${YELLOW}🚀 部署命令${NC}"
    echo "================================"
    echo ""
    echo "1. 上传项目文件:"
    if [ "$ERD_USE_SSHPASS" = "yes" ] && [ -n "$ERD_SERVER_PASSWORD" ]; then
        echo "  sshpass -p '$ERD_SERVER_PASSWORD' scp -P $ERD_SERVER_PORT -r . $ERD_SERVER_USER@$ERD_SERVER_HOST:$ERD_SERVER_PATH/"
    else
        echo "  scp -P $ERD_SERVER_PORT -r . $ERD_SERVER_USER@$ERD_SERVER_HOST:$ERD_SERVER_PATH/"
    fi
    echo ""
    echo "2. 连接服务器:"
    if [ "$ERD_USE_SSHPASS" = "yes" ] && [ -n "$ERD_SERVER_PASSWORD" ]; then
        echo "  sshpass -p '$ERD_SERVER_PASSWORD' ssh -p $ERD_SERVER_PORT $ERD_SERVER_USER@$ERD_SERVER_HOST"
    else
        echo "  ssh -p $ERD_SERVER_PORT $ERD_SERVER_USER@$ERD_SERVER_HOST"
    fi
    echo ""
    echo "3. 部署环境:"
    echo "  cd $ERD_SERVER_PATH"
    echo "  ./deploy/setup_server.sh"
    echo ""
    echo "4. 开始训练:"
    echo "  ./deploy/train_on_server.sh"
    echo ""
    echo "5. 监控训练:"
    echo "  ./deploy/monitor_training.sh"
    echo ""
}

# 显示使用说明
show_usage() {
    echo "ERD训练服务器配置管理"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --show        显示当前配置"
    echo "  --test        测试服务器连接"
    echo "  --detect      检测服务器环境"
    echo "  --commands    生成部署命令"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "配置文件位置: $0"
    echo "请编辑此文件修改服务器配置"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --show)
            show_config
            ;;
        --test)
            test_connection
            ;;
        --detect)
            if test_connection; then
                detect_server_env
            fi
            ;;
        --commands)
            generate_deploy_commands
            ;;
        --help|"")
            show_usage
            ;;
        *)
            echo -e "${RED}未知选项: $1${NC}"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

echo "📝 已加载ERD训练服务器配置"
