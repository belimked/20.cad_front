#!/bin/bash

# ERD自监督学习训练监控脚本
# 作者：Claude 4.0 sonnet
# 功能：实时监控训练状态、GPU使用、日志等

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# 获取当前时间
get_timestamp() {
    date '+%Y-%m-%d %H:%M:%S'
}

# 检查训练进程状态
check_training_process() {
    echo -e "${BLUE}🔍 训练进程状态${NC}"
    echo "================================"

    if [ -f "$PROJECT_DIR/logs/train.pid" ]; then
        local train_pid=$(cat "$PROJECT_DIR/logs/train.pid")
        if ps -p $train_pid > /dev/null 2>&1; then
            local start_time=$(ps -o lstart= -p $train_pid 2>/dev/null | xargs)
            local cpu_usage=$(ps -o %cpu= -p $train_pid 2>/dev/null | xargs)
            local mem_usage=$(ps -o %mem= -p $train_pid 2>/dev/null | xargs)
            local runtime=$(ps -o etime= -p $train_pid 2>/dev/null | xargs)

            echo -e "  ${GREEN}✅ 训练进程运行中${NC}"
            echo "  • 进程ID: $train_pid"
            echo "  • 启动时间: $start_time"
            echo "  • 运行时长: $runtime"
            echo "  • CPU使用: ${cpu_usage}%"
            echo "  • 内存使用: ${mem_usage}%"
        else
            echo -e "  ${RED}❌ 训练进程已停止${NC}"
            echo "  • 进程ID: $train_pid (已退出)"

            # 检查退出原因
            if [ -f "$PROJECT_DIR/logs/training.log" ]; then
                local last_error=$(tail -50 "$PROJECT_DIR/logs/training.log" | grep -i "error\|exception\|failed" | tail -1)
                if [ -n "$last_error" ]; then
                    echo "  • 可能错误: $last_error"
                fi
            fi
        fi
    else
        echo -e "  ${YELLOW}❓ 未找到训练进程${NC}"
        echo "  • 请先运行: ./deploy/train_on_server.sh"
    fi

    echo ""
}

# 显示GPU状态
show_gpu_status() {
    echo -e "${PURPLE}🖥️  GPU状态监控${NC}"
    echo "================================"

    if command -v nvidia-smi &> /dev/null; then
        # GPU基本信息
        local gpu_info=$(nvidia-smi --query-gpu=index,name,driver_version --format=csv,noheader,nounits 2>/dev/null)
        echo "GPU信息: $gpu_info"
        echo ""

        # GPU使用情况
        echo "实时使用情况:"
        nvidia-smi --query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw --format=csv,noheader,nounits 2>/dev/null | while IFS=',' read -r index name util mem_used mem_total temp power; do
            local mem_percent=$((mem_used * 100 / mem_total))
            echo "  GPU$index ($name):"
            echo "    • 利用率: ${util}%"
            echo "    • 显存: ${mem_used}MB/${mem_total}MB (${mem_percent}%)"
            echo "    • 温度: ${temp}°C"
            echo "    • 功耗: ${power}W"
        done

        # 进程信息
        echo ""
        echo "GPU进程:"
        nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader,nounits 2>/dev/null | while IFS=',' read -r pid name memory; do
            echo "  • PID $pid: $name (${memory}MB)"
        done
    else
        echo -e "  ${RED}❌ NVIDIA驱动未安装或GPU不可用${NC}"
    fi

    echo ""
}

# 显示训练进度
show_training_progress() {
    echo -e "${GREEN}📈 训练进度分析${NC}"
    echo "================================"

    if [ -f "$PROJECT_DIR/logs/training.log" ]; then
        # 提取关键信息
        local total_steps=$(grep -o "max_steps.*[0-9]\+" "$PROJECT_DIR/logs/training.log" | tail -1 | grep -o "[0-9]\+" || echo "1000")
        local current_step=$(grep -o "{'train_loss':" "$PROJECT_DIR/logs/training.log" | wc -l)
        local latest_loss=$(grep "{'train_loss':" "$PROJECT_DIR/logs/training.log" | tail -1 | grep -o "'train_loss': [0-9.]\+" | grep -o "[0-9.]\+" || echo "N/A")

        if [ "$current_step" -gt 0 ]; then
            local progress_percent=$((current_step * 100 / total_steps))
            echo "  • 训练步数: $current_step / $total_steps ($progress_percent%)"
            echo "  • 最新损失: $latest_loss"

            # 估算剩余时间
            if [ "$current_step" -gt 10 ]; then
                local start_time=$(head -50 "$PROJECT_DIR/logs/training.log" | grep -o "[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\} [0-9]\{2\}:[0-9]\{2\}:[0-9]\{2\}" | head -1)
                if [ -n "$start_time" ]; then
                    local elapsed_seconds=$(( $(date +%s) - $(date -d "$start_time" +%s) ))
                    local steps_per_second=$(echo "scale=2; $current_step / $elapsed_seconds" | bc -l 2>/dev/null || echo "0.1")
                    local remaining_steps=$((total_steps - current_step))
                    local remaining_seconds=$(echo "scale=0; $remaining_steps / $steps_per_second" | bc -l 2>/dev/null || echo "3600")
                    local remaining_time=$(date -u -d @$remaining_seconds +%H:%M:%S 2>/dev/null || echo "未知")

                    echo "  • 预计剩余: $remaining_time"
                fi
            fi
        else
            echo "  • 训练尚未开始或日志解析失败"
        fi

        # 显示最近的损失趋势
        echo ""
        echo "最近损失趋势:"
        grep "{'train_loss':" "$PROJECT_DIR/logs/training.log" | tail -5 | while read line; do
            local step=$(echo "$line" | grep -o "'step': [0-9]\+" | grep -o "[0-9]\+")
            local loss=$(echo "$line" | grep -o "'train_loss': [0-9.]\+" | grep -o "[0-9.]\+")
            echo "  Step $step: Loss $loss"
        done
    else
        echo -e "  ${YELLOW}⚠️  训练日志文件不存在${NC}"
    fi

    echo ""
}

# 显示最新日志
show_recent_logs() {
    echo -e "${CYAN}📝 最新训练日志${NC}"
    echo "================================"

    if [ -f "$PROJECT_DIR/logs/training.log" ]; then
        echo "最后20行日志:"
        echo "------------------------"
        tail -20 "$PROJECT_DIR/logs/training.log" | while read line; do
            # 高亮错误和警告
            if echo "$line" | grep -qi "error\|exception\|failed"; then
                echo -e "${RED}$line${NC}"
            elif echo "$line" | grep -qi "warning\|warn"; then
                echo -e "${YELLOW}$line${NC}"
            elif echo "$line" | grep -qi "completed\|success\|finished"; then
                echo -e "${GREEN}$line${NC}"
            else
                echo "$line"
            fi
        done
    else
        echo -e "${YELLOW}日志文件不存在${NC}"
    fi

    echo ""
}

# 显示文件状态
show_file_status() {
    echo -e "${BLUE}💾 文件状态${NC}"
    echo "================================"

    cd "$PROJECT_DIR"

    # 训练数据
    if [ -f "data/generated/training_data.json" ]; then
        local sample_count=$(grep -o '"task_type"' data/generated/training_data.json | wc -l)
        local file_size=$(du -h data/generated/training_data.json | cut -f1)
        echo "  • 训练数据: $sample_count 样本 ($file_size)"
    else
        echo "  • 训练数据: 未生成"
    fi

    # 模型文件
    if [ -d "data/models" ] && [ "$(ls -A data/models 2>/dev/null)" ]; then
        echo "  • 模型文件:"
        ls -la data/models/ | tail -n +2 | while read line; do
            echo "    $line"
        done
    else
        echo "  • 模型文件: 未生成"
    fi

    # 日志文件
    if [ -f "logs/training.log" ]; then
        local log_size=$(du -h logs/training.log | cut -f1)
        local log_lines=$(wc -l < logs/training.log)
        echo "  • 训练日志: $log_lines 行 ($log_size)"
    else
        echo "  • 训练日志: 不存在"
    fi

    echo ""
}

# 显示快捷命令
show_quick_commands() {
    echo -e "${YELLOW}🔧 快捷命令${NC}"
    echo "================================"
    echo "  tail -f logs/training.log           # 实时日志"
    echo "  watch -n 1 nvidia-smi              # GPU监控"
    echo "  kill \$(cat logs/train.pid)         # 停止训练"
    echo "  ./deploy/train_on_server.sh         # 重新训练"
    echo "  python examples/test_model.py       # 测试模型"
    echo ""
}

# 主函数
main() {
    clear
    echo -e "${CYAN}"
    echo "📊 ERD自监督学习训练监控面板"
    echo "================================"
    echo "更新时间: $(get_timestamp)"
    echo -e "${NC}"
    echo ""

    cd "$PROJECT_DIR"

    # 显示各种状态
    check_training_process
    show_gpu_status
    show_training_progress
    show_recent_logs
    show_file_status
    show_quick_commands
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
