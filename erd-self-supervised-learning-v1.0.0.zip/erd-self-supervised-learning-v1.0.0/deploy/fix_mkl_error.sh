#!/bin/bash

# Intel oneMKL 错误专用修复脚本
# 作者：Claude 4.0 sonnet
# 功能：专门解决 vLLM 启动时的 Intel oneMKL FATAL ERROR 问题

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 获取Python命令
get_python_cmd() {
    if [ -f "/root/miniconda/bin/python" ]; then
        echo "/root/miniconda/bin/python"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        echo "/root/miniconda3/bin/python"
    elif command -v python3 &> /dev/null; then
        echo "python3"
    else
        echo "python"
    fi
}

# 检测 MKL 错误
detect_mkl_error() {
    log_step "🔍 检测 Intel oneMKL 错误..."
    
    local python_cmd=$(get_python_cmd)
    local error_detected=false
    
    # 尝试导入 torch 并捕获 MKL 错误
    local import_result=$($python_cmd -c "
import sys
try:
    import torch
    print('SUCCESS: PyTorch导入成功')
    print(f'PyTorch版本: {torch.__version__}')
    print(f'CUDA可用: {torch.cuda.is_available()}')
except Exception as e:
    error_msg = str(e)
    if 'Intel oneMKL FATAL ERROR' in error_msg or 'libtorch_cpu.so' in error_msg:
        print('MKL_ERROR: 检测到Intel oneMKL错误')
        print(f'错误详情: {error_msg}')
    else:
        print(f'OTHER_ERROR: {error_msg}')
" 2>&1)
    
    echo "$import_result"
    
    if echo "$import_result" | grep -q "MKL_ERROR"; then
        log_error "❌ 检测到 Intel oneMKL 错误"
        return 0  # 检测到错误，需要修复
    elif echo "$import_result" | grep -q "SUCCESS"; then
        log_info "✅ PyTorch 工作正常，无需修复"
        return 1  # 无错误
    else
        log_warn "⚠️  PyTorch 导入异常，建议修复"
        return 0  # 其他错误，也尝试修复
    fi
}

# 备份当前环境
backup_current_env() {
    log_step "💾 备份当前 PyTorch 环境..."
    
    local python_cmd=$(get_python_cmd)
    local backup_dir="/tmp/pytorch_backup_$(date +%Y%m%d_%H%M%S)"
    
    mkdir -p "$backup_dir"
    
    # 备份已安装包列表
    $python_cmd -m pip list > "$backup_dir/pip_list.txt" 2>/dev/null || true
    
    # 备份 PyTorch 版本信息
    $python_cmd -c "
try:
    import torch
    with open('$backup_dir/torch_info.txt', 'w') as f:
        f.write(f'PyTorch版本: {torch.__version__}\\n')
        f.write(f'CUDA版本: {torch.version.cuda}\\n')
        f.write(f'CUDA可用: {torch.cuda.is_available()}\\n')
except:
    pass
" 2>/dev/null || true
    
    echo "$backup_dir" > /tmp/pytorch_backup_path.txt
    log_info "✅ 环境备份完成: $backup_dir"
    return 0
}

# 完全卸载 PyTorch
uninstall_pytorch() {
    log_step "🗑️  完全卸载 PyTorch..."
    
    local python_cmd=$(get_python_cmd)
    
    # 卸载 PyTorch 相关包
    local pytorch_packages=(
        "torch"
        "torchvision" 
        "torchaudio"
        "torchtext"
        "torchdata"
    )
    
    for package in "${pytorch_packages[@]}"; do
        if $python_cmd -c "import $package" 2>/dev/null; then
            log_info "卸载 $package..."
            $python_cmd -m pip uninstall "$package" -y 2>/dev/null || true
        fi
    done
    
    # 清理缓存
    $python_cmd -m pip cache purge 2>/dev/null || true
    
    # 清理临时文件
    rm -rf /tmp/pip-* 2>/dev/null || true
    rm -rf ~/.cache/pip/* 2>/dev/null || true
    
    log_info "✅ PyTorch 卸载完成"
    return 0
}

# 检测 GPU 类型
detect_gpu_type() {
    if command -v nvidia-smi &> /dev/null; then
        local gpu_info=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | head -1)
        if [[ "$gpu_info" == *"RTX 4090"* ]]; then
            echo "RTX_4090"
        elif [[ "$gpu_info" == *"RTX 3090"* ]]; then
            echo "RTX_3090"
        elif [[ "$gpu_info" == *"RTX"* ]]; then
            echo "RTX_OTHER"
        else
            echo "UNKNOWN"
        fi
    else
        echo "NO_GPU"
    fi
}

# 重新安装 PyTorch
reinstall_pytorch() {
    log_step "📦 重新安装 PyTorch..."
    
    local python_cmd=$(get_python_cmd)
    local gpu_type=$(detect_gpu_type)
    
    log_info "检测到GPU类型: $gpu_type"
    
    # 根据 GPU 类型选择合适的 PyTorch 版本
    case "$gpu_type" in
        "RTX_4090")
            log_info "为 RTX 4090 安装 CUDA 12.1 版本"
            $python_cmd -m pip install torch torchvision torchaudio \
                --index-url https://download.pytorch.org/whl/cu121 \
                --timeout 300
            ;;
        "RTX_3090"|"RTX_OTHER")
            log_info "为 RTX GPU 安装 CUDA 11.8 版本"
            $python_cmd -m pip install torch torchvision torchaudio \
                --index-url https://download.pytorch.org/whl/cu118 \
                --timeout 300
            ;;
        "NO_GPU"|"UNKNOWN")
            log_info "安装 CPU 版本"
            $python_cmd -m pip install torch torchvision torchaudio \
                --index-url https://download.pytorch.org/whl/cpu \
                --timeout 300
            ;;
    esac
    
    if [ $? -eq 0 ]; then
        log_info "✅ PyTorch 安装成功"
        return 0
    else
        log_error "❌ PyTorch 安装失败"
        return 1
    fi
}

# 设置环境变量
set_mkl_env_vars() {
    log_step "🔧 设置 MKL 环境变量..."
    
    # 创建环境变量设置脚本
    cat > /tmp/mkl_env_fix.sh << 'EOF'
#!/bin/bash
# Intel oneMKL 环境变量修复
export MKL_THREADING_LAYER=GNU
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
EOF
    
    chmod +x /tmp/mkl_env_fix.sh
    
    # 添加到 bashrc
    if ! grep -q "MKL_THREADING_LAYER" ~/.bashrc 2>/dev/null; then
        echo "" >> ~/.bashrc
        echo "# Intel oneMKL 环境变量修复" >> ~/.bashrc
        echo "export MKL_THREADING_LAYER=GNU" >> ~/.bashrc
        echo "export OMP_NUM_THREADS=1" >> ~/.bashrc
    fi
    
    # 立即应用环境变量
    source /tmp/mkl_env_fix.sh
    
    log_info "✅ MKL 环境变量设置完成"
    return 0
}

# 验证修复结果
verify_fix() {
    log_step "✅ 验证修复结果..."
    
    local python_cmd=$(get_python_cmd)
    
    # 应用环境变量
    export MKL_THREADING_LAYER=GNU
    export OMP_NUM_THREADS=1
    
    local verify_result=$($python_cmd -c "
import sys
try:
    import torch
    print('✅ PyTorch导入成功')
    print(f'PyTorch版本: {torch.__version__}')
    
    if torch.cuda.is_available():
        print(f'✅ CUDA可用: {torch.cuda.device_count()} 个GPU')
        for i in range(torch.cuda.device_count()):
            print(f'  GPU {i}: {torch.cuda.get_device_name(i)}')
    else:
        print('ℹ️  CUDA不可用，使用CPU模式')
    
    # 测试基本操作
    x = torch.randn(2, 3)
    y = torch.randn(3, 2)
    z = torch.mm(x, y)
    print('✅ PyTorch基本操作测试通过')
    
    print('SUCCESS')
except Exception as e:
    print(f'❌ 验证失败: {e}')
    print('FAILED')
" 2>&1)
    
    echo "$verify_result"
    
    if echo "$verify_result" | grep -q "SUCCESS"; then
        log_info "🎉 修复验证成功！"
        return 0
    else
        log_error "❌ 修复验证失败"
        return 1
    fi
}

# 回滚到备份
rollback_to_backup() {
    log_step "🔄 回滚到备份环境..."

    if [ ! -f "/tmp/pytorch_backup_path.txt" ]; then
        log_error "❌ 找不到备份路径"
        return 1
    fi

    local backup_dir=$(cat /tmp/pytorch_backup_path.txt)

    if [ ! -d "$backup_dir" ]; then
        log_error "❌ 备份目录不存在: $backup_dir"
        return 1
    fi

    log_info "从备份恢复: $backup_dir"

    # 这里可以添加具体的回滚逻辑
    # 由于 pip 没有直接的回滚功能，我们提供手动指导
    log_warn "⚠️  请手动检查备份文件并重新安装需要的包："
    log_info "备份信息: cat $backup_dir/pip_list.txt"
    log_info "PyTorch信息: cat $backup_dir/torch_info.txt"

    return 0
}

# 生成修复报告
generate_fix_report() {
    log_step "📊 生成修复报告..."

    local python_cmd=$(get_python_cmd)
    local report_file="mkl_fix_report_$(date +%Y%m%d_%H%M%S).txt"

    cat > "$report_file" << EOF
Intel oneMKL 错误修复报告
========================
修复时间: $(date '+%Y-%m-%d %H:%M:%S')
Python路径: $python_cmd
操作系统: $(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d'"' -f2 || echo "Unknown")

GPU信息:
$(nvidia-smi --query-gpu=name,memory.total --format=csv 2>/dev/null || echo "无GPU或nvidia-smi不可用")

修复前状态:
$(cat /tmp/pytorch_backup_path.txt 2>/dev/null && echo "备份已创建" || echo "无备份")

修复后状态:
EOF

    # 添加当前 PyTorch 状态
    $python_cmd -c "
try:
    import torch
    print(f'PyTorch版本: {torch.__version__}')
    print(f'CUDA版本: {torch.version.cuda}')
    print(f'CUDA可用: {torch.cuda.is_available()}')
    if torch.cuda.is_available():
        print(f'GPU数量: {torch.cuda.device_count()}')
except Exception as e:
    print(f'PyTorch状态异常: {e}')
" >> "$report_file" 2>/dev/null

    echo "" >> "$report_file"
    echo "环境变量设置:" >> "$report_file"
    echo "MKL_THREADING_LAYER=$MKL_THREADING_LAYER" >> "$report_file"
    echo "OMP_NUM_THREADS=$OMP_NUM_THREADS" >> "$report_file"

    log_info "✅ 修复报告已生成: $report_file"
    return 0
}

# 自动修复主流程
auto_fix() {
    log_info "🔧 开始 Intel oneMKL 自动修复流程..."
    echo ""

    # 1. 检测错误
    if ! detect_mkl_error; then
        log_info "✅ 无需修复，退出"
        return 0
    fi

    # 2. 备份环境
    backup_current_env

    # 3. 卸载 PyTorch
    uninstall_pytorch

    # 4. 重新安装 PyTorch
    if ! reinstall_pytorch; then
        log_error "❌ PyTorch 重新安装失败"
        return 1
    fi

    # 5. 设置环境变量
    set_mkl_env_vars

    # 6. 验证修复
    if verify_fix; then
        log_info "🎉 Intel oneMKL 错误修复成功！"
        generate_fix_report
        return 0
    else
        log_error "❌ 修复失败，请查看日志"
        return 1
    fi
}

# 测试 vLLM 启动
test_vllm_startup() {
    log_step "🚀 测试 vLLM 启动..."

    local python_cmd=$(get_python_cmd)

    # 应用环境变量
    export MKL_THREADING_LAYER=GNU
    export OMP_NUM_THREADS=1

    # 简单的 vLLM 导入测试
    local vllm_test=$($python_cmd -c "
try:
    import vllm
    print('✅ vLLM导入成功')
    print(f'vLLM版本: {vllm.__version__}')
    print('SUCCESS')
except Exception as e:
    print(f'❌ vLLM导入失败: {e}')
    print('FAILED')
" 2>&1)

    echo "$vllm_test"

    if echo "$vllm_test" | grep -q "SUCCESS"; then
        log_info "✅ vLLM 测试通过"
        return 0
    else
        log_warn "⚠️  vLLM 测试失败，但 PyTorch 可能已修复"
        return 1
    fi
}

# 显示使用说明
show_usage() {
    echo -e "${CYAN}Intel oneMKL 错误修复脚本${NC}"
    echo "================================"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --detect      仅检测 MKL 错误"
    echo "  --fix         自动修复 MKL 错误"
    echo "  --verify      验证修复结果"
    echo "  --test-vllm   测试 vLLM 启动"
    echo "  --rollback    回滚到备份"
    echo "  --report      生成修复报告"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 --fix         # 自动检测并修复"
    echo "  $0 --detect      # 仅检测问题"
    echo "  $0 --test-vllm   # 测试vLLM启动"
    echo ""
    echo "环境变量:"
    echo "  MKL_THREADING_LAYER=GNU    # 绕过MKL问题"
    echo "  OMP_NUM_THREADS=1          # 限制线程数"
    echo ""
}

# 主函数
main() {
    case "${1:---help}" in
        --detect)
            detect_mkl_error
            ;;
        --fix)
            auto_fix
            ;;
        --verify)
            verify_fix
            ;;
        --test-vllm)
            test_vllm_startup
            ;;
        --rollback)
            rollback_to_backup
            ;;
        --report)
            generate_fix_report
            ;;
        --help|"")
            show_usage
            ;;
        *)
            log_error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
