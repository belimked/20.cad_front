#!/bin/bash

# ERD项目Miniconda环境专用设置脚本
# 作者：Claude 4.0 sonnet
# 功能：专门适配 /root/miniconda/bin/python 环境

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 检测Miniconda环境
detect_miniconda() {
    step "🔍 检测Miniconda环境..."
    
    # 检查Python路径
    if [ -f "/root/miniconda/bin/python" ]; then
        export CONDA_PATH="/root/miniconda"
        export PYTHON_CMD="/root/miniconda/bin/python"
        export CONDA_CMD="/root/miniconda/bin/conda"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        export CONDA_PATH="/root/miniconda3"
        export PYTHON_CMD="/root/miniconda3/bin/python"
        export CONDA_CMD="/root/miniconda3/bin/conda"
    else
        error "❌ 未找到Miniconda安装"
        return 1
    fi
    
    log "✅ 检测到Miniconda: $CONDA_PATH"
    
    # 检查Python版本
    local python_version=$($PYTHON_CMD --version 2>&1)
    log "Python版本: $python_version"
    
    # 检查conda版本
    local conda_version=$($CONDA_CMD --version 2>&1)
    log "Conda版本: $conda_version"
    
    return 0
}

# 使用现有conda环境
use_existing_conda_env() {
    step "🐍 使用现有Conda环境..."

    # 初始化conda
    source $CONDA_PATH/etc/profile.d/conda.sh

    # 使用base环境或当前激活的环境
    log "使用现有的conda环境..."

    # 验证环境
    local current_python=$(which python)
    log "当前Python路径: $current_python"

    # 检查Python版本
    local python_version=$(python --version 2>&1)
    log "Python版本: $python_version"

    return 0
}

# 安装依赖包
install_dependencies() {
    step "📦 安装依赖包..."

    # 确保在正确的环境中
    source $CONDA_PATH/etc/profile.d/conda.sh
    # 不需要激活特定环境，使用当前环境
    
    # 升级pip
    log "升级pip..."
    pip install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
    
    # 检测GPU并安装对应的PyTorch
    if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
        log "检测到RTX 4090，安装优化版PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
    elif nvidia-smi &> /dev/null; then
        log "检测到NVIDIA GPU，安装CUDA版PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
    else
        log "未检测到GPU，安装CPU版PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
    fi
    
    # 安装其他依赖
    log "安装其他依赖..."
    pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
    
    return 0
}

# 创建环境配置文件
create_env_config() {
    step "🔧 创建环境配置..."

    cat > erd_env_config.sh << EOF
#!/bin/bash
# ERD训练环境配置 - Miniconda版本

# 初始化conda
source $CONDA_PATH/etc/profile.d/conda.sh
# 使用当前conda环境，不需要激活特定环境

# Python路径
export PYTHONPATH="\${PYTHONPATH}:\$(pwd)/src"
export PYTHON_CMD="$PYTHON_CMD"

# CUDA配置
export CUDA_VISIBLE_DEVICES=0
export TOKENIZERS_PARALLELISM=false

# HuggingFace配置
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_CACHE=/root/lanyun-tmp/modelscope_cache
export TRANSFORMERS_CACHE=/root/lanyun-tmp/modelscope_cache

# 训练优化配置
if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
    export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512
    export CUDA_LAUNCH_BLOCKING=0
fi

# pip镜像配置
export PIP_INDEX_URL="https://mirrors.aliyun.com/pypi/simple/"
export PIP_TRUSTED_HOST="mirrors.aliyun.com"

echo "✅ ERD训练环境已配置 (Miniconda)"
EOF
    
    chmod +x erd_env_config.sh
    log "✅ 环境配置文件已创建"
    
    return 0
}

# 验证安装
verify_installation() {
    step "✅ 验证安装..."

    # 初始化conda
    source $CONDA_PATH/etc/profile.d/conda.sh
    # 使用当前环境
    
    # 检查关键依赖
    log "检查PyTorch..."
    /root/miniconda/bin/python  -c "import torch; print(f'PyTorch版本: {torch.__version__}'); print(f'CUDA可用: {torch.cuda.is_available()}')"
    
    log "检查Transformers..."
    /root/miniconda/bin/python  -c "import transformers; print(f'Transformers版本: {transformers.__version__}')"
    
    log "检查PEFT..."
    /root/miniconda/bin/python  -c "import peft; print(f'PEFT版本: {peft.__version__}')"
    
    # 检查GPU
    if nvidia-smi &> /dev/null; then
        log "检查GPU..."
        /root/miniconda/bin/python  -c "import torch; print(f'GPU数量: {torch.cuda.device_count()}'); [print(f'GPU {i}: {torch.cuda.get_device_name(i)}') for i in range(torch.cuda.device_count())]"
    fi
    
    return 0
}

# 创建快速启动脚本
create_quick_start() {
    step "🚀 创建快速启动脚本..."
    
    cat > quick_train_miniconda.sh << EOF
#!/bin/bash
# ERD训练快速启动脚本 - Miniconda版本

# 初始化conda环境
source $CONDA_PATH/etc/profile.d/conda.sh
# 使用当前conda环境

# 加载环境配置
source erd_env_config.sh

echo "🧠 启动ERD自监督学习训练 (Miniconda)"
echo "=================================="

# 检查ERD文件
if [ ! -f "data/erd/cost_erd.json" ]; then
    echo "❌ ERD文件不存在，请先准备数据"
    exit 1
fi

# 启动训练
$PYTHON_CMD examples/train_model.py \\
    --erd_file data/erd/cost_erd.json \\
    --max_samples 8000 \\
    --config config/qwen_3b_config.yaml \\
    --output_dir data/generated

echo "✅ 训练启动完成"
EOF
    
    chmod +x quick_train_miniconda.sh
    log "✅ 快速启动脚本已创建"
    
    return 0
}

# 显示使用说明
show_usage() {
    echo ""
    echo -e "${GREEN}🎉 Miniconda环境设置完成！${NC}"
    echo "================================"
    echo ""
    echo "📊 环境信息:"
    echo "  • Conda路径: $CONDA_PATH"
    echo "  • Python命令: $PYTHON_CMD"
    echo "  • 环境名称: 当前conda环境"
    echo ""
    echo "🚀 使用方法:"
    echo "  ./quick_train_miniconda.sh          # 快速训练"
    echo "  ./deploy/train_on_server.sh         # 后台训练"
    echo "  ./deploy/monitor_training.sh        # 监控训练"
    echo ""
    echo "🔧 手动操作:"
    echo "  source $CONDA_PATH/etc/profile.d/conda.sh"
    echo "  # 使用当前conda环境"
    echo "  source erd_env_config.sh"
    echo "  python examples/train_model.py ..."
    echo ""
}

# 主函数
main() {
    echo -e "${BLUE}"
    echo "🐍 ERD项目Miniconda环境设置"
    echo "================================"
    echo "专门适配 /root/miniconda/bin/python"
    echo -e "${NC}"
    
    if detect_miniconda && \
       use_existing_conda_env && \
       install_dependencies && \
       create_env_config && \
       verify_installation && \
       create_quick_start; then
        
        show_usage
        log "✅ Miniconda环境设置成功"
        return 0
    else
        error "❌ Miniconda环境设置失败"
        return 1
    fi
}

# 脚本入口
main "$@"
