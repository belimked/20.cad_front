#!/bin/bash

# ERD项目依赖包修复脚本
# 作者：Claude 4.0 sonnet
# 功能：检查和修复缺失的依赖包

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 获取Python命令
get_python_cmd() {
    if [ -f "deploy/detect_python.sh" ]; then
        chmod +x deploy/detect_python.sh
        ./deploy/detect_python.sh --detect
    elif [ -f "/root/miniconda/bin/python" ]; then
        echo "/root/miniconda/bin/python"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        echo "/root/miniconda3/bin/python"
    elif command -v python3 &> /dev/null; then
        echo "python3"
    else
        echo "python"
    fi
}

# 检查依赖包
check_dependencies() {
    step "📦 检查依赖包..."
    
    local python_cmd=$(get_python_cmd)
    local missing_deps=()
    local optional_deps=()
    
    # 核心依赖包
    local core_deps=(
        "torch"
        "transformers"
        "peft"
        "datasets"
        "accelerate"
        "numpy"
        "pandas"
        "tqdm"
        "pyyaml"
        "scikit-learn"
    )
    
    # 可选依赖包
    local optional_deps_list=(
        "wandb"
        "tensorboard"
        "matplotlib"
        "seaborn"
    )
    
    log "使用Python: $python_cmd"
    
    # 检查核心依赖
    for dep in "${core_deps[@]}"; do
        if $python_cmd -c "import $dep" 2>/dev/null; then
            local version=$($python_cmd -c "import $dep; print($dep.__version__)" 2>/dev/null || echo "未知版本")
            log "✅ $dep: $version"
        else
            missing_deps+=("$dep")
            error "❌ $dep: 缺失"
        fi
    done
    
    # 检查可选依赖
    for dep in "${optional_deps_list[@]}"; do
        if $python_cmd -c "import $dep" 2>/dev/null; then
            local version=$($python_cmd -c "import $dep; print($dep.__version__)" 2>/dev/null || echo "未知版本")
            log "✅ $dep (可选): $version"
        else
            optional_deps+=("$dep")
            warn "⚠️  $dep (可选): 缺失"
        fi
    done
    
    # 返回结果
    if [ ${#missing_deps[@]} -gt 0 ]; then
        error "❌ 缺少核心依赖: ${missing_deps[*]}"
        export MISSING_CORE_DEPS="${missing_deps[*]}"
        return 1
    else
        log "✅ 所有核心依赖已安装"
        export MISSING_OPTIONAL_DEPS="${optional_deps[*]}"
        return 0
    fi
}

# 安装缺失的依赖
install_missing_deps() {
    step "📥 安装缺失的依赖..."
    
    local python_cmd=$(get_python_cmd)
    
    # 确保pip可用
    if ! $python_cmd -m pip --version &> /dev/null; then
        error "❌ pip不可用"
        return 1
    fi
    
    # 安装核心依赖
    if [ -n "$MISSING_CORE_DEPS" ]; then
        log "安装核心依赖: $MISSING_CORE_DEPS"
        
        # 使用阿里云镜像加速
        $python_cmd -m pip install $MISSING_CORE_DEPS \
            -i https://mirrors.aliyun.com/pypi/simple/ \
            --trusted-host mirrors.aliyun.com \
            --timeout 120
        
        if [ $? -eq 0 ]; then
            log "✅ 核心依赖安装成功"
        else
            error "❌ 核心依赖安装失败"
            return 1
        fi
    fi
    
    # 安装可选依赖（忽略失败）
    if [ -n "$MISSING_OPTIONAL_DEPS" ]; then
        log "尝试安装可选依赖: $MISSING_OPTIONAL_DEPS"
        
        for dep in $MISSING_OPTIONAL_DEPS; do
            $python_cmd -m pip install $dep \
                -i https://mirrors.aliyun.com/pypi/simple/ \
                --trusted-host mirrors.aliyun.com \
                --timeout 120 2>/dev/null
            
            if [ $? -eq 0 ]; then
                log "✅ $dep 安装成功"
            else
                warn "⚠️  $dep 安装失败（可选依赖，可忽略）"
            fi
        done
    fi
    
    return 0
}

# 修复PyTorch CUDA支持
fix_pytorch_cuda() {
    step "🔥 检查PyTorch CUDA支持..."
    
    local python_cmd=$(get_python_cmd)
    
    # 检查CUDA可用性
    if $python_cmd -c "import torch; print(f'CUDA可用: {torch.cuda.is_available()}')" 2>/dev/null | grep -q "True"; then
        log "✅ PyTorch CUDA支持正常"
        return 0
    fi
    
    # 检查是否有GPU
    if ! command -v nvidia-smi &> /dev/null; then
        warn "⚠️  未检测到NVIDIA GPU，使用CPU版本"
        return 0
    fi
    
    # 重新安装CUDA版本的PyTorch
    warn "⚠️  PyTorch CUDA支持异常，尝试重新安装..."
    
    # 检测GPU类型
    if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
        log "检测到RTX 4090，安装CUDA 12.1版本"
        $python_cmd -m pip install torch torchvision torchaudio \
            --index-url https://download.pytorch.org/whl/cu121 \
            --force-reinstall
    else
        log "安装CUDA 11.8版本"
        $python_cmd -m pip install torch torchvision torchaudio \
            --index-url https://download.pytorch.org/whl/cu118 \
            --force-reinstall
    fi
    
    # 验证安装
    if $python_cmd -c "import torch; print(f'CUDA可用: {torch.cuda.is_available()}')" 2>/dev/null | grep -q "True"; then
        log "✅ PyTorch CUDA支持修复成功"
        return 0
    else
        warn "⚠️  PyTorch CUDA支持仍然异常，但可以使用CPU训练"
        return 0
    fi
}

# 清理pip缓存
clean_pip_cache() {
    step "🧹 清理pip缓存..."
    
    local python_cmd=$(get_python_cmd)
    
    # 清理pip缓存
    $python_cmd -m pip cache purge 2>/dev/null || true
    
    # 清理临时文件
    rm -rf /tmp/pip-* 2>/dev/null || true
    rm -rf ~/.cache/pip/* 2>/dev/null || true
    
    log "✅ pip缓存清理完成"
    return 0
}

# 生成依赖报告
generate_dependency_report() {
    step "📊 生成依赖报告..."
    
    local python_cmd=$(get_python_cmd)
    
    cat > dependency_report.txt << EOF
ERD项目依赖包报告
==================
检查时间: $(date '+%Y-%m-%d %H:%M:%S')
Python路径: $python_cmd
Python版本: $($python_cmd --version 2>&1)

已安装的包:
EOF
    
    # 获取已安装包列表
    $python_cmd -m pip list >> dependency_report.txt 2>/dev/null || echo "无法获取包列表" >> dependency_report.txt
    
    echo "" >> dependency_report.txt
    echo "PyTorch信息:" >> dependency_report.txt
    $python_cmd -c "
import torch
print(f'PyTorch版本: {torch.__version__}')
print(f'CUDA可用: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'CUDA版本: {torch.version.cuda}')
    print(f'GPU数量: {torch.cuda.device_count()}')
    for i in range(torch.cuda.device_count()):
        print(f'GPU {i}: {torch.cuda.get_device_name(i)}')
" >> dependency_report.txt 2>/dev/null || echo "无法获取PyTorch信息" >> dependency_report.txt
    
    log "✅ 依赖报告已生成: dependency_report.txt"
    return 0
}

# 显示修复建议
show_fix_suggestions() {
    step "💡 修复建议..."
    
    echo ""
    echo "如果依赖包问题仍然存在，请尝试："
    echo ""
    echo "1. 手动安装缺失的包："
    echo "   pip install torch transformers peft datasets accelerate"
    echo ""
    echo "2. 使用国内镜像源："
    echo "   pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/"
    echo ""
    echo "3. 升级pip版本："
    echo "   pip install --upgrade pip"
    echo ""
    echo "4. 清理环境重新安装："
    echo "   pip uninstall torch transformers peft -y"
    echo "   pip install torch transformers peft"
    echo ""
    echo "5. 查看详细报告："
    echo "   cat dependency_report.txt"
    echo ""
}

# 显示使用说明
show_usage() {
    echo "ERD项目依赖包修复脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --check       检查依赖包状态"
    echo "  --install     安装缺失的依赖包"
    echo "  --fix-cuda    修复PyTorch CUDA支持"
    echo "  --clean       清理pip缓存"
    echo "  --report      生成依赖报告"
    echo "  --auto        自动修复（推荐）"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 --auto        # 自动检查和修复"
    echo "  $0 --check       # 仅检查依赖状态"
    echo "  $0 --install     # 安装缺失依赖"
    echo ""
}

# 快速检查（仅检查关键依赖）
quick_check() {
    local python_cmd=$(get_python_cmd)

    # 只检查最关键的依赖
    local critical_deps=("torch" "transformers" "peft")

    for dep in "${critical_deps[@]}"; do
        if ! $python_cmd -c "import $dep" 2>/dev/null; then
            return 1
        fi
    done

    return 0
}

# 主函数
main() {
    case "${1:-}" in
        --check)
            check_dependencies
            ;;
        --quick-check)
            quick_check
            ;;
        --install)
            if check_dependencies; then
                log "✅ 依赖检查通过"
            else
                install_missing_deps
            fi
            ;;
        --fix-cuda)
            fix_pytorch_cuda
            ;;
        --clean)
            clean_pip_cache
            ;;
        --report)
            generate_dependency_report
            ;;
        --auto)
            echo -e "${BLUE}"
            echo "🔧 ERD项目依赖包自动修复"
            echo "================================"
            echo -e "${NC}"

            # 先快速检查，如果通过就跳过详细检查
            if quick_check; then
                log "✅ 关键依赖已安装，跳过详细检查"
            else
                clean_pip_cache

                if ! check_dependencies; then
                    install_missing_deps
                    check_dependencies
                fi

                fix_pytorch_cuda
                generate_dependency_report
            fi

            log "✅ 依赖包自动修复完成"
            ;;
        --help|"")
            show_usage
            ;;
        *)
            error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
