#!/bin/bash

# ERD项目环境检测脚本
# 作者：Claude 4.0 sonnet
# 功能：检测Python环境是否正确配置

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 检测Python环境
check_python_env() {
    step "🔍 检测Python环境..."
    
    # 检查Miniconda
    if [ -f "/root/miniconda/bin/python" ]; then
        log "✅ 检测到Miniconda: /root/miniconda/bin/python"
        export PYTHON_TYPE="miniconda"
        export PYTHON_CMD="/root/miniconda/bin/python"
        return 0
    elif [ -f "/root/miniconda3/bin/python" ]; then
        log "✅ 检测到Miniconda3: /root/miniconda3/bin/python"
        export PYTHON_TYPE="miniconda3"
        export PYTHON_CMD="/root/miniconda3/bin/python"
        return 0
    fi
    
    # 检查虚拟环境
    if [ -d "erd_env" ]; then
        log "✅ 检测到虚拟环境: erd_env"
        export PYTHON_TYPE="venv"
        export PYTHON_CMD="python"
        return 0
    fi
    
    # 检查系统Python
    if command -v python3 &> /dev/null; then
        warn "⚠️  使用系统Python3"
        export PYTHON_TYPE="system"
        export PYTHON_CMD="python3"
        return 0
    fi
    
    error "❌ 未找到可用的Python环境"
    return 1
}

# 检测依赖包
check_dependencies() {
    step "📦 检测依赖包..."
    
    # 激活对应环境
    case "$PYTHON_TYPE" in
        "miniconda"|"miniconda3")
            if [ -f "/root/miniconda/etc/profile.d/conda.sh" ]; then
                source /root/miniconda/etc/profile.d/conda.sh
            elif [ -f "/root/miniconda3/etc/profile.d/conda.sh" ]; then
                source /root/miniconda3/etc/profile.d/conda.sh
            fi
            ;;
        "venv")
            source erd_env/bin/activate
            ;;
    esac
    
    # 检查关键依赖
    local missing_deps=()
    
    if ! $PYTHON_CMD -c "import torch" 2>/dev/null; then
        missing_deps+=("torch")
    else
        local torch_version=$($PYTHON_CMD -c "import torch; print(torch.__version__)" 2>/dev/null)
        log "✅ PyTorch: $torch_version"
    fi
    
    if ! $PYTHON_CMD -c "import transformers" 2>/dev/null; then
        missing_deps+=("transformers")
    else
        local transformers_version=$($PYTHON_CMD -c "import transformers; print(transformers.__version__)" 2>/dev/null)
        log "✅ Transformers: $transformers_version"
    fi
    
    if ! $PYTHON_CMD -c "import peft" 2>/dev/null; then
        missing_deps+=("peft")
    else
        local peft_version=$($PYTHON_CMD -c "import peft; print(peft.__version__)" 2>/dev/null)
        log "✅ PEFT: $peft_version"
    fi
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        error "❌ 缺少依赖包: ${missing_deps[*]}"
        return 1
    fi
    
    return 0
}

# 检测GPU环境
check_gpu() {
    step "🖥️  检测GPU环境..."
    
    if command -v nvidia-smi &> /dev/null; then
        local gpu_info=$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>/dev/null)
        log "✅ GPU信息: $gpu_info"
        
        # 检查CUDA可用性
        case "$PYTHON_TYPE" in
            "miniconda"|"miniconda3")
                if [ -f "/root/miniconda/etc/profile.d/conda.sh" ]; then
                    source /root/miniconda/etc/profile.d/conda.sh
                elif [ -f "/root/miniconda3/etc/profile.d/conda.sh" ]; then
                    source /root/miniconda3/etc/profile.d/conda.sh
                fi
                ;;
            "venv")
                source erd_env/bin/activate
                ;;
        esac
        
        if $PYTHON_CMD -c "import torch; print(f'CUDA可用: {torch.cuda.is_available()}')" 2>/dev/null; then
            log "✅ PyTorch CUDA支持正常"
        else
            warn "⚠️  PyTorch CUDA支持异常"
        fi
    else
        warn "⚠️  未检测到NVIDIA GPU"
    fi
    
    return 0
}

# 检测项目文件
check_project_files() {
    step "📁 检测项目文件..."
    
    local required_files=(
        "data/erd/cost_erd.json"
        "config/qwen_3b_config.yaml"
        "examples/train_model.py"
        "deploy/train_on_server.sh"
    )
    
    local missing_files=()
    
    for file in "${required_files[@]}"; do
        if [ -f "$file" ]; then
            log "✅ $file"
        else
            missing_files+=("$file")
        fi
    done
    
    if [ ${#missing_files[@]} -gt 0 ]; then
        error "❌ 缺少文件: ${missing_files[*]}"
        return 1
    fi
    
    return 0
}

# 生成环境报告
generate_report() {
    step "📊 生成环境报告..."
    
    cat > env_report.txt << EOF
ERD项目环境检测报告
==================
检测时间: $(date '+%Y-%m-%d %H:%M:%S')

Python环境:
  类型: $PYTHON_TYPE
  命令: $PYTHON_CMD
  版本: $($PYTHON_CMD --version 2>&1)

依赖包:
$(case "$PYTHON_TYPE" in
    "miniconda"|"miniconda3")
        if [ -f "/root/miniconda/etc/profile.d/conda.sh" ]; then
            source /root/miniconda/etc/profile.d/conda.sh
        elif [ -f "/root/miniconda3/etc/profile.d/conda.sh" ]; then
            source /root/miniconda3/etc/profile.d/conda.sh
        fi
        ;;
    "venv")
        source erd_env/bin/activate
        ;;
esac

$PYTHON_CMD -c "
try:
    import torch
    print(f'  PyTorch: {torch.__version__}')
    print(f'  CUDA可用: {torch.cuda.is_available()}')
except:
    print('  PyTorch: 未安装')

try:
    import transformers
    print(f'  Transformers: {transformers.__version__}')
except:
    print('  Transformers: 未安装')

try:
    import peft
    print(f'  PEFT: {peft.__version__}')
except:
    print('  PEFT: 未安装')
" 2>/dev/null)

GPU信息:
$(nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>/dev/null || echo "  无GPU或驱动未安装")

磁盘空间:
$(df -h . | tail -1)

项目文件:
$(ls -la data/erd/cost_erd.json config/qwen_3b_config.yaml examples/train_model.py 2>/dev/null || echo "  部分文件缺失")
EOF
    
    log "✅ 环境报告已生成: env_report.txt"
    
    return 0
}

# 显示修复建议
show_fix_suggestions() {
    step "🔧 修复建议..."
    
    echo ""
    echo "如果环境检测失败，请尝试以下修复方法："
    echo ""
    echo "1. 重新运行环境设置："
    echo "   ./deploy/setup_server.sh"
    echo ""
    echo "2. 手动安装依赖："
    case "$PYTHON_TYPE" in
        "miniconda"|"miniconda3")
            echo "   pip install torch transformers peft datasets accelerate"
            ;;
        "venv")
            echo "   source erd_env/bin/activate"
            echo "   pip install torch transformers peft datasets accelerate"
            ;;
        *)
            echo "   pip3 install torch transformers peft datasets accelerate"
            ;;
    esac
    echo ""
    echo "3. 检查GPU驱动："
    echo "   nvidia-smi"
    echo ""
    echo "4. 查看详细报告："
    echo "   cat env_report.txt"
    echo ""
}

# 主函数
main() {
    echo -e "${BLUE}"
    echo "🔍 ERD项目环境检测"
    echo "================================"
    echo -e "${NC}"
    
    local all_checks_passed=true
    
    if ! check_python_env; then
        all_checks_passed=false
    fi
    
    if ! check_dependencies; then
        all_checks_passed=false
    fi
    
    check_gpu  # GPU检测不影响整体结果
    
    if ! check_project_files; then
        all_checks_passed=false
    fi
    
    generate_report
    
    echo ""
    if [ "$all_checks_passed" = true ]; then
        log "✅ 环境检测通过，可以开始训练"
        echo ""
        echo "🚀 开始训练："
        echo "  ./deploy/train_on_server.sh"
        return 0
    else
        error "❌ 环境检测失败"
        show_fix_suggestions
        return 1
    fi
}

# 脚本入口
main "$@"
