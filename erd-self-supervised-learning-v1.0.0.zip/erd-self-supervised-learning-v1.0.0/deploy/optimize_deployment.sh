#!/bin/bash

# ERD项目部署优化脚本
# 作者：Claude 4.0 sonnet
# 功能：减少重复检查，优化部署流程

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 创建部署状态跟踪
create_deployment_state() {
    step "📋 创建部署状态跟踪..."
    
    cat > .deployment_state << EOF
# ERD项目部署状态跟踪
# 此文件用于避免重复执行已完成的步骤

ENVIRONMENT_SETUP=false
DEPENDENCIES_CHECKED=false
GPU_OPTIMIZED=false
TRAINING_READY=false

# 时间戳
LAST_SETUP=$(date '+%Y-%m-%d %H:%M:%S')
EOF
    
    log "✅ 部署状态跟踪已创建"
}

# 读取部署状态
load_deployment_state() {
    if [ -f ".deployment_state" ]; then
        source .deployment_state
        log "📋 加载部署状态: 环境=${ENVIRONMENT_SETUP}, 依赖=${DEPENDENCIES_CHECKED}, GPU=${GPU_OPTIMIZED}"
    else
        # 默认状态
        ENVIRONMENT_SETUP=false
        DEPENDENCIES_CHECKED=false
        GPU_OPTIMIZED=false
        TRAINING_READY=false
    fi
}

# 更新部署状态
update_deployment_state() {
    local key=$1
    local value=$2
    
    if [ -f ".deployment_state" ]; then
        sed -i "s/^${key}=.*/${key}=${value}/" .deployment_state
    fi
}

# 智能环境检查
smart_env_check() {
    step "🔍 智能环境检查..."
    
    load_deployment_state
    
    if [ "$ENVIRONMENT_SETUP" = "true" ]; then
        log "✅ 环境已设置，跳过重复检查"
        return 0
    fi
    
    # 执行环境检查
    if [ -f "deploy/check_env.sh" ]; then
        chmod +x deploy/check_env.sh
        if ./deploy/check_env.sh --quick; then
            update_deployment_state "ENVIRONMENT_SETUP" "true"
            log "✅ 环境检查完成"
            return 0
        fi
    fi
    
    return 1
}

# 智能依赖检查
smart_dependency_check() {
    step "📦 智能依赖检查..."
    
    load_deployment_state
    
    if [ "$DEPENDENCIES_CHECKED" = "true" ]; then
        log "✅ 依赖已检查，跳过重复检查"
        return 0
    fi
    
    # 执行快速依赖检查
    if [ -f "deploy/fix_dependencies.sh" ]; then
        chmod +x deploy/fix_dependencies.sh
        if ./deploy/fix_dependencies.sh --quick-check; then
            update_deployment_state "DEPENDENCIES_CHECKED" "true"
            log "✅ 关键依赖检查通过"
            return 0
        else
            warn "⚠️  需要安装依赖，执行完整检查..."
            if ./deploy/fix_dependencies.sh --auto; then
                update_deployment_state "DEPENDENCIES_CHECKED" "true"
                log "✅ 依赖安装完成"
                return 0
            fi
        fi
    fi
    
    return 1
}

# 智能GPU优化
smart_gpu_optimization() {
    step "🚀 智能GPU优化..."
    
    load_deployment_state
    
    if [ "$GPU_OPTIMIZED" = "true" ]; then
        log "✅ GPU已优化，跳过重复设置"
        return 0
    fi
    
    # 执行GPU优化
    if [ -f "deploy/gpu_cleanup.sh" ]; then
        chmod +x deploy/gpu_cleanup.sh
        if ./deploy/gpu_cleanup.sh --optimize-only; then
            update_deployment_state "GPU_OPTIMIZED" "true"
            log "✅ GPU优化完成"
            return 0
        fi
    fi
    
    return 1
}

# 显示优化效果
show_optimization_summary() {
    step "📊 部署优化总结..."
    
    load_deployment_state
    
    echo ""
    echo "🎯 优化效果:"
    echo "  • 环境检查: $([ "$ENVIRONMENT_SETUP" = "true" ] && echo "✅ 已优化" || echo "❌ 需要检查")"
    echo "  • 依赖检查: $([ "$DEPENDENCIES_CHECKED" = "true" ] && echo "✅ 已优化" || echo "❌ 需要检查")"
    echo "  • GPU优化: $([ "$GPU_OPTIMIZED" = "true" ] && echo "✅ 已优化" || echo "❌ 需要优化")"
    echo ""
    echo "💡 优化建议:"
    echo "  • 使用 --reset 重置所有状态"
    echo "  • 使用 --status 查看当前状态"
    echo "  • 定期清理 .deployment_state 文件"
    echo ""
}

# 重置部署状态
reset_deployment_state() {
    step "🔄 重置部署状态..."
    
    rm -f .deployment_state .deps_checked
    log "✅ 部署状态已重置"
}

# 显示当前状态
show_deployment_status() {
    step "📋 当前部署状态..."
    
    load_deployment_state
    
    echo ""
    echo "📊 部署状态:"
    echo "  • 环境设置: $ENVIRONMENT_SETUP"
    echo "  • 依赖检查: $DEPENDENCIES_CHECKED"
    echo "  • GPU优化: $GPU_OPTIMIZED"
    echo "  • 训练就绪: $TRAINING_READY"
    
    if [ -f ".deployment_state" ]; then
        echo "  • 最后更新: $(grep LAST_SETUP .deployment_state | cut -d'=' -f2)"
    fi
    echo ""
}

# 显示使用说明
show_usage() {
    echo "ERD项目部署优化脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --optimize    执行智能优化部署"
    echo "  --status      显示当前部署状态"
    echo "  --reset       重置所有部署状态"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "优化功能:"
    echo "  • 避免重复环境检查"
    echo "  • 智能依赖包检查"
    echo "  • GPU优化状态跟踪"
    echo "  • 部署状态持久化"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --optimize)
            echo -e "${BLUE}"
            echo "🚀 ERD项目智能部署优化"
            echo "================================"
            echo -e "${NC}"
            
            create_deployment_state
            
            if smart_env_check && \
               smart_dependency_check && \
               smart_gpu_optimization; then
                
                update_deployment_state "TRAINING_READY" "true"
                show_optimization_summary
                log "✅ 智能部署优化完成"
            else
                error "❌ 部署优化失败"
                exit 1
            fi
            ;;
        --status)
            show_deployment_status
            ;;
        --reset)
            reset_deployment_state
            ;;
        --help|"")
            show_usage
            ;;
        *)
            error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
