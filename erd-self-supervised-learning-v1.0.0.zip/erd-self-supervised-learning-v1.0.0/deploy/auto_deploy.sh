#!/bin/bash

# ERD自监督学习项目自动化部署脚本
# 作者：Claude 4.0 sonnet
# 功能：本地打包 → 上传服务器 → 解压 → 训练 → 清理

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# 配置文件路径
CONFIG_FILE="$SCRIPT_DIR/deploy_config.conf"

# 默认配置
DEFAULT_CONFIG="# ERD自动部署配置文件
# 服务器连接配置
SERVER_HOST=your-server.com
SERVER_USER=root
SERVER_PORT=22
SERVER_PASSWORD=
USE_SSH_KEY=true

# 服务器路径配置
SERVER_BASE_PATH=/root/lanyun-tmp
SERVER_PROJECT_NAME=erd
SERVER_FULL_PATH=\${SERVER_BASE_PATH}/\${SERVER_PROJECT_NAME}

# 训练配置
MAX_SAMPLES=8000
GPU_DEVICE=0
ENABLE_RTX4090_OPT=true

# 部署选项
AUTO_START_TRAINING=true
AUTO_CLEANUP_LOCAL=true
KEEP_REMOTE_BACKUP=true
FORCE_REINSTALL=false

# SSH选项
SSH_OPTS=\"-o StrictHostKeyChecking=no -o ConnectTimeout=30\"
"

log_info() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 创建默认配置文件
create_default_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        log_info "创建默认配置文件: $CONFIG_FILE"
        echo "$DEFAULT_CONFIG" > "$CONFIG_FILE"
        log_warn "请编辑配置文件后重新运行: vim $CONFIG_FILE"
        return 1
    fi
    return 0
}

# 加载配置文件
load_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        log_error "配置文件不存在: $CONFIG_FILE"
        return 1
    fi
    
    log_info "加载配置文件: $CONFIG_FILE"
    source "$CONFIG_FILE"
    
    # 验证必要配置
    if [ -z "$SERVER_HOST" ] || [ "$SERVER_HOST" = "your-server.com" ]; then
        log_error "请配置正确的服务器地址"
        return 1
    fi
    
    return 0
}

# 显示配置信息
show_config() {
    echo -e "${CYAN}📋 当前部署配置${NC}"
    echo "================================"
    echo "🌐 服务器信息:"
    echo "  • 主机: $SERVER_HOST"
    echo "  • 用户: $SERVER_USER"
    echo "  • 端口: $SERVER_PORT"
    echo "  • 路径: $SERVER_FULL_PATH"
    echo ""
    echo "🔧 部署选项:"
    echo "  • 自动开始训练: $AUTO_START_TRAINING"
    echo "  • 自动清理本地: $AUTO_CLEANUP_LOCAL"
    echo "  • 保留远程备份: $KEEP_REMOTE_BACKUP"
    echo "  • 强制重新安装: $FORCE_REINSTALL"
    echo ""
    echo "🧠 训练配置:"
    echo "  • 训练样本数: $MAX_SAMPLES"
    echo "  • GPU设备: $GPU_DEVICE"
    echo "  • RTX4090优化: $ENABLE_RTX4090_OPT"
    echo ""
}

# 测试服务器连接
test_server_connection() {
    log_step "🔍 测试服务器连接..."
    
    local ssh_cmd=""
    if [ "$USE_SSH_KEY" = "true" ]; then
        ssh_cmd="ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    else
        if [ -z "$SERVER_PASSWORD" ]; then
            log_error "未配置服务器密码且未启用SSH密钥"
            return 1
        fi
        if ! command -v sshpass &> /dev/null; then
            log_error "需要安装sshpass: sudo apt-get install sshpass"
            return 1
        fi
        ssh_cmd="sshpass -p '$SERVER_PASSWORD' ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    fi
    
    if eval "$ssh_cmd 'echo \"连接测试成功\"'" 2>/dev/null; then
        log_info "✅ 服务器连接测试成功"
        return 0
    else
        log_error "❌ 服务器连接测试失败"
        return 1
    fi
}

# 本地打包
local_package() {
    log_step "📦 本地打包项目..."
    
    cd "$PROJECT_DIR"
    
    # 执行打包脚本
    if [ -f "package_project.sh" ]; then
        log_info "执行打包脚本..."
        if ./package_project.sh; then
            log_info "✅ 项目打包完成"
            return 0
        else
            log_error "❌ 项目打包失败"
            return 1
        fi
    else
        log_error "打包脚本不存在: package_project.sh"
        return 1
    fi
}

# 上传到服务器
upload_to_server() {
    log_step "📤 上传项目到服务器..."
    
    cd "$PROJECT_DIR"
    
    # 查找打包文件
    local package_file=$(ls erd-self-supervised-learning-*.tar.gz 2>/dev/null | head -1)
    if [ -z "$package_file" ]; then
        log_error "未找到打包文件"
        return 1
    fi
    
    log_info "上传文件: $package_file"
    
    # 构建上传命令
    local upload_cmd=""
    if [ "$USE_SSH_KEY" = "true" ]; then
        upload_cmd="scp -P $SERVER_PORT $SSH_OPTS $package_file $SERVER_USER@$SERVER_HOST:$SERVER_BASE_PATH/"
    else
        upload_cmd="sshpass -p '$SERVER_PASSWORD' scp -P $SERVER_PORT $SSH_OPTS $package_file $SERVER_USER@$SERVER_HOST:$SERVER_BASE_PATH/"
    fi
    
    if eval "$upload_cmd"; then
        log_info "✅ 文件上传成功"
        export UPLOADED_FILE="$package_file"
        return 0
    else
        log_error "❌ 文件上传失败"
        return 1
    fi
}

# 服务器端部署
deploy_on_server() {
    log_step "🚀 服务器端部署..."
    
    # 构建SSH命令
    local ssh_cmd=""
    if [ "$USE_SSH_KEY" = "true" ]; then
        ssh_cmd="ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    else
        ssh_cmd="sshpass -p '$SERVER_PASSWORD' ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    fi
    
    # 服务器端部署脚本
    local deploy_script="
        # 创建基础目录（如果不存在）
        echo '创建服务器目录...'
        mkdir -p $SERVER_BASE_PATH
        cd $SERVER_BASE_PATH

        # 备份现有项目
        if [ '$KEEP_REMOTE_BACKUP' = 'true' ] && [ -d '$SERVER_PROJECT_NAME' ]; then
            echo '备份现有项目...'
            mv $SERVER_PROJECT_NAME ${SERVER_PROJECT_NAME}_backup_\$(date +%Y%m%d_%H%M%S)
        fi
        
        # 解压新项目
        echo '解压项目文件...'
        tar -xzf $UPLOADED_FILE
        
        # 重命名项目目录
        project_dir=\$(ls -d erd-self-supervised-learning-* | head -1)
        if [ -n \"\$project_dir\" ]; then
            mv \"\$project_dir\" $SERVER_PROJECT_NAME
            echo \"项目目录重命名为: $SERVER_PROJECT_NAME\"
        else
            echo \"错误: 未找到解压的项目目录\"
            exit 1
        fi
        
        # 进入项目目录
        cd $SERVER_PROJECT_NAME
        
        # 设置执行权限
        chmod +x deploy/*.sh
        chmod +x *.sh 2>/dev/null || true
        
        # 环境部署
        echo '开始环境部署...'
        if [ '$FORCE_REINSTALL' = 'true' ]; then
            rm -rf erd_env 2>/dev/null || true
        fi
        
        ./deploy/setup_server.sh
        
        if [ \$? -eq 0 ]; then
            echo '✅ 环境部署成功'
        else
            echo '❌ 环境部署失败'
            exit 1
        fi
        
        # 清理上传的压缩包
        rm -f $SERVER_BASE_PATH/$UPLOADED_FILE
        
        echo '✅ 服务器端部署完成'
    "
    
    if eval "$ssh_cmd '$deploy_script'"; then
        log_info "✅ 服务器端部署成功"
        return 0
    else
        log_error "❌ 服务器端部署失败"
        return 1
    fi
}

# 启动训练
start_remote_training() {
    if [ "$AUTO_START_TRAINING" != "true" ]; then
        log_info "跳过自动启动训练"
        return 0
    fi
    
    log_step "🧠 启动远程训练..."
    
    # 构建SSH命令
    local ssh_cmd=""
    if [ "$USE_SSH_KEY" = "true" ]; then
        ssh_cmd="ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    else
        ssh_cmd="sshpass -p '$SERVER_PASSWORD' ssh -p $SERVER_PORT $SSH_OPTS $SERVER_USER@$SERVER_HOST"
    fi
    
    # 训练启动脚本
    local training_script="
        cd $SERVER_FULL_PATH
        
        # 设置训练参数
        export CUDA_VISIBLE_DEVICES=$GPU_DEVICE
        
        if [ '$ENABLE_RTX4090_OPT' = 'true' ]; then
            export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512
        fi
        
        # 启动训练
        echo '启动后台训练...'
        ./deploy/train_on_server.sh
        
        if [ \$? -eq 0 ]; then
            echo '✅ 训练启动成功'
            echo '监控命令: ./deploy/monitor_training.sh'
        else
            echo '❌ 训练启动失败'
            exit 1
        fi
    "
    
    if eval "$ssh_cmd '$training_script'"; then
        log_info "✅ 远程训练启动成功"
        return 0
    else
        log_error "❌ 远程训练启动失败"
        return 1
    fi
}

# 清理本地文件
cleanup_local() {
    if [ "$AUTO_CLEANUP_LOCAL" != "true" ]; then
        log_info "跳过本地清理"
        return 0
    fi
    
    log_step "🧹 清理本地文件..."
    
    cd "$PROJECT_DIR"
    
    # 删除打包文件
    local package_files=$(ls erd-self-supervised-learning-*.tar.gz erd-self-supervised-learning-*.zip 2>/dev/null)
    if [ -n "$package_files" ]; then
        log_info "删除本地打包文件..."
        rm -f $package_files
        log_info "✅ 本地清理完成"
    else
        log_info "无需清理本地文件"
    fi
    
    return 0
}

# 显示部署结果
show_deployment_result() {
    echo ""
    echo -e "${GREEN}🎉 自动化部署完成！${NC}"
    echo "================================"
    echo ""
    echo "📊 部署信息:"
    echo "  • 服务器: $SERVER_HOST:$SERVER_PORT"
    echo "  • 项目路径: $SERVER_FULL_PATH"
    echo "  • 训练状态: $([ "$AUTO_START_TRAINING" = "true" ] && echo "已启动" || echo "未启动")"
    echo ""
    echo "🔧 远程管理命令:"

    local ssh_prefix=""
    if [ "$USE_SSH_KEY" = "true" ]; then
        ssh_prefix="ssh -p $SERVER_PORT $SERVER_USER@$SERVER_HOST"
    else
        ssh_prefix="sshpass -p '$SERVER_PASSWORD' ssh -p $SERVER_PORT $SERVER_USER@$SERVER_HOST"
    fi

    echo "  # 连接服务器"
    echo "  $ssh_prefix"
    echo ""
    echo "  # 监控训练（连接后执行）"
    echo "  cd $SERVER_FULL_PATH && ./deploy/monitor_training.sh"
    echo ""
    echo "  # 查看日志（连接后执行）"
    echo "  cd $SERVER_FULL_PATH && tail -f logs/training.log"
    echo ""
    echo "  # 停止训练（连接后执行）"
    echo "  cd $SERVER_FULL_PATH && kill \$(cat logs/train.pid)"
    echo ""

    if [ "$AUTO_START_TRAINING" = "true" ]; then
        echo "🎯 预计训练时间: 3-4小时"
        echo "📈 预期效果: 直接关系查询85-90%准确率"
    else
        echo "🚀 手动启动训练:"
        echo "  cd $SERVER_FULL_PATH && ./deploy/train_on_server.sh"
    fi
    echo ""
}

# 显示使用说明
show_usage() {
    echo "ERD自监督学习项目自动化部署脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --config      显示当前配置"
    echo "  --test        测试服务器连接"
    echo "  --deploy      执行完整自动部署"
    echo "  --package     仅本地打包"
    echo "  --upload      仅上传到服务器"
    echo "  --init        创建默认配置文件"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "完整部署流程:"
    echo "  1. $0 --init          # 创建配置文件"
    echo "  2. vim $CONFIG_FILE   # 编辑配置"
    echo "  3. $0 --test          # 测试连接"
    echo "  4. $0 --deploy        # 自动部署"
    echo ""
    echo "配置文件: $CONFIG_FILE"
    echo ""
}

# 主函数
main() {
    echo -e "${CYAN}"
    echo "🚀 ERD自监督学习项目自动化部署"
    echo "================================"
    echo "本地打包 → 上传服务器 → 解压 → 训练 → 清理"
    echo -e "${NC}"

    case "${1:-}" in
        --init)
            create_default_config
            if [ $? -eq 0 ]; then
                log_info "✅ 默认配置文件已存在"
                show_config
            fi
            ;;
        --config)
            if load_config; then
                show_config
            fi
            ;;
        --test)
            if load_config && test_server_connection; then
                log_info "✅ 服务器连接正常，可以执行部署"
            else
                log_error "❌ 服务器连接失败，请检查配置"
                exit 1
            fi
            ;;
        --package)
            if local_package; then
                log_info "✅ 本地打包完成"
            else
                exit 1
            fi
            ;;
        --upload)
            if load_config && test_server_connection && upload_to_server; then
                log_info "✅ 文件上传完成"
            else
                exit 1
            fi
            ;;
        --deploy)
            # 完整自动部署流程
            if ! create_default_config; then
                exit 1
            fi

            if ! load_config; then
                exit 1
            fi

            show_config
            echo ""
            echo "即将开始自动部署，按Enter继续，Ctrl+C取消..."
            read -r

            if test_server_connection && \
               local_package && \
               upload_to_server && \
               deploy_on_server && \
               start_remote_training && \
               cleanup_local; then

                show_deployment_result
                log_info "✅ 自动化部署成功完成"
            else
                log_error "❌ 自动化部署失败"
                exit 1
            fi
            ;;
        --help|"")
            show_usage
            ;;
        *)
            log_error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
