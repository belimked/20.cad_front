#!/bin/bash

# ERD项目服务器目录创建脚本
# 作者：Claude 4.0 sonnet
# 功能：在服务器上创建 /root/lanyun-tmp/erd/ 目录结构

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 创建目录结构
create_directories() {
    step "📁 创建服务器目录结构..."
    
    # 基础目录
    local base_dir="/root/lanyun-tmp"
    local project_dir="/root/lanyun-tmp/erd"
    
    # 创建基础目录
    if [ ! -d "$base_dir" ]; then
        log "创建基础目录: $base_dir"
        mkdir -p "$base_dir"
        chmod 755 "$base_dir"
    else
        log "基础目录已存在: $base_dir"
    fi
    
    # 创建项目目录
    if [ ! -d "$project_dir" ]; then
        log "创建项目目录: $project_dir"
        mkdir -p "$project_dir"
        chmod 755 "$project_dir"
    else
        log "项目目录已存在: $project_dir"
    fi
    
    # 创建子目录
    local subdirs=(
        "logs"
        "data/erd"
        "data/generated"
        "data/models"
        "cache/huggingface"
        "backup"
    )
    
    for subdir in "${subdirs[@]}"; do
        local full_path="$project_dir/$subdir"
        if [ ! -d "$full_path" ]; then
            log "创建子目录: $full_path"
            mkdir -p "$full_path"
            chmod 755 "$full_path"
        else
            log "子目录已存在: $full_path"
        fi
    done
    
    return 0
}

# 设置目录权限
set_permissions() {
    step "🔧 设置目录权限..."
    
    local project_dir="/root/lanyun-tmp/erd"
    
    # 设置所有者
    chown -R root:root "/root/lanyun-tmp"
    
    # 设置权限
    find "/root/lanyun-tmp" -type d -exec chmod 755 {} \;
    find "/root/lanyun-tmp" -type f -exec chmod 644 {} \;
    
    log "✅ 目录权限设置完成"
    
    return 0
}

# 创建目录说明文件
create_readme() {
    step "📝 创建目录说明..."
    
    local readme_file="/root/lanyun-tmp/erd/README_DIRECTORY.md"
    
    cat > "$readme_file" << 'EOF'
# ERD自监督学习项目目录说明

## 📁 目录结构

```
/root/lanyun-tmp/erd/
├── README_DIRECTORY.md          # 本说明文件
├── src/                         # 源代码目录
├── config/                      # 配置文件
├── examples/                    # 示例脚本
├── deploy/                      # 部署脚本
├── data/                        # 数据目录
│   ├── erd/                     # ERD文件
│   ├── generated/               # 生成的训练数据
│   └── models/                  # 训练好的模型
├── logs/                        # 日志文件
├── cache/                       # 缓存目录
│   └── huggingface/             # HuggingFace模型缓存
├── backup/                      # 备份目录
├── erd_env/                     # Python虚拟环境（自动创建）
└── erd_env_config.sh            # 环境配置脚本（自动创建）
```

## 🎯 项目信息

- **项目名称**: ERD自监督学习系统
- **基础模型**: Qwen2.5-3B-Instruct
- **数据规模**: 63张表，1330个字段，38个关系
- **训练样本**: 8000个（自动生成）
- **预计训练时间**: 3-4小时（RTX 4090）

## 🚀 快速使用

```bash
# 进入项目目录
cd /root/lanyun-tmp/erd

# 激活环境
source erd_env_config.sh

# 开始训练
./deploy/train_on_server.sh

# 监控训练
./deploy/monitor_training.sh
```

## 📊 文件说明

### 重要文件
- `logs/training.log`: 训练日志
- `logs/train.pid`: 训练进程ID
- `data/erd/cost_erd.json`: ERD数据文件
- `data/models/final_model/`: 最终训练模型

### 配置文件
- `config/qwen_3b_config.yaml`: 模型训练配置
- `erd_env_config.sh`: 环境变量配置

### 脚本文件
- `deploy/train_on_server.sh`: 训练启动脚本
- `deploy/monitor_training.sh`: 训练监控脚本
- `quick_train_miniconda.sh`: 快速训练脚本（Miniconda版）

## 🔧 维护说明

- 定期清理 `cache/` 目录中的临时文件
- 备份重要的训练模型到 `backup/` 目录
- 日志文件会自动轮转，无需手动清理

创建时间: $(date '+%Y-%m-%d %H:%M:%S')
EOF
    
    chmod 644 "$readme_file"
    log "✅ 目录说明文件已创建: $readme_file"
    
    return 0
}

# 显示目录信息
show_directory_info() {
    step "📊 目录信息总览..."
    
    local project_dir="/root/lanyun-tmp/erd"
    
    echo ""
    echo "📁 创建的目录结构:"
    echo "================================"
    
    if command -v tree &> /dev/null; then
        tree -L 3 "$project_dir" 2>/dev/null || ls -la "$project_dir"
    else
        find "$project_dir" -type d | head -20 | sort
    fi
    
    echo ""
    echo "💾 磁盘使用情况:"
    echo "================================"
    df -h "$project_dir"
    
    echo ""
    echo "🔧 目录权限:"
    echo "================================"
    ls -la "/root/lanyun-tmp/"
    
    echo ""
    log "✅ 服务器目录创建完成"
    log "项目路径: $project_dir"
    
    return 0
}

# 主函数
main() {
    echo -e "${BLUE}"
    echo "📁 ERD项目服务器目录创建"
    echo "================================"
    echo "目标路径: /root/lanyun-tmp/erd/"
    echo -e "${NC}"
    
    if create_directories && \
       set_permissions && \
       create_readme && \
       show_directory_info; then
        
        log "✅ 目录创建成功完成"
        return 0
    else
        echo "❌ 目录创建失败"
        return 1
    fi
}

# 脚本入口
main "$@"
