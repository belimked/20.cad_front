#!/bin/bash

# ERD项目Python路径检测脚本
# 作者：Claude 4.0 sonnet
# 功能：智能检测并返回正确的Python命令路径

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# 检测Python路径
detect_python_path() {
    local python_cmd=""
    local python_type=""
    
    # 1. 优先检测Miniconda
    if [ -f "/root/miniconda/bin/python" ]; then
        python_cmd="/root/miniconda/bin/python"
        python_type="miniconda"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        python_cmd="/root/miniconda3/bin/python"
        python_type="miniconda3"
    
    # 2. 检查虚拟环境中的python
    elif [ -f "erd_env/bin/python" ]; then
        python_cmd="$(pwd)/erd_env/bin/python"
        python_type="venv"
    
    # 3. 检查系统python3
    elif command -v python3 &> /dev/null; then
        python_cmd="python3"
        python_type="system_python3"
    
    # 4. 检查系统python
    elif command -v python &> /dev/null; then
        python_cmd="python"
        python_type="system_python"
    
    else
        echo -e "${RED}❌ 未找到可用的Python解释器${NC}" >&2
        return 1
    fi
    
    # 验证Python版本
    local python_version=$($python_cmd --version 2>&1)
    if [[ $python_version == *"Python 3."* ]]; then
        if [ "$1" = "--verbose" ]; then
            echo -e "${GREEN}✅ 检测到Python: $python_cmd${NC}" >&2
            echo -e "${GREEN}   类型: $python_type${NC}" >&2
            echo -e "${GREEN}   版本: $python_version${NC}" >&2
        fi
        echo "$python_cmd"
        return 0
    else
        echo -e "${RED}❌ Python版本不兼容: $python_version${NC}" >&2
        return 1
    fi
}

# 设置Python环境变量
set_python_env() {
    local python_cmd=$(detect_python_path)
    if [ $? -eq 0 ]; then
        export PYTHON_CMD="$python_cmd"
        export ERD_PYTHON_PATH="$python_cmd"
        
        # 根据Python类型设置环境
        if [[ "$python_cmd" == *"miniconda"* ]]; then
            # Miniconda环境
            if [ -f "/root/miniconda/etc/profile.d/conda.sh" ]; then
                source /root/miniconda/etc/profile.d/conda.sh
            elif [ -f "/root/miniconda3/etc/profile.d/conda.sh" ]; then
                source /root/miniconda3/etc/profile.d/conda.sh
            fi
        elif [[ "$python_cmd" == *"erd_env"* ]]; then
            # 虚拟环境
            if [ -f "erd_env/bin/activate" ]; then
                source erd_env/bin/activate
            fi
        fi
        
        return 0
    else
        return 1
    fi
}

# 创建Python启动脚本
create_python_wrapper() {
    local python_cmd=$(detect_python_path)
    if [ $? -eq 0 ]; then
        cat > python_wrapper.sh << EOF
#!/bin/bash
# ERD项目Python包装脚本
# 自动检测并使用正确的Python路径

# 设置Python路径
PYTHON_CMD="$python_cmd"

# 设置环境
if [[ "$python_cmd" == *"miniconda"* ]]; then
    if [ -f "/root/miniconda/etc/profile.d/conda.sh" ]; then
        source /root/miniconda/etc/profile.d/conda.sh
    elif [ -f "/root/miniconda3/etc/profile.d/conda.sh" ]; then
        source /root/miniconda3/etc/profile.d/conda.sh
    fi
elif [[ "$python_cmd" == *"erd_env"* ]]; then
    if [ -f "erd_env/bin/activate" ]; then
        source erd_env/bin/activate
    fi
fi

# 执行Python命令
exec "\$PYTHON_CMD" "\$@"
EOF
        chmod +x python_wrapper.sh
        echo "python_wrapper.sh"
        return 0
    else
        return 1
    fi
}

# 测试Python环境
test_python_env() {
    local python_cmd=$(detect_python_path --verbose)
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}🔍 测试Python环境...${NC}"
        
        # 测试基本功能
        if $python_cmd -c "print('Python基本功能正常')" 2>/dev/null; then
            echo -e "${GREEN}✅ Python基本功能测试通过${NC}"
        else
            echo -e "${RED}❌ Python基本功能测试失败${NC}"
            return 1
        fi
        
        # 测试关键模块
        local modules=("torch" "transformers" "peft")
        for module in "${modules[@]}"; do
            if $python_cmd -c "import $module; print(f'$module 版本: {$module.__version__}')" 2>/dev/null; then
                echo -e "${GREEN}✅ $module 模块可用${NC}"
            else
                echo -e "${YELLOW}⚠️  $module 模块不可用${NC}"
            fi
        done
        
        return 0
    else
        return 1
    fi
}

# 显示使用说明
show_usage() {
    echo "ERD项目Python路径检测脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --detect      检测Python路径"
    echo "  --verbose     详细输出检测过程"
    echo "  --set-env     设置Python环境变量"
    echo "  --wrapper     创建Python包装脚本"
    echo "  --test        测试Python环境"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 --detect                    # 检测Python路径"
    echo "  $0 --verbose                   # 详细检测过程"
    echo "  PYTHON_CMD=\$($0 --detect)     # 获取Python命令"
    echo "  source <($0 --set-env)         # 设置环境变量"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --detect)
            detect_python_path
            ;;
        --verbose)
            detect_python_path --verbose
            ;;
        --set-env)
            if set_python_env; then
                echo "export PYTHON_CMD=\"$PYTHON_CMD\""
                echo "export ERD_PYTHON_PATH=\"$ERD_PYTHON_PATH\""
            else
                return 1
            fi
            ;;
        --wrapper)
            create_python_wrapper
            ;;
        --test)
            test_python_env
            ;;
        --help|"")
            show_usage
            ;;
        *)
            echo -e "${RED}未知选项: $1${NC}" >&2
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
