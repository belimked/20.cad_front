#!/bin/bash

# ERD项目GPU清理集成脚本
# 作者：Claude 4.0 sonnet
# 功能：集成GPU内存清理到训练流程

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%H:%M:%S')]${NC} $1"
}

step() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

# 检查GPU状态
check_gpu_status() {
    step "📊 检查GPU状态..."
    
    if ! command -v nvidia-smi &> /dev/null; then
        warn "⚠️  nvidia-smi不可用，跳过GPU检查"
        return 1
    fi
    
    # 显示GPU基本信息
    local gpu_info=$(nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv,noheader,nounits 2>/dev/null)
    log "GPU信息: $gpu_info"
    
    # 检查GPU进程
    local gpu_processes=$(nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader 2>/dev/null)
    if [ -n "$gpu_processes" ]; then
        warn "⚠️  检测到GPU进程:"
        echo "$gpu_processes" | while read line; do
            echo "    $line"
        done
        return 1
    else
        log "✅ GPU空闲，无进程占用"
        return 0
    fi
}

# 强制清理GPU
force_clear_gpu() {
    step "🔥 强制清理GPU内存..."
    
    # 1. 杀死训练相关进程
    log "清理训练进程..."
    pkill -f "train_model" 2>/dev/null || true
    pkill -f "python.*train" 2>/dev/null || true
    pkill -f "torchrun" 2>/dev/null || true
    pkill -f "torch.*distributed" 2>/dev/null || true
    pkill -f "transformers" 2>/dev/null || true
    
    # 2. 清理GPU设备文件
    log "清理GPU设备文件..."
    if command -v fuser &> /dev/null; then
        sudo fuser -k /dev/nvidia* 2>/dev/null || true
        log "✅ fuser清理完成"
    else
        warn "⚠️  fuser命令不可用"
    fi
    
    # 3. 清理缓存文件
    log "清理缓存文件..."
    
    # PyTorch缓存
    if [ -d "$HOME/.cache/torch" ]; then
        rm -rf "$HOME/.cache/torch"/* 2>/dev/null || true
        log "✅ PyTorch缓存已清理"
    fi
    
    # HuggingFace缓存
    if [ -d "$HOME/.cache/huggingface" ]; then
        rm -rf "$HOME/.cache/huggingface/transformers/*/tmp*" 2>/dev/null || true
        rm -rf "$HOME/.cache/huggingface/hub/*/tmp*" 2>/dev/null || true
        log "✅ HuggingFace临时文件已清理"
    fi
    
    # 项目缓存
    if [ -d "./cache" ]; then
        rm -rf "./cache/huggingface/transformers/*/tmp*" 2>/dev/null || true
        log "✅ 项目缓存已清理"
    fi
    
    # 系统临时文件
    rm -rf /tmp/torch_* 2>/dev/null || true
    rm -rf /tmp/transformers_* 2>/dev/null || true
    rm -rf /tmp/pytorch_* 2>/dev/null || true
    log "✅ 系统临时文件已清理"
    
    # 4. 清理Python缓存
    log "清理Python缓存..."
    find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
    find . -name "*.pyc" -delete 2>/dev/null || true
    find . -name "*.pyo" -delete 2>/dev/null || true
    log "✅ Python缓存已清理"
    
    # 5. 等待清理生效
    log "等待清理生效..."
    sleep 5
    
    return 0
}

# 智能GPU清理
smart_clear_gpu() {
    step "🧠 智能GPU清理..."
    
    # 首先检查GPU状态
    if check_gpu_status; then
        log "✅ GPU已空闲，无需清理"
        return 0
    fi
    
    # 尝试使用项目的GPU清理脚本
    if [ -f "examples/shell/clear_gpu_memory.sh" ]; then
        log "使用项目GPU清理脚本..."
        chmod +x examples/shell/clear_gpu_memory.sh
        ./examples/shell/clear_gpu_memory.sh true
        
        # 检查清理效果
        sleep 3
        if check_gpu_status; then
            log "✅ 项目脚本清理成功"
            return 0
        else
            warn "⚠️  项目脚本清理不完全，使用强制清理"
        fi
    else
        log "未找到项目GPU清理脚本，使用内置清理"
    fi
    
    # 使用强制清理
    force_clear_gpu
    
    # 最终检查
    sleep 3
    if check_gpu_status; then
        log "✅ GPU清理成功"
        return 0
    else
        warn "⚠️  GPU清理不完全，但将继续训练"
        return 0
    fi
}

# 设置GPU优化参数
setup_gpu_optimization() {
    step "⚡ 设置GPU优化参数..."
    
    # RTX 4090优化
    if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
        log "检测到RTX 4090，启用优化配置"
        export PYTORCH_CUDA_ALLOC_CONF="max_split_size_mb:512"
        export CUDA_LAUNCH_BLOCKING="0"
        export TORCH_CUDNN_V8_API_ENABLED="1"
        log "✅ RTX 4090优化配置已启用"
    else
        log "使用通用GPU优化配置"
        export PYTORCH_CUDA_ALLOC_CONF="max_split_size_mb:256"
    fi
    
    # 通用优化
    export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
    export TOKENIZERS_PARALLELISM="false"
    export OMP_NUM_THREADS="4"
    
    log "✅ GPU优化参数设置完成"
    return 0
}

# 显示GPU信息
show_gpu_info() {
    step "📊 GPU环境信息..."
    
    if ! command -v nvidia-smi &> /dev/null; then
        warn "⚠️  nvidia-smi不可用"
        return 1
    fi
    
    echo ""
    echo "GPU硬件信息:"
    nvidia-smi --query-gpu=index,name,memory.total,driver_version --format=csv,header
    
    echo ""
    echo "GPU使用情况:"
    nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv,header
    
    echo ""
    echo "GPU进程:"
    nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,header
    
    echo ""
    echo "环境变量:"
    echo "  CUDA_VISIBLE_DEVICES: ${CUDA_VISIBLE_DEVICES:-未设置}"
    echo "  PYTORCH_CUDA_ALLOC_CONF: ${PYTORCH_CUDA_ALLOC_CONF:-未设置}"
    echo "  CUDA_LAUNCH_BLOCKING: ${CUDA_LAUNCH_BLOCKING:-未设置}"
    
    return 0
}

# 显示使用说明
show_usage() {
    echo "ERD项目GPU清理集成脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  --check       检查GPU状态"
    echo "  --clear       智能清理GPU"
    echo "  --force       强制清理GPU"
    echo "  --optimize    设置GPU优化参数"
    echo "  --info        显示GPU信息"
    echo "  --auto        自动模式（清理+优化）"
    echo "  --help        显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 --auto        # 自动清理并优化"
    echo "  $0 --clear       # 智能清理GPU"
    echo "  $0 --info        # 显示GPU信息"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --check)
            check_gpu_status
            ;;
        --clear)
            smart_clear_gpu
            ;;
        --force)
            force_clear_gpu
            ;;
        --optimize)
            setup_gpu_optimization
            ;;
        --info)
            show_gpu_info
            ;;
        --auto)
            echo -e "${BLUE}"
            echo "🔥 ERD项目GPU自动清理和优化"
            echo "================================"
            echo -e "${NC}"
            
            smart_clear_gpu
            setup_gpu_optimization
            show_gpu_info
            
            log "✅ GPU自动清理和优化完成"
            ;;
        --help|"")
            show_usage
            ;;
        *)
            error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
