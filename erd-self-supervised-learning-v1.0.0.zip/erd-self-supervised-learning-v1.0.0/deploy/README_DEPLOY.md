# ERD自监督学习项目 - 服务器部署指南

## 🎯 项目概述
基于63张真实企业数据库表的ERD自监督学习系统，使用Qwen2.5-3B模型，能够自动学习表关联关系并回答相关查询。

**项目特色**：
- ✅ **零人工标注**：完全基于ERD结构自动学习
- ✅ **真实数据**：63张企业级数据库表，1330个字段
- ✅ **轻量高效**：基于Qwen2.5-3B，适配RTX 4090
- ✅ **专业部署**：参考vLLM部署脚本，支持智能检测和优化

## 📊 数据规模
- **表数量**: 63张
- **字段总数**: 1330个
- **关系数量**: 38个
- **训练样本**: 8000个（自动生成）
- **预计训练时间**: 3-4小时（RTX 4090）

## 🚀 快速部署（推荐）

### 方法一：一键部署
```bash
# 1. 解压项目
tar -xzf erd-self-supervised-learning-v1.0.0.tar.gz
cd erd-self-supervised-learning-v1.0.0

# 2. 快速开始（自动化部署）
./quick_start.sh

# 3. 按提示操作
./deploy/setup_server.sh      # 环境设置
./deploy/train_on_server.sh   # 开始训练
./deploy/monitor_training.sh  # 监控训练
```

### 方法二：配置化部署
```bash
# 1. 配置服务器信息
vim deploy/server_config.sh  # 修改服务器配置

# 2. 测试连接
./deploy/server_config.sh --test

# 3. 检测环境
./deploy/server_config.sh --detect

# 4. 执行部署
./deploy/setup_server.sh
./deploy/train_on_server.sh
```

## 📋 详细部署步骤

### 1. 上传项目文件
```bash
# 上传压缩包
scp erd-self-supervised-learning-v1.0.0.tar.gz user@server:/path/to/upload/

# 或直接上传目录
scp -r erd-self-supervised-learning/ user@server:/path/to/project/
```

### 2. 服务器环境设置
```bash
cd /path/to/project/erd-self-supervised-learning/

# 智能环境设置（自动检测GPU类型和优化配置）
./deploy/setup_server.sh

# 功能包括：
# - 自动检测RTX 4090并启用优化
# - 创建Python虚拟环境
# - 安装优化版本的PyTorch和依赖
# - 设置环境变量和配置
# - 生成快速启动脚本
```

### 3. 开始训练
```bash
# 后台启动训练（推荐）
./deploy/train_on_server.sh

# 或前台训练
./quick_train.sh

# 功能包括：
# - 检查训练前置条件
# - 自动处理已有训练进程
# - 启用RTX 4090优化配置
# - 后台运行并记录PID
```

### 4. 监控训练
```bash
# 综合监控面板（推荐）
./deploy/monitor_training.sh

# 实时日志
tail -f logs/training.log

# GPU监控
watch -n 1 nvidia-smi

# 训练进程状态
ps aux | grep train_model
```

## 📋 服务器要求

### 硬件要求
- **GPU**: RTX 4090 / A100 / V100 (24GB+ 显存)
- **内存**: 32GB+ RAM
- **存储**: 50GB+ 可用空间

### 软件要求
- **操作系统**: Ubuntu 20.04+ / CentOS 8+
- **Python**: 3.8+
- **CUDA**: 11.8+ / 12.0+
- **驱动**: NVIDIA 驱动 520+

## 🔧 配置说明

### 训练配置 (config/qwen_3b_config.yaml)
```yaml
model:
  name: "Qwen/Qwen2.5-3B-Instruct"  # 基础模型
  max_length: 2048                   # 最大序列长度

training:
  batch_size: 16                     # 批次大小
  learning_rate: 2e-4                # 学习率
  max_steps: 1000                    # 最大训练步数
  
hardware:
  mixed_precision: "bf16"            # 混合精度
  gradient_checkpointing: true       # 梯度检查点
```

### 数据配置
- **ERD文件**: `data/erd/cost_erd.json` (63张表)
- **训练样本**: 自动生成8000个样本
- **样本分布**: 40%基础关系 + 30%路径发现 + 20%SQL生成 + 10%负样本

## 📈 训练监控

### 关键指标
- **Loss**: 训练损失（目标 < 1.0）
- **GPU利用率**: 应保持在80%+
- **显存使用**: 约8-12GB
- **训练速度**: 约120 tokens/s

### 日志文件
- `logs/training.log`: 完整训练日志
- `logs/train.pid`: 训练进程ID
- `data/generated/training_data.json`: 生成的训练数据
- `data/models/`: 模型检查点

## 🎯 预期结果

### 性能指标
- **直接关系查询**: 85-90%准确率
- **间接关系推理**: 75-80%准确率  
- **SQL生成**: 70-75%准确率
- **复杂业务逻辑**: 60-65%准确率

### 输出文件
- `data/models/final_model/`: 最终训练模型
- `data/generated/evaluation_results.json`: 评估结果
- `data/erd/cost_erd.stats.json`: ERD统计信息

## 🛠️ 故障排除

### 常见问题

1. **CUDA内存不足**
   ```bash
   # 减少批次大小
   # 修改 config/qwen_3b_config.yaml 中的 batch_size: 8
   ```

2. **依赖安装失败**
   ```bash
   # 使用国内镜像
   pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/
   ```

3. **模型下载慢**
   ```bash
   # 设置HuggingFace镜像
   export HF_ENDPOINT=https://hf-mirror.com
   ```

### 停止训练
```bash
# 优雅停止
kill $(cat logs/train.pid)

# 强制停止
pkill -f train_model.py
```

## 📞 技术支持

如遇问题，请检查：
1. `logs/training.log` 中的错误信息
2. GPU驱动和CUDA版本兼容性
3. Python环境和依赖版本

## 🎉 训练完成后

训练完成后，模型将保存在 `data/models/final_model/` 目录，可用于：
- 表关联关系查询
- SQL生成辅助
- 数据库设计建议
- 业务逻辑分析
