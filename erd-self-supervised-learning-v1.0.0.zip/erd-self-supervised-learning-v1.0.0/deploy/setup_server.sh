#!/bin/bash

# ERD自监督学习项目服务器部署脚本
# 作者：Claude 4.0 sonnet
# 功能：自动化部署ERD训练环境，支持RTX 4090优化

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

log_info() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# 检测系统环境
detect_system_info() {
    log_step "🔍 检测系统环境..."

    # 操作系统信息
    local os_info=$(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d'"' -f2 || echo "Unknown")
    log_info "操作系统: $os_info"

    # Python版本检查 - 优先检查miniconda
    local python_cmd=""
    if [ -f "/root/miniconda/bin/python" ]; then
        python_cmd="/root/miniconda/bin/python"
        log_info "检测到Miniconda Python: $python_cmd"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        python_cmd="/root/miniconda3/bin/python"
        log_info "检测到Miniconda3 Python: $python_cmd"
    elif command -v python3 &> /dev/null; then
        python_cmd="python3"
        log_info "使用系统Python3"
    else
        log_error "❌ 未找到Python，请安装Python3.8+或Miniconda"
        return 1
    fi

    # 设置全局Python命令
    export PYTHON_CMD="$python_cmd"
    local python_version=$($python_cmd --version 2>&1)
    log_info "Python版本: $python_version"

    # CUDA环境检查
    if command -v nvidia-smi &> /dev/null; then
        local gpu_info=$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>/dev/null)
        log_info "GPU信息: $gpu_info"

        # 检查是否为RTX 4090
        if echo "$gpu_info" | grep -q "4090"; then
            log_info "✅ 检测到RTX 4090，将启用优化配置"
            export ERD_GPU_TYPE="RTX_4090"
        else
            log_warn "⚠️  非RTX 4090 GPU，使用通用配置"
            export ERD_GPU_TYPE="GENERIC"
        fi
    else
        log_warn "⚠️  CUDA未检测到，将使用CPU训练（速度较慢）"
        export ERD_GPU_TYPE="CPU"
    fi

    return 0
}

# 创建虚拟环境
setup_python_env() {
    log_step "🐍 设置Python环境..."

    cd "$PROJECT_DIR"

    # 检查是否使用conda环境
    if [[ "$PYTHON_CMD" == *"miniconda"* ]]; then
        log_info "检测到Miniconda，使用conda环境管理..."

        # 检查conda命令
        local conda_cmd=""
        if [ -f "/root/miniconda/bin/conda" ]; then
            conda_cmd="/root/miniconda/bin/conda"
        elif [ -f "/root/miniconda3/bin/conda" ]; then
            conda_cmd="/root/miniconda3/bin/conda"
        else
            log_error "❌ 未找到conda命令"
            return 1
        fi

        # 使用现有conda环境，不创建新环境
        log_info "使用现有conda环境..."
        source $($conda_cmd info --base)/etc/profile.d/conda.sh
        # 不需要激活特定环境，使用当前环境

        # 升级pip
        log_info "升级pip..."
        pip install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com

    else
        # 使用传统venv
        log_info "使用Python venv创建虚拟环境..."

        if [ ! -d "erd_env" ]; then
            log_info "创建Python虚拟环境..."
            $PYTHON_CMD -m venv erd_env
        else
            log_info "虚拟环境已存在，跳过创建"
        fi

        # 激活虚拟环境
        source erd_env/bin/activate

        # 升级pip
        log_info "升级pip..."
        pip install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
    fi

    return 0
}

# 安装依赖包
install_dependencies() {
    log_step "📦 安装项目依赖..."

    cd "$PROJECT_DIR"
    source erd_env/bin/activate

    # 根据GPU类型选择PyTorch版本
    if [ "$ERD_GPU_TYPE" = "RTX_4090" ]; then
        log_info "安装RTX 4090优化版本的PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
    elif [ "$ERD_GPU_TYPE" = "GENERIC" ]; then
        log_info "安装通用CUDA版本的PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
    else
        log_info "安装CPU版本的PyTorch..."
        pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
    fi

    # 安装其他依赖
    log_info "安装其他依赖包..."
    pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com

    return 0
}

# 验证安装
verify_installation() {
    log_step "✅ 验证安装..."

    cd "$PROJECT_DIR"
    source erd_env/bin/activate

    # 检查关键依赖
    log_info "检查PyTorch..."
    python -c "import torch; print(f'PyTorch版本: {torch.__version__}'); print(f'CUDA可用: {torch.cuda.is_available()}')"

    log_info "检查Transformers..."
    python -c "import transformers; print(f'Transformers版本: {transformers.__version__}')"

    log_info "检查PEFT..."
    python -c "import peft; print(f'PEFT版本: {peft.__version__}')"

    # 检查GPU内存
    if [ "$ERD_GPU_TYPE" != "CPU" ]; then
        log_info "检查GPU内存..."
        python -c "import torch; print(f'GPU数量: {torch.cuda.device_count()}'); [print(f'GPU {i}: {torch.cuda.get_device_name(i)} ({torch.cuda.get_device_properties(i).total_memory // 1024**3}GB)') for i in range(torch.cuda.device_count())]"
    fi

    return 0
}

# 设置模型缓存
setup_model_cache() {
    log_step "📦 设置模型缓存..."

    cd "$PROJECT_DIR"

    # 检查模型缓存管理脚本
    if [ -f "deploy/model_cache_manager.sh" ]; then
        chmod +x deploy/model_cache_manager.sh

        # 检查缓存状态
        if ./deploy/model_cache_manager.sh --check; then
            log_info "✅ 模型缓存已存在，跳过下载"
        else
            log_info "🔄 设置模型缓存..."
            if ./deploy/model_cache_manager.sh --setup; then
                log_info "✅ 模型缓存设置完成"
            else
                log_warn "⚠️  模型缓存设置失败，训练时将自动下载"
            fi
        fi
    else
        log_warn "⚠️  模型缓存管理脚本不存在，跳过缓存设置"
    fi

    return 0
}

# 设置环境变量和配置
setup_environment() {
    log_step "🔧 设置环境变量..."

    cd "$PROJECT_DIR"

    # 创建环境配置文件
    cat > erd_env_config.sh << EOF
#!/bin/bash
# ERD训练环境配置

# Python路径
export PYTHONPATH="\${PYTHONPATH}:\$(pwd)/src"

# Python命令配置
export PYTHON_CMD="$PYTHON_CMD"

# 环境激活配置
if [[ "$PYTHON_CMD" == *"miniconda"* ]]; then
    # Miniconda环境
    if [ -f "/root/miniconda/bin/conda" ]; then
        source /root/miniconda/etc/profile.d/conda.sh
    elif [ -f "/root/miniconda3/bin/conda" ]; then
        source /root/miniconda3/etc/profile.d/conda.sh
    fi
    # 使用当前conda环境，不需要激活特定环境
else
    # 传统venv环境
    source erd_env/bin/activate 2>/dev/null || echo "虚拟环境激活失败"
fi

# CUDA配置
export CUDA_VISIBLE_DEVICES=0
export TOKENIZERS_PARALLELISM=false

# HuggingFace配置
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_CACHE=/root/lanyun-tmp/modelscope_cache
export TRANSFORMERS_CACHE=/root/lanyun-tmp/modelscope_cache

# 训练优化配置
if [ "$ERD_GPU_TYPE" = "RTX_4090" ]; then
    export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512
    export CUDA_LAUNCH_BLOCKING=0
fi

# pip镜像配置
export PIP_INDEX_URL="https://mirrors.aliyun.com/pypi/simple/"
export PIP_TRUSTED_HOST="mirrors.aliyun.com"

echo "✅ ERD训练环境已配置"
EOF

    chmod +x erd_env_config.sh

    # 创建必要目录
    log_info "创建目录结构..."
    mkdir -p data/generated
    mkdir -p data/models
    mkdir -p logs
    mkdir -p cache/huggingface
    mkdir -p /root/lanyun-tmp/modelscope_cache

    return 0
}

# 生成快速启动脚本
create_quick_start() {
    log_step "🚀 创建快速启动脚本..."

    cd "$PROJECT_DIR"

    cat > quick_train.sh << EOF
#!/bin/bash
# ERD训练快速启动脚本

# 激活环境
if [ -f "erd_env/bin/activate" ]; then
    source erd_env/bin/activate
fi

if [ -f "erd_env_config.sh" ]; then
    source erd_env_config.sh
fi

echo "🧠 启动ERD自监督学习训练"
echo "=========================="

# 检查ERD文件
if [ ! -f "data/erd/cost_erd.json" ]; then
    echo "❌ ERD文件不存在，请先准备数据"
    exit 1
fi

# 确定Python命令
PYTHON_CMD="python"
if [ -f "/root/miniconda/bin/python" ]; then
    PYTHON_CMD="/root/miniconda/bin/python"
elif [ -f "/root/miniconda3/bin/python" ]; then
    PYTHON_CMD="/root/miniconda3/bin/python"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
fi

# 启动训练
\$PYTHON_CMD examples/train_model.py \\
    --erd_file data/erd/cost_erd.json \\
    --max_samples 8000 \\
    --config config/qwen_3b_config.yaml \\
    --output_dir data/generated

echo "✅ 训练启动完成"
EOF

    chmod +x quick_train.sh

    return 0
}

# 显示部署结果
show_deployment_result() {
    echo ""
    echo -e "${GREEN}🎉 ERD自监督学习环境部署完成！${NC}"
    echo "================================"
    echo ""
    echo "📊 环境信息:"
    echo "  • GPU类型: $ERD_GPU_TYPE"
    echo "  • 项目目录: $PROJECT_DIR"
    echo "  • 虚拟环境: erd_env"
    echo ""
    echo "🚀 快速开始:"
    echo "  ./quick_train.sh                    # 快速训练"
    echo "  ./deploy/train_on_server.sh         # 后台训练"
    echo "  ./deploy/monitor_training.sh        # 监控训练"
    echo ""
    echo "🔧 手动操作:"
    echo "  source erd_env/bin/activate         # 激活环境"
    echo "  source erd_env_config.sh            # 加载配置"
    echo "  python examples/train_model.py ...  # 手动训练"
    echo ""
    echo "📝 日志文件:"
    echo "  logs/training.log                   # 训练日志"
    echo "  logs/setup.log                      # 部署日志"
    echo ""
}

# 主函数
main() {
    echo -e "${CYAN}"
    echo "🚀 ERD自监督学习项目服务器部署"
    echo "================================"
    echo "基于63张真实企业数据库表的自监督学习"
    echo "支持RTX 4090优化，预计训练时间3-4小时"
    echo -e "${NC}"

    # 创建日志文件
    mkdir -p logs
    exec > >(tee -a logs/setup.log)
    exec 2>&1

    # 检测是否为Miniconda环境
    if [ -f "/root/miniconda/bin/python" ] || [ -f "/root/miniconda3/bin/python" ]; then
        log_info "🐍 检测到Miniconda环境，使用专用设置脚本"
        chmod +x deploy/miniconda_setup.sh
        if ./deploy/miniconda_setup.sh; then
            log_info "✅ Miniconda环境设置成功"
            return 0
        else
            log_error "❌ Miniconda环境设置失败"
            return 1
        fi
    else
        # 执行标准部署步骤
        if detect_system_info && \
           setup_python_env && \
           install_dependencies && \
           setup_model_cache && \
           verify_installation && \
           setup_environment && \
           create_quick_start; then

            show_deployment_result
            log_info "✅ 部署成功完成"
            return 0
        else
            log_error "❌ 部署过程中出现错误"
            return 1
        fi
    fi
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
