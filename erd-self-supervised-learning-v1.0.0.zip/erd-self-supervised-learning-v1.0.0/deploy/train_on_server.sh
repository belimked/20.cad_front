#!/bin/bash

# ERD自监督学习服务器训练脚本
# 作者：Claude 4.0 sonnet
# 功能：后台启动训练，支持RTX 4090优化

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

log_info() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# 检查训练前置条件
check_prerequisites() {
    log_step "🔍 检查训练前置条件..."

    cd "$PROJECT_DIR"

    # 检查Python环境（Miniconda或虚拟环境）
    if [ -f "/root/miniconda/bin/python" ] || [ -f "/root/miniconda3/bin/python" ]; then
        log_info "检测到Miniconda环境"
    elif [ -d "erd_env" ]; then
        log_info "检测到虚拟环境"
    else
        log_error "❌ 未找到Python环境，请先运行 ./deploy/setup_server.sh"
        return 1
    fi

    # 检查ERD文件
    if [ ! -f "data/erd/cost_erd.json" ]; then
        log_error "❌ ERD文件不存在: data/erd/cost_erd.json"
        return 1
    fi

    # 检查配置文件
    if [ ! -f "config/qwen_3b_config.yaml" ]; then
        log_error "❌ 配置文件不存在: config/qwen_3b_config.yaml"
        return 1
    fi

    # 检查是否已有训练进程
    if [ -f "logs/train.pid" ]; then
        local old_pid=$(cat logs/train.pid)
        if ps -p $old_pid > /dev/null 2>&1; then
            log_warn "⚠️  检测到正在运行的训练进程 (PID: $old_pid)"
            echo "是否停止现有训练并启动新的训练？(y/N)"
            read -r response
            if [[ "$response" =~ ^[Yy]$ ]]; then
                log_info "停止现有训练进程..."
                kill $old_pid
                sleep 3
            else
                log_info "保持现有训练进程运行"
                return 1
            fi
        fi
    fi

    log_info "✅ 前置条件检查通过"
    return 0
}

# 准备训练环境
prepare_training_env() {
    log_step "🔧 准备训练环境..."

    cd "$PROJECT_DIR"

    # 加载环境配置（包含环境激活逻辑）
    if [ -f "erd_env_config.sh" ]; then
        source erd_env_config.sh
    else
        # 设置基本环境变量
        export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"
        export CUDA_VISIBLE_DEVICES=0
        export TOKENIZERS_PARALLELISM=false
        export HF_ENDPOINT=https://hf-mirror.com

        # 尝试激活环境
        if [ -f "/root/miniconda/bin/python" ] || [ -f "/root/miniconda3/bin/python" ]; then
            # Miniconda环境，使用当前环境
            log_info "使用Miniconda环境"
        elif [ -d "erd_env" ]; then
            source erd_env/bin/activate
        fi
    fi

    # 创建必要目录
    mkdir -p logs data/generated data/models

    # 检测GPU类型并优化配置
    if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
        log_info "检测到RTX 4090，启用优化配置"
        export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512
        export CUDA_LAUNCH_BLOCKING=0
    fi

    log_info "✅ 训练环境准备完成"
    return 0
}

# 清理GPU内存
clear_gpu_memory() {
    log_step "🔥 清理GPU内存..."

    cd "$PROJECT_DIR"

    # 使用集成的GPU清理脚本
    if [ -f "deploy/gpu_cleanup.sh" ]; then
        log_info "使用集成GPU清理脚本..."
        chmod +x deploy/gpu_cleanup.sh
        ./deploy/gpu_cleanup.sh --auto
    elif [ -f "examples/shell/clear_gpu_memory.sh" ]; then
        log_info "使用项目GPU清理脚本..."
        chmod +x examples/shell/clear_gpu_memory.sh
        ./examples/shell/clear_gpu_memory.sh true
    else
        log_info "使用内置GPU清理逻辑..."

        # 杀死训练相关进程
        pkill -f "train_model" 2>/dev/null || true
        pkill -f "python.*train" 2>/dev/null || true
        pkill -f "torchrun" 2>/dev/null || true

        # 清理缓存文件
        rm -rf ~/.cache/torch/* 2>/dev/null || true
        rm -rf ~/.cache/huggingface/transformers/*/tmp* 2>/dev/null || true
        rm -rf /tmp/torch_* 2>/dev/null || true

        # 等待清理生效
        sleep 3
    fi

    log_info "✅ GPU清理完成"
    return 0
}

# 启动训练进程
start_training() {
    log_step "🚀 启动训练进程..."

    cd "$PROJECT_DIR"

    # 使用Python路径检测脚本
    local python_cmd="python"
    if [ -f "deploy/detect_python.sh" ]; then
        chmod +x deploy/detect_python.sh
        python_cmd=$(./deploy/detect_python.sh --detect)
        if [ $? -ne 0 ]; then
            log_error "❌ Python路径检测失败"
            return 1
        fi
        log_info "检测到Python: $python_cmd"
    else
        # 备用检测逻辑
        if [ -f "/root/miniconda/bin/python" ]; then
            python_cmd="/root/miniconda/bin/python"
        elif [ -f "/root/miniconda3/bin/python" ]; then
            python_cmd="/root/miniconda3/bin/python"
        elif command -v python3 &> /dev/null; then
            python_cmd="python3"
        fi
    fi

    # 构建训练命令
    local train_cmd="$python_cmd examples/train_model.py"
    train_cmd="$train_cmd --erd_file data/erd/cost_erd.json"
    train_cmd="$train_cmd --max_samples 8000"
    train_cmd="$train_cmd --config config/qwen_3b_config.yaml"
    train_cmd="$train_cmd --output_dir data/generated"

    log_info "训练命令: $train_cmd"

    # 启动后台训练
    nohup $train_cmd > logs/training.log 2>&1 &

    # 获取进程ID
    local train_pid=$!
    echo $train_pid > logs/train.pid

    # 等待一下确保进程启动
    sleep 2

    # 检查进程是否正常启动
    if ps -p $train_pid > /dev/null 2>&1; then
        log_info "✅ 训练进程启动成功 (PID: $train_pid)"
        return 0
    else
        log_error "❌ 训练进程启动失败"
        return 1
    fi
}

# 显示训练信息
show_training_info() {
    local train_pid=$(cat logs/train.pid 2>/dev/null)

    echo ""
    echo -e "${GREEN}🎉 ERD自监督学习训练已启动！${NC}"
    echo "================================"
    echo ""
    echo "📊 训练信息:"
    echo "  • 进程ID: $train_pid"
    echo "  • ERD数据: 63张表，1330个字段，38个关系"
    echo "  • 训练样本: 8000个（自动生成）"
    echo "  • 基础模型: Qwen2.5-3B-Instruct"
    echo "  • 预计时间: 3-4小时"
    echo ""
    echo "📊 监控命令:"
    echo "  ./deploy/monitor_training.sh        # 综合监控"
    echo "  tail -f logs/training.log           # 实时日志"
    echo "  watch -n 1 nvidia-smi              # GPU监控"
    echo ""
    echo "🔧 控制命令:"
    echo "  kill $train_pid                     # 停止训练"
    echo "  kill \$(cat logs/train.pid)         # 停止训练（通用）"
    echo ""
    echo "📁 输出位置:"
    echo "  data/models/                        # 训练模型"
    echo "  data/generated/                     # 训练数据"
    echo "  logs/training.log                   # 训练日志"
    echo ""
}

# 主函数
main() {
    echo -e "${CYAN}"
    echo "🧠 ERD自监督学习模型训练"
    echo "================================"
    echo "基于63张真实企业数据库表"
    echo "Qwen2.5-3B模型，RTX 4090优化"
    echo -e "${NC}"

    # 检查和修复依赖（仅在必要时）
    if [ -f "deploy/fix_dependencies.sh" ] && [ ! -f ".deps_checked" ]; then
        log_step "🔧 检查依赖包..."
        chmod +x deploy/fix_dependencies.sh
        if ! ./deploy/fix_dependencies.sh --check; then
            log_warn "⚠️  检测到缺失依赖，尝试自动修复..."
            ./deploy/fix_dependencies.sh --auto
        fi
        # 标记依赖已检查
        touch .deps_checked
    elif [ -f ".deps_checked" ]; then
        log_info "✅ 依赖包已检查过，跳过重复检查"
    fi

    # 执行训练流程
    if check_prerequisites && \
       prepare_training_env && \
       clear_gpu_memory && \
       start_training; then

        show_training_info
        log_info "✅ 训练启动成功"
        return 0
    else
        log_error "❌ 训练启动失败"
        return 1
    fi
}

# 脚本入口
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
