# CUDA 内存不足问题 - 快速修复指南

## 🚨 问题描述
训练时遇到 CUDA 内存不足错误：
```
CUDA out of memory. Tried to allocate 18.55 GiB. GPU 0 has a total capacity of 23.64 GiB of which 7.75 GiB is free.
```

## 🎯 立即解决方案

### 方案1：使用内存优化配置（推荐）
```bash
# 1. 清理GPU内存
./clear_gpu_memory.sh --all

# 2. 使用内存优化训练
./quick_train_memory_optimized.sh
```

### 方案2：手动修复
```bash
# 1. 停止当前训练
pkill -f train_model.py

# 2. 清理GPU内存
./clear_gpu_memory.sh --clear

# 3. 使用优化配置重新训练
python examples/train_model.py \
    --erd_file data/erd/cost_erd.json \
    --max_samples 5000 \
    --config config/qwen_3b_memory_optimized.yaml \
    --output_dir data/generated
```

## 🔧 内存优化配置对比

| 参数 | 原始配置 | 优化配置 | 说明 |
|------|----------|----------|------|
| batch_size | 16 | 4 | 减少75%内存使用 |
| gradient_accumulation_steps | 2 | 8 | 保持有效批次大小 |
| max_length | 2048 | 1024 | 减少50%序列内存 |
| lora_r | 8 | 4 | 减少LoRA参数量 |
| lora_alpha | 16 | 8 | 匹配r值调整 |
| target_modules | 4个 | 2个 | 减少目标模块 |

## 📊 内存使用估算

### 原始配置内存需求
- 模型基础内存：~6GB
- 批次数据：16 × 2048 × 4bytes ≈ 512MB
- 梯度和优化器：~12GB
- **总计：~19GB**

### 优化配置内存需求
- 模型基础内存：~6GB
- 批次数据：4 × 1024 × 4bytes ≈ 64MB
- 梯度和优化器：~6GB
- **总计：~12GB**

## 🛠️ 进一步优化选项

如果仍然内存不足，可以尝试：

### 极限优化配置
```yaml
training:
  batch_size: 2  # 进一步减少
  gradient_accumulation_steps: 16  # 相应增加
  
model:
  max_length: 512  # 进一步减少序列长度
  
lora:
  r: 2  # 最小LoRA参数
  lora_alpha: 4
  target_modules: ["q_proj"]  # 只训练一个模块
```

### 使用CPU卸载
```yaml
hardware:
  use_cpu_offload: true  # 启用CPU卸载
  max_memory_per_gpu: "18GB"  # 限制GPU内存使用
```

## 🔍 故障排除

### 检查GPU状态
```bash
# 查看GPU使用情况
./clear_gpu_memory.sh --status

# 查看详细内存信息
nvidia-smi
```

### 清理GPU进程
```bash
# 查看并清理GPU进程
./clear_gpu_memory.sh --kill
```

### 设置内存优化环境
```bash
# 设置优化环境变量
./clear_gpu_memory.sh --env
source gpu_memory_env.sh
```

## 📈 预期效果

使用内存优化配置后：
- ✅ GPU内存使用：~12GB（原19GB）
- ✅ 训练速度：略慢但稳定
- ✅ 模型效果：基本保持不变
- ✅ 训练稳定性：显著提升

## 🚀 快速启动命令

```bash
# 一键解决内存问题
./clear_gpu_memory.sh --all && ./quick_train_memory_optimized.sh
```

## 📝 注意事项

1. **批次大小减少**会导致训练时间增加，但通过梯度累积保持训练效果
2. **序列长度减少**可能影响长文本处理，但对ERD任务影响较小
3. **LoRA参数减少**会略微降低微调能力，但仍能达到预期效果
4. 建议在训练开始前运行 `./clear_gpu_memory.sh --all` 确保GPU内存干净

## 🔄 恢复原始配置

如果需要恢复原始配置：
```bash
# 使用原始配置文件
python examples/train_model.py \
    --config config/qwen_3b_config.yaml \
    --erd_file data/erd/cost_erd.json \
    --max_samples 5000
```
