# 4表增强训练数据配置建议

## 数据统计
- 总样本数: 983
- 任务类型分布:
  - basic_relationship: 420 条 (42.7%)
  - business_analysis: 60 条 (6.1%)
  - negative_relationship: 50 条 (5.1%)
  - path_discovery: 213 条 (21.7%)
  - sql_generation: 240 条 (24.4%)

## 训练配置建议

### 基础配置
```yaml
model_name: qwen_4table_enhanced_v2
base_model: Qwen2.5-3B-Instruct
max_samples: 983

lora_config:
  r: 16
  lora_alpha: 32
  target_modules: ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
  lora_dropout: 0.1

training_args:
  max_length: 2048
  batch_size: 2
  gradient_accumulation_steps: 8
  learning_rate: 2e-4
  num_train_epochs: 3
  warmup_steps: 50
  logging_steps: 10
  save_steps: 100
  eval_steps: 100
  early_stopping_patience: 5
```

### 训练策略
1. **数据质量**: 983条高质量样本，包含多样化的问题表达
2. **任务平衡**: 涵盖关系分析、SQL生成、业务分析等多个维度
3. **格式统一**: 全部采用messages格式，包含4表Schema前置
4. **增量训练**: 可以在现有模型基础上继续训练

### 预期效果
- 保持专业的数据库分析能力
- 提升自然语言理解和灵活性
- 支持更多样化的问题表达方式
- 增强业务场景理解能力

### 训练时间估算
- RTX 4090: 约2-3小时
- 训练步数: 约183步 (3个epoch)
- 建议使用early stopping避免过拟合
