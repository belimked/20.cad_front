create table cmtb_append_column_json
(
    cac_id         int auto_increment comment '序号'
        primary key,
    cac_code       varchar(50)  not null comment 'json:对象代码，例如【key】，必须使用和字典表中，相同的Key，AName开头',
    cac_name       varchar(50)  not null comment 'json:对象显示名称，例如【超黑】',
    cac_value_type int          not null comment '对象值类型，0：文本，1：JSON',
    cac_value_sc   varchar(100) null comment '对象值结构说明，针对JSON格式，申明结构和对应的key，例如{''name1'':''超白玻'',''name2'':''南海'',''name3'':''价格''}',
    cac_createtime varchar(50)  not null comment '创建时间',
    cac_createuser varchar(50)  not null comment '创建人',
    constraint cmtb_append_column_json_index_code
        unique (cac_code)
)
    comment '玻璃基片颜色配置表-Table';

create table cmtb_attachment
(
    att_id                int auto_increment comment '附件序号'
        primary key,
    att_original_name     varchar(512) null comment '附件原始名称',
    att_actual_name       varchar(128) null comment '附件在服务器上存储名称',
    att_refer_moduleid    varchar(64)  null comment '附件从属业务对象所属模块编号',
    att_refer_attributeid varchar(64)  null comment '附件从属业务对象子属性编号',
    att_refer_objectid    varchar(64)  null comment '附件从属业务对象编号',
    att_store_path        varchar(512) null comment '附件在服务器上的存储路径',
    att_type              varchar(32)  null comment '附件文件类型',
    att_size              varchar(32)  null comment '附件大小',
    att_remark            varchar(512) null comment '附件备注信息',
    att_status            varchar(2)   null comment '附件状态',
    att_createuser        varchar(20)  null comment '创建人',
    att_createdate        varchar(20)  null comment '创建时间',
    att_updateuser        varchar(20)  null comment '更新人',
    att_updatedate        varchar(20)  null comment '更新时间'
)
    comment '附件表';

create table cmtb_button
(
    btn_id         int auto_increment comment '按钮序号'
        primary key,
    btn_name       varchar(128) null comment '按钮名称',
    cm_id          int          null comment '关联到menu对象的序号',
    btn_code       varchar(512) null comment '按钮代码',
    btn_icon       varchar(32)  null comment '按钮图标',
    btn_js         varchar(512) null comment '按钮脚本',
    btn_sort       int          null comment '按钮排序',
    btn_status     varchar(2)   null comment '按钮状态 0无效 1有效',
    btn_createuser varchar(20)  null comment '创建人',
    btn_createdate varchar(20)  null comment '创建时间',
    btn_updateuser varchar(20)  null comment '更新人',
    btn_updatedate varchar(20)  null comment '更新时间'
)
    comment '按钮对象表' row_format = DYNAMIC;

create table cmtb_dictionary_type
(
    ct_id         int auto_increment comment 'ct_id'
        primary key,
    ct_name       varchar(64) null comment '字典对象名称 显示使用',
    ct_code       varchar(64) null comment '字典对象代码',
    ct_type       varchar(64) null comment '字典类型 .0:系统配置信息,1:业务字典',
    ct_status     varchar(2)  null comment '状态 ,0:可用,1:不可用',
    ct_cteatetime varchar(20) null comment '创建时间',
    ct_cteateuser varchar(20) null comment '创建人',
    ct_updatetime varchar(20) null comment '更新时间',
    ct_updateuser varchar(20) null comment '更新人'
)
    comment '数据字典表';

create table cmtb_dictionary_value
(
    ctv_id         int auto_increment comment 'ctv_id'
        primary key,
    ct_id          int           null comment '字典对象序号,主表',
    ctv_name       varchar(128)  null comment '字典对象值—显示名称',
    ctv_value      varchar(5000) null comment '字典对象值—实际的值',
    ctv_order      int           null comment '字典对象排序',
    ctv_status     varchar(32)   null comment '状态 0:可用 1:不可用',
    ctv_cteateuser varchar(20)   null comment '创建人',
    ctv_cteatetime varchar(20)   null comment '创建时间',
    ctv_updateuser varchar(20)   null comment '更新人',
    ctv_updatetime varchar(20)   null comment '更新时间'
)
    comment '数据字典表—数据表';

create table cmtb_formula_config
(
    cfc_id           int auto_increment comment '序号'
        primary key,
    cfc_vendor_group varchar(50) not null comment '供应商组序号',
    cfc_name         varchar(50) not null comment '公式名称，显示用',
    cfc_code         varchar(50) not null comment '公式代码，逻辑计算使用',
    cfc_pr_id        int         null comment '父级序号，默认空',
    cfc_type         int         null comment '公式类型，0：主公式，1：子公式，2，正负判断公式，3。阈值-百分比，4，阈值元/吨',
    cfc_status       int         not null comment '状态，0：正常，默认值。9：弃用',
    cfc_createtime   varchar(20) not null comment '创建时间',
    cfc_createuser   varchar(20) not null comment '创建人',
    cfc_updatetime   varchar(20) not null comment '更新时间',
    cfc_updateuser   varchar(20) not null comment '更新人'
)
    comment '供应商-公式配置表';

create table cmtb_menu
(
    men_id      int auto_increment comment '菜单序号'
        primary key,
    men_name    varchar(64)            null comment '菜单名称',
    men_code    varchar(512)           null comment '菜单代码，权限控制时使用',
    men_pid     int                    null comment '菜单父序号',
    men_p_url   varchar(512)           null comment '菜单父对象-网址，匹配tab对象时使用',
    men_type    int                    null comment '菜单类型 0菜单 1标签页',
    men_url     varchar(512)           null comment '菜单对应的网址',
    men_icon    varchar(32)            null comment '菜单对应的图标',
    men_status  varchar(2) default '0' null comment '菜单状态 1无效 0有效',
    create_user varchar(20)            null comment '创建人',
    create_code varchar(20)            null comment '创建人代码',
    create_time datetime               null comment '创建时间',
    update_user varchar(20)            null comment '更新人',
    update_code varchar(20)            null comment '更新人代码',
    update_time varchar(20)            null comment '更新时间'
)
    comment '菜单对象表' row_format = DYNAMIC;

create table craft_drawing_info
(
    id                           int auto_increment comment '自动递增 ID'
        primary key,
    mpom_process_draw_number     varchar(50)   not null comment '工艺图纸编号',
    mpom_process_draw_numberJson varchar(255)  null comment '工艺图名称json格式',
    tep_id                       int           not null comment '预结算审核单序号',
    glass_type                   varchar(50)   not null comment '玻璃的类型（如双片夹胶、三片中空夹胶）',
    is_curved                    int(1)        not null comment '是否弧形（1: 是, 0: 否）',
    h                            varchar(50)   not null comment '玻璃的高度信息',
    w                            varchar(50)   not null comment '玻璃的宽度信息',
    hole_count                   int default 0 null comment '开孔数量',
    groove_count                 int default 0 null comment '挖槽数量',
    chamfer_count                int default 0 null comment '切角数量',
    u_slot_count                 int default 0 null comment 'U 槽数量',
    glue_depth_info              varchar(255)  null comment '胶深信息',
    glue_depth_info_u            varchar(255)  null comment 'U形胶深信息',
    polishing_info               varchar(100)  null comment '精磨信息（如果有）',
    hlk                          int default 0 null comment '黑铝框',
    fbdxj                        int default 0 null comment '飞边打斜胶',
    reqin                        int default 0 null comment '热浸',
    dumo                         int default 0 null comment '镀膜',
    yaqi                         int default 0 null comment '氩气',
    caiyou                       int default 0 null comment '彩釉'
)
    comment '工艺图AI模型识别结果表' row_format = DYNAMIC;

create table flyway_schema_history
(
    installed_rank int                                 not null
        primary key,
    version        varchar(50)                         null,
    description    varchar(200)                        not null,
    type           varchar(20)                         not null,
    script         varchar(1000)                       not null,
    checksum       int                                 null,
    installed_by   varchar(100)                        not null,
    installed_on   timestamp default CURRENT_TIMESTAMP not null,
    execution_time int                                 not null,
    success        tinyint(1)                          not null
);

create index flyway_schema_history_s_idx
    on flyway_schema_history (success);

create table hstb_accounting_attachment
(
    haa_id              int auto_increment
        primary key,
    ma_id               int           null comment '结算单序号',
    mtm_id              int           null comment '发货单序号',
    haa_attachment_name varchar(255)  null comment '结算单-附件名称',
    haa_attachment_path varchar(500)  null comment '结算单-附件路径',
    haa_type            int           not null comment '操作类型：0：结算单附件上传，1：弃用',
    haa_status          int default 0 not null comment '状态，0：正常，1：弃用',
    haa_createtime      varchar(20)   not null comment '创建时间',
    haa_createuser      varchar(20)   not null comment '创建人',
    haa_updatetime      varchar(20)   null comment '更新时间',
    haa_updateuser      varchar(20)   null comment '更新人',
    haa_original_name   varchar(255)  null comment '结算单-附件原文件名'
)
    comment '结算单附件表-历史记录';

create table hstb_material_price_log
(
    h_id              int auto_increment comment '序号'
        primary key,
    h_type            int           not null comment '类型，0:PMS订单，1:MES订单',
    h_order_id        int           not null comment '订单序号',
    h_status          int default 0 not null comment '状态 状态：0，正常，5，弃用',
    h_create_user     varchar(20)   not null comment '创建人 创建人',
    h_create_usercode varchar(20)   not null comment '创建人工号 创建人工号',
    h_create_time     varchar(20)   not null comment '创建时间 创建时间',
    h_update_user     varchar(20)   null comment '更新人 更新人',
    h_update_usercode varchar(20)   null comment '更新人工号 更新人工号',
    h_update_time     varchar(20)   null comment '更新时间 更新时间'
)
    comment '材料单价变更日志 记录材料单价变更历史';

create table hstb_material_price_log_detail
(
    hd_id                int auto_increment comment '序号'
        primary key,
    h_id                 int           not null comment '主表序号',
    hd_order_id          int           not null comment '订单表序号',
    hd_order_material_id int           not null comment '订单详情表序号',
    hd_psam_code         varchar(200)  null comment '材料编号',
    hd_old_price         varchar(200)  null comment '旧单价',
    hd_old_measure       varchar(200)  null comment '旧面积',
    hd_new_price         varchar(200)  null comment '新单价',
    hd_new_measure       varchar(200)  null comment '新面积',
    hd_status            int default 0 not null comment '状态 状态：0，正常，5，弃用',
    hd_create_user       varchar(20)   not null comment '创建人 创建人',
    hd_create_usercode   varchar(20)   not null comment '创建人工号 创建人工号',
    hd_create_time       varchar(20)   not null comment '创建时间 创建时间',
    hd_update_user       varchar(20)   null comment '更新人 更新人',
    hd_update_usercode   varchar(20)   null comment '更新人工号 更新人工号',
    hd_update_time       varchar(20)   null comment '更新时间 更新时间'
)
    comment '材料单价变更日志-详情 材料单价变更日志-详情';

create table hstb_modification_log
(
    hml_id               int auto_increment comment '序号'
        primary key,
    hml_type             varchar(2)   null comment '对象类型 1:铝型材
3:玻璃
2:铝板
6:石材
5:不锈钢
4:钢材
7:常规附件
8:非常规附件
9:辅材
10:铝锭
11:线密度
12:结算单',
    pro_id               int          null comment '项目序号 项目序号',
    hml_operation_data   varchar(128) null comment '修改数据 存放修改的数据信息',
    hml_operation_type   varchar(2)   null comment '修改的类型 0:手动修改1:结算修改',
    hml_operation_number varchar(128) null comment '关联单号',
    hml_business_id      int          null comment '业务对象序号 单价类型的数据，需要关联该字段，得出某一个业务对象的数据
比方玻璃单价修改，type对象是2，business_id则是针对price对象的序号（tm_id）',
    hml_remark           varchar(512) null comment '修改备注',
    hml_status           varchar(2)   null comment '状态',
    hml_createuser       varchar(20)  null comment '创建人',
    hml_createusercode   varchar(20)  null comment '创建人代码',
    att_info             varchar(500) null comment '附件信息',
    hml_createtime       varchar(20)  null comment '创建时间',
    hml_updateuser       varchar(20)  null comment '更新人',
    hml_updateusercode   varchar(20)  null comment '更新人代码',
    hml_updatetime       varchar(20)  null comment '更新时间'
)
    comment '业务数据修改记录';

create index hstb_modification_log_hml_business_id_hml_type_index
    on hstb_modification_log (hml_business_id, hml_type);

create table hstb_root_exception
(
    id     int auto_increment
        primary key,
    number varchar(100) not null,
    status int          not null
);

create table hstb_vpo_extend_contract_approval_log
(
    hca_id         int auto_increment comment '当前对象序号'
        primary key,
    business_id    int           not null comment '业务对象序号',
    hca_type       int           not null comment '节点类型',
    hca_comment    varchar(5000) null comment '节点备注',
    hca_createuser varchar(20)   null comment '节点创建人',
    hca_createtime varchar(20)   null comment '节点创建时间',
    hca_updateuser varchar(20)   null comment '节点更新人',
    hca_updatetime varchar(20)   null comment '节点更新时间',
    hca_status     int default 0 not null comment '状态'
)
    comment '合同单价审核单_节点';

create table material_cost_info
(
    id                       int auto_increment comment '自动递增 ID'
        primary key,
    tep_id                   int              not null comment '预结算审核单序号',
    tep_detail_id            varchar(50)      null comment '预结算审核单详情序号',
    mpom_psam_code           varchar(50)      null comment '材料编号',
    mpom_process_draw_number varchar(50)      not null comment '工艺图纸编号',
    ai_total_cost            double           null comment 'AI 计算材料附加总费用',
    ai_weight_area           double           null comment 'AI 计算材料单重面积',
    ai_hole_cost             double default 0 null comment 'AI 计算材料开孔费用',
    ai_groove_cost           double default 0 null comment 'AI 计算材料挖槽费用',
    ai_chamfer_cost          double default 0 null comment 'AI 计算材料切角费用',
    ai_u_slot_cost           double default 0 null comment 'AI 计算材料 U 槽费用',
    ai_glue_depth_cost       double default 0 null comment 'AI 计算材料胶深费用',
    ai_polishing_cost        double default 0 null comment 'AI 计算材料精磨费用',
    ai_over_wh               int    default 0 null comment '是否超长超宽',
    ai_over_wh_cost          double default 0 null comment '超长超宽价格',
    ai_xz                    varchar(50)      null comment '形状'
)
    comment 'AI材料费用信息' row_format = DYNAMIC;

create table mstb_accounting
(
    ma_id              int auto_increment comment '结算序号'
        primary key,
    ma_number          varchar(128)           null comment '结算单号',
    pv_id              int                    null comment '材料类型',
    pro_id             int                    null comment '项目序号',
    ma_except_cost     decimal(32, 8)         null comment '计算总金额',
    ma_external_cost   decimal(32, 8)         null comment '额外运费',
    ma_actual_cost     decimal(32, 8)         null comment '实际金额',
    ma_express_number  varchar(128)           null comment '供应商送货单号',
    ma_vendor_name     varchar(128)           null comment '供应商',
    ma_remark          varchar(512)           null comment '原因',
    ma_status          varchar(2)             null comment '状态 0有效，1失效',
    ma_accounting_type varchar(2) default '0' null comment '结算单类型 0:为普通的结算单   1:为加工件采购结算单',
    ma_createuser      varchar(20)            null comment '创建人',
    ma_createusercode  varchar(20)            null comment '创建人代码',
    ma_createtime      varchar(20)            null comment '创建时间',
    ma_updateuser      varchar(20)            null comment '更新人',
    ma_updateusercode  varchar(20)            null comment '更新人代码',
    ma_updatetime      varchar(20)            null comment '更新时间'
)
    comment '结算主表';

create table mstb_deliver_main
(
    mdm_id             int auto_increment comment '原材料运货序号'
        primary key,
    mdm_no             varchar(128)           null comment '原材料运货单号',
    pro_id             int                    null comment '项目序号',
    vendor_id          varchar(128)           null comment '供应商序号',
    prv_id             int                    null comment '材料类型ID',
    mdm_close_time     varchar(20)            null comment '结算时间',
    mdm_export_time    varchar(20)            null comment '导出时间',
    mdm_status         varchar(2)             null comment '状态 0:带结算
1：已结算',
    mdm_deliver_status varchar(2) default '0' null comment '送货单状态  0：有效  -1无效',
    mdm_deliver_type   varchar(2) default '0' null comment '送货单类型  0:为普通的送货单   1:为加工件采购送货单',
    mdm_createuser     varchar(20)            null comment '创建人',
    mdm_createusercode varchar(20)            null comment '创建人代码',
    mdm_createtime     varchar(20)            null comment '创建时间',
    mdm_updateuser     varchar(20)            null comment '更新人',
    mdm_updateusercode varchar(20)            null comment '更新人代码',
    mdm_updatetime     varchar(20)            null comment '更新时间'
)
    comment '送货单主表';

create index index_mdm_id
    on mstb_deliver_main (mdm_id);

create index index_pro_id
    on mstb_deliver_main (pro_id);

create table mstb_material_process
(
    omp_id             int(1) auto_increment comment '工艺图记录ID'
        primary key,
    pro_id             int(1)                 not null comment '工程项目ID',
    pv_id              int(1)                 not null comment '物料类型ID',
    omp_name           varchar(100)           null comment '工艺图名称',
    file_name          varchar(255)           null comment '工艺图文件名',
    omp_column_code    varchar(255)           null comment '对应工艺图配置表的配置列  拼接而成',
    omp_column_value   varchar(255)           null comment '对应工艺图配置表的配置列值  拼接而成',
    omp_createdate     varchar(20)            null comment '工艺图创建时间',
    omp_createuser     varchar(20)            null comment '工艺图创建人员',
    omp_createUsercode varchar(20)            null comment '工艺图创建人员工号',
    omp_updatedate     varchar(20)            null comment '工艺图修改时间',
    omp_updateuser     varchar(20)            null comment '工艺图修改人员',
    omp_updateUsercode varchar(20)            null comment '工艺图修改人员工号',
    omp_status         varchar(2) default '1' null comment '工艺图状态  0不可用 1可用，默认可用',
    omp_option1        varchar(20)            null comment '备用字段1',
    omp_option2        varchar(20)            null comment '备用字段2',
    omp_option3        varchar(20)            null comment '备用字段3',
    constraint MSIX_ompName
        unique (pro_id, omp_name)
)
    comment '工艺图表';

create index MSIX_proId
    on mstb_material_process (pro_id);

create index MSIX_pvId
    on mstb_material_process (pv_id);

create table mstb_materials_receiving_main
(
    mmrm_id             int auto_increment comment '收货序号'
        primary key,
    pro_id              int                    null comment '工程项目ID',
    pv_id               int                    null comment '材料类型ID',
    mdm_id              int                    null comment '原材料运货序号',
    mmrm_source         int                    null comment '数据对象对应的原始来源
0:pms
1:mes',
    mmrm_no             varchar(100)           null comment '收货单号',
    mmrm_filename       varchar(128)           null comment '原材料收货凭证',
    mmrm_receivedate    varchar(20)            null comment '实际收货时间',
    mmrm_status         varchar(2)             null comment '原材料收货单状态 1待收货 2完成收货 -1弃用
-2异常（结算之后，再次接收到同步数据）
3，已结算，4待结算',
    mmrm_receicing_type varchar(2) default '0' null comment '收货单类型 0:为普通的收货单  1：为加工件采购收货单',
    mmrm_createuser     varchar(20)            null comment '原材料收货记录创建人员',
    mmrm_createdate     varchar(20)            null comment '原材料收货记录创建时间',
    mmrm_updatedate     varchar(20)            null comment '原材料收货记录修改人员',
    mmrm_updateuser     varchar(20)            null comment '原材料收货记录修改时间',
    mmrm_option1        int                    null comment '0:工地  1:工厂'
)
    comment '材料收货主表';

create index index_mmrm_id
    on mstb_materials_receiving_main (mmrm_id);

create index index_pro_id
    on mstb_materials_receiving_main (pro_id);

create table mstb_mes_purchase_order_main
(
    o_id                      int(10) auto_increment
        primary key,
    o_order_number            varchar(50)   null comment '采购订购单号',
    o_vendor_id               varchar(50)   null comment '供应商
            存放实际供应商名称，不存放序号',
    o_buyer                   varchar(20)   null comment '采购员',
    o_receiver                varchar(20)   null comment '收货人',
    o_receiver_contract       varchar(200)  null comment '收货人联系方式',
    o_receiver_address        varchar(200)  null comment '收货地址',
    o_receiver_date           varchar(30)   null comment '收货时间',
    o_providetype_id          varchar(5)    null comment '材料类型序号',
    o_status                  varchar(2)    null comment '订单状态 -- 1未收货 2 已收货  3 终止订单  4 收货中',
    o_remark                  varchar(255)  null comment '备注',
    o_createuser              varchar(20)   null comment '创建人',
    o_createdate              varchar(20)   null comment '创建时间',
    o_updateuser              varchar(20)   null comment '更新人',
    o_updatedate              varchar(20)   null comment '更新时间',
    o_send_status             int(10)       null comment 'int型备用字段

            --MES 订单处理状态
            0：未发单
            1：已发单',
    o_intfields2              int(10)       null,
    o_fields1                 varchar(2)    null comment '方式表预留字段1--0工地收货,1工厂收货',
    o_fields2                 varchar(2)    null comment '方式表预留字段2--材料类型pvId',
    o_oa_number               varchar(255)  null comment 'OA流程编号',
    o_con_id                  int(10)       null comment '合同的id',
    o_order_type              varchar(2)    null comment '订单的类型--(年度合同,工程合同等)',
    o_pro_id                  int(10)       null comment '项目id',
    o_pro_name                varchar(50)   null comment '项目名称',
    o_stage_id                int(10)       null comment '阶段ID',
    o_stage_name              varchar(100)  null comment '阶段名称',
    o_total_weight            varchar(50)   null comment '总重量/面积',
    o_buyer_contract          varchar(50)   null comment '采购人(发件人)联系方式',
    o_addressee               varchar(50)   null comment '收件人',
    o_addressee_contract      varchar(50)   null comment '收件人联系方式',
    o_flow_status             varchar(20)   null,
    mpom_purchase_type        varchar(50)   null comment '分单-采购方式',
    o_jgfs                    varchar(2)    null comment '加工方式 0先拉弯后喷涂，1先喷涂后拉弯',
    o_type                    varchar(2)    null comment '订单类型 0普通订单，1多供应商订单',
    o_vendor_companyname      varchar(50)   null comment '供方名称',
    o_provider_name           varchar(50)   null comment '供方收件人',
    o_provider_contract       varchar(50)   null comment '供方收件人联系方式',
    mes_price_status          int default 0 not null comment '单价录入状态，0:未录入，1:已录入',
    mes_price_create_date     varchar(20)   null comment '单价录入时间',
    mes_price_create_user     varchar(20)   null comment '单价录入人',
    mes_price_create_usercode varchar(20)   null comment '单价录入人工号',
    mes_po_status             int default 0 not null comment '成本订单状态，0：有效，9:无效',
    mes_po_total_price        varchar(100)  null comment '成本订单总金额',
    mes_po_total_weight       varchar(100)  null comment '成本订单总面积/重量'
)
    comment 'MES加工订单主表 ' row_format = DYNAMIC;

create table mstb_mes_purchase_order_material
(
    mpom_id                       int(10) auto_increment comment 'id'
        primary key,
    mpom_o_id                     int(10)      null comment '采购订单id',
    mpom_mppm_id                  int(10)      null comment '冗余材料表id,对应于mstb_purchase_plan_material的mppm_id',
    mpom_mpp_id                   int(10)      null comment '提料单表id',
    mpom_mpp_no                   varchar(100) null comment '订购单号
            冗余存放订单编号',
    mpom_purchase_number          int(10)      null comment '采购数量',
    mpom_type                     varchar(2)   null comment '材料编码的类型--1优化单生成的材料 -- 0不需要优化的材料',
    mpom_status                   varchar(2)   null comment '采购单材料状态 1未收货 2已收货 3终止订单 4收货中 8、删除材料流程审核中',
    mpom_intfields1               int(10)      null comment 'int型备用字段',
    mpom_intfields2               int(10)      null,
    mpom_fields1                  varchar(255) null comment '字符型备用字段 --- 特殊处理,便于后面的查询和显示 .如果是优化则保存优化长度,如果不是优化则保存设计尺寸',
    mpom_fields2                  varchar(255) null comment '保存订单材料的来源类型 1,提料单材料 2外协外包材料 3 原材料补货单 4 工地补货单',
    mpom_fields3                  varchar(255) null comment '保存订单材料的收货类型.0工地收货 1工厂收货',
    mpom_createuser               varchar(20)  null comment '创建人',
    mpom_createdate               varchar(20)  null comment '创建时间',
    mpom_updateuser               varchar(20)  null comment '更新人',
    mpom_updatedate               varchar(20)  null comment '更新时间',
    mpom_psam_id                  int(10)      null comment '设计单材料id,对应于mstb_purchase_plan_material的psam_id',
    mpom_hasreceiving_count       int(10)      null comment '可收货数量',
    mpom_pv_id                    int(10)      null comment '材料类型id',
    mpom_pro_id                   int(10)      null comment '工程项目id',
    mpom_vendor_id                varchar(50)  null comment '供应商id',
    mpom_mpv_id                   int(10)      null comment '供应商材料代码对照表 -- id',
    mpom_vendor_symbol            varchar(100) null comment '供应商材料代码对照表 -- 供应商材料代码',
    mpom_yh_length                varchar(20)  null comment 'x型材优化后长度',
    mpom_design_size              varchar(200) null comment '订购尺寸',
    mpom_process_size             varchar(200) null comment '加工尺寸',
    mpom_weight_single            varchar(255) null comment '材质',
    mpom_optimization_no          varchar(200) null comment '存放
            种类',
    mpom_action_area              varchar(255) null comment '颜色',
    mpom_psam_weight              varchar(20)  null comment '重量（Kg）/面积（m2）',
    mpom_plan_total               varchar(10)  null comment '提料单提料数量',
    mpom_psam_code                varchar(500) null comment '材料编号
            存放材料序号',
    mpom_psam_name                varchar(200) null comment '材料名称',
    mpom_process_draw_number      varchar(50)  null comment '图纸',
    mpom_mpp_symbol               varchar(255) null comment '物料工程属性代码',
    mpom_total_weight             varchar(50)  null comment '单行的总重量/面积',
    mpom_process_draw_number_json varchar(255) null comment '图纸JSON
            {name:xxx,id:xxx}

            name:名称
            id:序号',
    mpom_generete_modelimg        varchar(100) null comment '铝型材开模图',
    mpom_generete_modelimg_json   varchar(255) null comment '铝型材开模图Json格式',
    mpom_remark                   varchar(255) null comment '备注',
    mpom_linear_density           varchar(50)  null comment '线密度',
    mpom_curve_making             varchar(10)  null comment '铝型材拉弯',
    mpom_fields4                  varchar(2)   null comment '采购订单材料从表备用字段 -- 用于表名是否锁定当前列表,1表示未锁定,-1表示锁定,-2表示流程通过',
    mpom_fields5                  varchar(50)  null comment '采购订单材料表备用字段 -- 保存铝型材材质',
    mpom_m_type                   varchar(50)  null comment '辅材材料种类',
    mpom_total_purchase           int(10)      null comment '材料采购总量 采购总量等于采购量加上废料使用量',
    mpom_freezed_purchase         int(10)      null comment '废料使用量',
    mpom_flow_status              varchar(2)   null comment '默认为NULL，0解锁，1加锁',
    jsbz                          varchar(200) null comment '辅材技术标准',
    schd                          varchar(200) null comment '石材厚度',
    mes_po_price                  varchar(100) null comment '成本订单金额',
    mes_po_weight                 varchar(100) null comment '成本订单面积/重量'
)
    comment 'MES加工订单材料表 ' row_format = DYNAMIC;

create table mstb_meterial_project_properties
(
    mpp_id          int auto_increment comment '物料工程属性值序号'
        primary key,
    proj_id         int          null comment '工程项目序号',
    prov_id         int          null comment '物料类型代号',
    mpp_symbol      varchar(500) null comment '物料工程属性代码',
    mpp_name        varchar(100) null comment '物料工程属性详情',
    mpp_kmt         varchar(128) null comment '开模图',
    mpp_action_area varchar(128) null comment '表面处理',
    mpp_basic       varchar(128) null comment '基本属性名称',
    mpp_xmd         varchar(64)  null comment '线密度',
    mpp_status      varchar(2)   null comment '物料工程属性值状态 0不可用 1可用 2被合并',
    mpp_createuser  varchar(20)  null comment '创建人',
    mpp_createdate  varchar(20)  null comment '创建时间',
    mpp_updateuser  varchar(20)  null comment '更新人',
    mpp_updatedate  varchar(20)  null comment '更新时间'
)
    comment '物料工程属性表';

create index mstb_meterial_project_properties_x
    on mstb_meterial_project_properties (proj_id, prov_id, mpp_symbol);

create definer = fangda@`%` trigger TR_update_material_xmd
    before update
                      on mstb_meterial_project_properties
                      for each row
BEGIN
  IF (NEW.mpp_xmd is not null) THEN
update mstb_project_materials s set s.psam_xmd=NEW.mpp_xmd where 	mpm_code=NEW.mpp_symbol and pro_id=NEW.proj_id and prv_id=NEW.prov_id;
END IF;
END;

create table mstb_per_payment_approval
(
    ppm_id                int auto_increment comment '序号'
        primary key,
    ppm_pro               int          null comment '项目序号',
    ppm_pro_name          varchar(200) null comment '项目名称',
    ppm_con_id            int          null comment '合同序号',
    ppm_con_name          varchar(200) null comment '合同编号',
    ppm_number            varchar(200) null comment '审核单号',
    ppm_approval_comment  varchar(200) null comment '审核意见，成本',
    ppm_approval_user     varchar(200) null comment '审核人',
    ppm_approval_datetime varchar(200) null comment '审核时间',
    ppm_cost_amount       varchar(200) null comment '预付款金额',
    ppm_pv                int          null comment '材料类型',
    ppm_vendor_id         varchar(200) null comment '供应商序号',
    ppm_vendor_name       varchar(200) null comment '供应商名称',
    ppm_createtime        varchar(20)  null comment '创建时间',
    ppm_createuser        varchar(20)  null comment '创建人',
    ppm_submittime        varchar(20)  null comment '提交时间',
    ppm_submituser        varchar(20)  null comment '提交人',
    ppm_updatetime        varchar(20)  null comment '更新时间',
    ppm_updateuser        varchar(20)  null comment '更新人',
    ppm_status            int          null comment '状态,ID#30025-结算状态',
    contract_createtime   varchar(50)  null comment '合同创建时间'
)
    comment '预付款-审核单-主对象';

create table mstb_pms_purchase_order_main
(
    o_id                      int(10) auto_increment
        primary key,
    o_order_number            varchar(50)   null comment '采购订购单号',
    o_vendorID                varchar(50)   null comment '供应商序号',
    o_buyer                   varchar(20)   null comment '采购员',
    o_receiver                varchar(20)   null comment '收货人',
    o_receiverContract        varchar(200)  null comment '收货人联系方式',
    o_receiverAddress         varchar(200)  null comment '收货地址',
    o_receiverDate            varchar(30)   null comment '预计到货日期',
    o_provideType_id          varchar(5)    null comment '材料类型序号',
    o_status                  varchar(2)    null comment '订单状态 -- 1,2,4有效，3，无效',
    o_remark                  varchar(255)  null comment '备注',
    o_createuser              varchar(20)   null comment '创建人',
    o_createdate              varchar(20)   null comment '下单日期',
    o_updateuser              varchar(20)   null comment '更新人',
    o_updatedate              varchar(20)   null comment '更新时间',
    o_intfields1              int(10)       null comment 'int型备用字段',
    o_intfields2              int(10)       null,
    o_fields1                 varchar(255)  null comment '方式表预留字段1--0工地收货,1工厂收货',
    o_fields2                 varchar(255)  null comment '方式表预留字段2--材料类型pvId',
    o_fields3                 varchar(255)  null comment '字符型备用字段',
    o_con_id                  int(10)       null comment '合同的id',
    o_order_type              varchar(2)    null comment '订单的类型--(年度合同,工程合同等)',
    o_proId                   int(10)       null comment '项目id',
    o_proName                 varchar(50)   null comment '项目名称',
    o_stageId                 int(10)       null comment '阶段ID',
    o_stageName               varchar(100)  null comment '阶段名称',
    o_totalWeight             varchar(50)   null comment '总重量/面积',
    o_buyerContract           varchar(50)   null comment '采购人(发件人)联系方式',
    o_addressee               varchar(50)   null comment '收件人',
    o_addresseeContract       varchar(50)   null comment '收件人联系方式',
    o_flowStatus              varchar(20)   null,
    mpom_purchase_type        varchar(50)   null comment '分单-采购方式',
    o_jgfs                    varchar(2)    null comment '加工方式 0先拉弯后喷涂，1先喷涂后拉弯',
    o_type                    varchar(2)    null comment '订单类型 0普通订单，1多供应商订单',
    o_vendor_companyname      varchar(50)   null comment '供方名称',
    o_providerName            varchar(50)   null comment '供方收件人',
    o_providerContract        varchar(50)   null comment '供方收件人联系方式',
    o_order_remark            varchar(255)  null comment '订单备注',
    pms_price_status          int default 0 not null comment '单价录入状态，0:未录入，1:已录入',
    pms_price_create_date     varchar(20)   null comment '单价录入时间',
    pms_price_create_user     varchar(20)   null comment '单价录入人',
    pms_price_create_usercode varchar(20)   null comment '单价录入人工号',
    pms_po_status             int default 0 not null comment '成本订单状态，0：有效，9:无效',
    pms_po_total_price        varchar(100)  null comment '成本订单总金额',
    pms_po_total_weight       varchar(100)  null comment '成本订单总面积/重量',
    o_po_gc_type              int           null comment 'PMS订单，钢材类型，0：原材料，1：钢制件',
    o_from_type               int(1)        null comment '订单所属 0-pms 1-mes',
    o_mes_send_time           varchar(20)   null comment '发单日期 yyyy-MM-dd',
    o_send_status             int(1)        null comment '订单发单状态 0-未发单 1-已发单',
    o_oa_number               varchar(50)   null comment 'oa流程编号'
)
    comment 'PMS采购订单主表 ' row_format = DYNAMIC;

create index index_o_order_number
    on mstb_pms_purchase_order_main (o_order_number);

create table mstb_pms_purchase_order_material
(
    mpom_id                      int(10) auto_increment comment 'id'
        primary key,
    mpom_o_id                    int(10)      null comment '采购订单id',
    mpom_mppm_id                 int(10)      null comment '冗余材料表id,对应于mstb_purchase_plan_material的mppm_id',
    mpom_mpp_id                  int(10)      null comment '提料单表id',
    mpom_mpp_no                  varchar(100) null comment '提料单号',
    mpom_purchaseNumber          int(10)      null comment '采购数量',
    mpom_type                    varchar(2)   null comment '材料编码的类型--1优化单生成的材料 -- 0不需要优化的材料',
    mpom_status                  varchar(2)   null comment '采购单材料状态 1未收货 2已收货 3终止订单 4收货中 8、删除材料流程审核中',
    mpom_intfields1              int(10)      null comment 'int型备用字段',
    mpom_intfields2              int(10)      null,
    mpom_fields1                 varchar(255) null comment '字符型备用字段 --- 特殊处理,便于后面的查询和显示 .如果是优化则保存优化长度,如果不是优化则保存设计尺寸',
    mpom_fields2                 varchar(255) null comment '保存订单材料的来源类型 1,提料单材料 2外协外包材料 3 原材料补货单 4 工地补货单 ',
    mpom_fields3                 varchar(255) null comment '保存订单材料的收货类型.0工地收货 1工厂收货 ',
    mpom_createuser              varchar(20)  null comment '创建人',
    mpom_createdate              varchar(20)  null comment '创建时间',
    mpom_updateuser              varchar(20)  null comment '更新人',
    mpom_updatedate              varchar(20)  null comment '更新时间',
    mpom_psam_id                 int(10)      null comment '设计单材料id,对应于mstb_purchase_plan_material的psam_id',
    mpom_hasReceiving_count      int(10)      null comment '已收货数量',
    mpom_pvId                    int(10)      null comment '材料类型id',
    mpom_proId                   int(10)      null comment '工程项目id',
    mpom_vendorId                varchar(50)  null comment '供应商id',
    mpom_mpv_id                  int(10)      null comment '供应商材料代码对照表 -- id',
    mpom_vendor_symbol           varchar(100) null comment '供应商材料代码对照表 -- 供应商材料代码',
    mpom_yh_length               varchar(20)  null comment 'x型材优化后长度',
    mpom_design_size             varchar(200) null comment '订购尺寸',
    mpom_process_size            varchar(200) null comment '加工尺寸',
    mpom_weight_single           varchar(255) null comment '工程属性详情',
    mpom_optimization_no         varchar(200) null,
    mpom_action_area             varchar(255) null comment '表面处理和颜色',
    mpom_psam_weight             varchar(20)  null comment '重量（Kg）/面积（m2）',
    mpom_plan_total              varchar(10)  null comment '提料单提料数量',
    mpom_psam_code               varchar(500) null comment '材料编号',
    mpom_psam_name               varchar(200) null comment '材料名称',
    mpom_process_draw_number     varchar(50)  null comment '材料工艺图',
    mpom_mppSymbol               varchar(255) null comment '物料工程属性代码',
    mpom_totalWeight             varchar(50)  null comment '单行的总重量/面积',
    mpom_process_draw_numberJson varchar(255) null comment '工艺图名称json格式',
    mpom_genereteModelimg        varchar(100) null comment '铝型材开模图',
    mpom_genereteModelimg_Json   varchar(255) null comment '铝型材开模图Json格式',
    mpom_remark                  varchar(255) null comment '备注',
    mpom_linear_density          varchar(50)  null comment '线密度',
    mpom_curve_making            varchar(10)  null comment '铝型材拉弯',
    mpom_fields4                 varchar(2)   null comment '采购订单材料从表备用字段 -- 用于表名是否锁定当前列表,1表示未锁定,-1表示锁定,-2表示流程通过',
    mpom_fields5                 varchar(50)  null comment '采购订单材料表备用字段 -- 保存铝型材材质',
    mpom_m_type                  varchar(50)  null comment '辅材材料种类',
    mpom_total_purchase          int(10)      null comment '材料采购总量 采购总量等于采购量加上废料使用量',
    mpom_freezed_purchase        int(10)      null comment '废料使用量',
    mpom_flowStatus              varchar(2)   null comment '默认为NULL，0解锁，1加锁',
    jsbz                         varchar(200) null comment '辅材技术标准',
    schd                         varchar(200) null comment '石材厚度',
    pms_po_price                 varchar(100) null comment '成本订单金额',
    pms_po_weight                varchar(100) null comment '成本订单面积/重量'
)
    comment 'PMS采购订单材料详情表' row_format = DYNAMIC;

create table mstb_project
(
    pro_id             int auto_increment comment '主键'
        primary key,
    pro_name           varchar(128)           null comment '项目名称',
    pro_code           varchar(128)           null comment '项目简称',
    pro_address        varchar(512)           null comment '项目地址',
    pro_description    varchar(512)           null comment '项目简介',
    pro_remark         varchar(512)           null comment '备注',
    pro_start_date     varchar(20)            null comment '开始时间',
    pro_expect_enddate varchar(20)            null comment '结束时间',
    pro_option1        varchar(50)            null comment '项目工厂',
    pro_option2        varchar(50)            null comment '项目公司',
    mp_status          varchar(2) default '0' null comment '状态 状态',
    create_user        varchar(20)            null comment '创建人 创建人',
    create_code        varchar(20)            null comment '创建人代码 创建人代码',
    create_time        varchar(20)            null comment '创建时间 创建时间',
    update_user        varchar(20)            null comment '更新人 更新人',
    update_code        varchar(20)            null comment '更新人代码 更新人代码',
    update_time        varchar(20)            null comment '更新时间 更新时间'
)
    comment '项目主表';

create table mstb_project_materials
(
    mpm_id                int auto_increment comment '材料序号'
        primary key,
    psam_code             varchar(128)    null comment '材料编号',
    mma_pt_area           decimal(32, 10) null comment '喷涂面积',
    mma_pt_cost           decimal(32, 8)  null comment '喷涂费用',
    pro_id                int             null comment '项目序号',
    psam_name             varchar(512)    null comment '材料名称',
    prv_id                varchar(2)      null comment '物料类型ID',
    mma_id                varchar(512)    null comment '物料基本属性名称',
    mpm_code              varchar(128)    null comment '物料工程代码',
    psam_weight_single    varchar(512)    null comment '工程属性详情',
    psam_action_area      varchar(512)    null comment '表面处理和颜色',
    psam_design_size      varchar(512)    null comment '订购尺寸',
    psam_process_size     varchar(512)    null comment '加工尺寸',
    psam_tech_requirement varchar(512)    null comment '技术要求',
    psam_unit             varchar(32)     null comment '单位',
    psam_weight           varchar(32)     null comment '重量（Kg）/面积（m2）',
    psam_description      varchar(512)    null comment '备注',
    psam_gyt              varchar(512)    null comment '工艺图',
    psam_jgt              varchar(512)    null comment '生产加工图',
    psam_kmt              varchar(512)    null comment '开模图',
    psam_lw               varchar(32)     null comment '拉弯',
    psam_xmd              varchar(32)     null comment '线密度--冗余物料表数据',
    mpp_basic             varchar(200)    null,
    psam_zl               varchar(200)    null,
    psam_createuser       varchar(20)     null comment '创建人',
    psam_createdate       varchar(20)     null comment '创建时间',
    psam_updateuser       varchar(20)     null comment '更新人',
    psam_updatedate       varchar(20)     null comment '更新时间'
)
    comment '项目材料表';

create index index_mmrm_id
    on mstb_project_materials (mpm_id);

create index index_pro_id
    on mstb_project_materials (pro_id);

create index unit_code
    on mstb_project_materials (pro_id, prv_id, psam_code);

create table mstb_project_staff
(
    mps_id          int auto_increment comment '序号'
        primary key,
    pro_id          int         null comment '项目序号',
    usercode        varchar(32) null comment '用户代码',
    username        varchar(64) null comment '用户姓名',
    plan_staff_type varchar(32) null comment '人员安排角色',
    mps_status      varchar(2)  null comment '状态',
    create_user     varchar(20) null comment '创建人',
    create_code     varchar(20) null comment '创建人代码',
    create_time     varchar(20) null comment '创建时间',
    update_user     varchar(20) null comment '更新人',
    update_code     varchar(20) null comment '更新人代码',
    update_time     varchar(20) null comment '更新时间'
)
    comment '人员安排表';

create index mstb_project_staff_usercode_index
    on mstb_project_staff (usercode);

create table mstb_purchase_order_material_vpo_extend_approval
(
    mpom_id                      int                    null comment 'id',
    mpom_o_id                    int                    null comment '采购订单id',
    mpom_mppm_id                 int                    null comment '冗余材料表id,对应于mstb_purchase_plan_material的mppm_id',
    mpom_mpp_id                  int                    null comment '提料单表id',
    mpom_mpp_no                  varchar(100)           null comment '提料单号',
    mpom_purchaseNumber          int                    null comment '采购数量',
    mpom_type                    varchar(2)             null comment '材料编码的类型--1优化单生成的材料 -- 0不需要优化的材料',
    mpom_status                  varchar(2)             null comment '审核单材料状态，0，未提交，1，已提交，9，失效',
    mpom_intfields1              int                    null comment 'int型备用字段',
    mpom_intfields2              int                    null comment 'int型备用字段2',
    mpom_fields1                 varchar(255)           null comment '字符型备用字段 --- 特殊处理,便于后面的查询和显示 .如果是优化则保存优化长度,如果不是优化则保存设计尺寸',
    mpom_fields2                 varchar(255)           null comment '保存订单材料的来源类型 1,提料单材料 2外协外包材料 3 原材料补货单 4 工地补货单 ',
    mpom_fields3                 varchar(255)           null comment '保存订单材料的收货类型.0工地收货 1工厂收货 ',
    mpom_createuser              varchar(20)            null comment '创建人
',
    mpom_createdate              varchar(20)            null comment '创建时间
',
    mpom_updateuser              varchar(20)            null comment '更新人',
    mpom_updatedate              varchar(20)            null comment '更新时间',
    mpom_psam_id                 int                    null comment '设计单材料id,对应于mstb_purchase_plan_material的psam_id',
    mpom_hasReceiving_count      int        default 0   null comment '已收货数量',
    mpom_pvId                    int                    null comment '材料类型id',
    mpom_proId                   int                    null comment '工程项目id',
    mpom_vendorId                varchar(50)            null comment '供应商id',
    mpom_mpv_id                  int                    null comment '供应商材料代码对照表 -- id',
    mpom_vendor_symbol           varchar(100)           null comment '供应商材料代码对照表 -- 供应商材料代码',
    mpom_yh_length               varchar(20)            null comment 'x型材优化后长度',
    mpom_design_size             varchar(200)           null comment '设计尺寸',
    mpom_process_size            varchar(200)           null comment '加工尺寸',
    mpom_weight_single           varchar(255)           null comment '工程属性详情',
    mpom_optimization_no         varchar(200)           null,
    mpom_action_area             varchar(255)           null comment '表面处理和颜色',
    mpom_psam_weight             varchar(20)            null comment '重量（Kg）/面积（m2）',
    mpom_plan_total              varchar(10)            null comment '提料单提料数量',
    mpom_psam_code               varchar(500)           null comment '材料编号',
    mpom_psam_name               varchar(200)           null comment '材料名称',
    mpom_process_draw_number     varchar(50)            null comment '材料工艺图',
    mpom_mppSymbol               varchar(255)           null comment '物料工程属性代码',
    mpom_totalWeight             varchar(50)            null comment '单行的总重量/面积',
    mpom_process_draw_numberJson varchar(255)           null comment '工艺图名称json格式',
    mpom_genereteModelimg        varchar(100)           null comment '铝型材开模图',
    mpom_genereteModelimg_Json   varchar(255)           null comment '铝型材开模图Json格式',
    mpom_remark                  varchar(255)           null comment '备注',
    mpom_linear_density          varchar(50)            null comment '线密度',
    mpom_curve_making            varchar(10)            null comment '铝型材拉弯',
    mpom_fields4                 varchar(2) default '1' null comment '采购订单材料从表备用字段 -- 用于表名是否锁定当前列表,1表示未锁定,-1表示锁定,-2表示流程通过',
    mpom_fields5                 varchar(50)            null comment '采购订单材料表备用字段 -- 保存铝型材材质',
    mpom_m_type                  varchar(50)            null comment '辅材材料种类',
    mpom_total_purchase          int                    null comment '材料采购总量 采购总量等于采购量加上废料使用量',
    mpom_freezed_purchase        int                    null comment '废料使用量',
    mpom_flowStatus              varchar(2)             null comment '默认为NULL，0解锁，1加锁',
    jsbz                         varchar(200)           null comment '辅材技术标准',
    schd                         varchar(200)           null comment '石材厚度',
    mpom_send_amount             varchar(50)            null comment '材料发货数量',
    pms_po_price                 varchar(100)           null comment '成本订单金额',
    pms_po_weight                varchar(100)           null comment '成本订单面积/重量',
    vpo_extend_sa_submit_price   varchar(50)            null comment '预结算单价',
    vpo_extend_sa_price          varchar(50)            null comment '合同单价',
    vpo_extend_sa_createtime     varchar(20)            null comment '合同单价创建时间',
    vpo_extend_sa_createuser     varchar(20)            null comment '合同单价创建人',
    vpo_extend_sa_updatetime     varchar(20)            null comment '合同单价更新时间',
    vpo_extend_sa_updateuser     varchar(20)            null comment '合同单价更新人',
    tep_id                       int                    not null comment '预结算审核单序号',
    tep_detail_id                int auto_increment comment '预结算审核单详情序号'
        primary key,
    vpo_extend_att_00            varchar(100)           null comment '附加属性00，钢材线密度',
    vpo_extend_att_01            varchar(100)           null comment '附加属性01，钢材黑材单价',
    vpo_extend_att_02            varchar(100)           null comment '附加属性02，钢材工艺图单价',
    vpo_extend_att_03            varchar(100)           null comment '附加属性03',
    vpo_extend_att_04            varchar(100)           null comment '附加属性04',
    vpo_extend_att_05            varchar(100)           null comment '附加属性05',
    vpo_extend_att_06            varchar(100)           null comment '附加属性06',
    vpo_extend_att_07            varchar(100)           null comment '附加属性07',
    vpo_extend_att_08            varchar(100)           null comment '附加属性08',
    vpo_extend_att_09            varchar(100)           null comment '附加属性09',
    vpo_extend_att_10            varchar(100)           null comment '附加属性10',
    vpo_extend_att_11            varchar(200)           null comment '附加属性11',
    vpo_extend_att_12            varchar(200)           null comment '附加属性12',
    vpo_extend_att_13            varchar(200)           null comment '附加属性13',
    vpo_extend_att_14            varchar(200)           null comment '附加属性14',
    vpo_extend_att_15            varchar(200)           null comment '附加属性15',
    vpo_extend_att_16            varchar(200)           null comment '附加属性16',
    vpo_extend_att_17            varchar(200)           null comment '附加属性17',
    vpo_extend_att_18            varchar(200)           null comment '附加属性18',
    vpo_extend_att_19            varchar(200)           null comment '附加属性19',
    vpo_extend_att_20            varchar(200)           null comment '附加属性20',
    vpo_extend_att_json          text                   null comment '存储扩展JSON属性，基础信息和即将生效属性都在'
)
    comment '增值服务，预结算审核单详情';

create index mstb_purchase_order_material_vpo_extend_approval_tep_id_index
    on mstb_purchase_order_material_vpo_extend_approval (tep_id);

create table mstb_transport_root
(
    mtm_id               int auto_increment comment '序号'
        primary key,
    mtm_pro              int          not null comment '项目序号',
    mtm_vendor           varchar(50)  not null comment '供应商序号',
    mtm_vendor_cn        varchar(50)  not null comment '供应商名称，中文',
    mtm_number           varchar(50)  not null comment '发货单号',
    mtm_pv               int          not null comment '发货单类型，对照材料序号',
    mtm_express_number   varchar(100) not null comment '供应商手填运货单号',
    mtm_total_amount     double       null comment '发货单总数量，依据材料明细得出',
    mtm_total_weight     double       null comment '总重',
    mtm_status           int          not null comment '状态
            0：待收货
            1：方大已收货
            2：方大弃用',
    mtm_createtime       varchar(20)  not null,
    mtm_createuser       varchar(20)  not null,
    mtm_updatetime       varchar(20)  null,
    mtm_updateuser       varchar(20)  null,
    mtm_pro_name         varchar(200) not null comment '项目名称',
    mtm_address          varchar(200) not null comment '发货地址',
    mtm_receiver         varchar(200) not null comment '方大收货人',
    mtm_receiver_mobile  varchar(200) not null comment '方大收货人联系方式',
    mtm_remark           varchar(255) null comment '发货单单备注',
    vpo_extend_sa_status int          null comment ' 结算状态，ID#30025-结算状态',
    vpo_extend_sa_time   varchar(20)  null comment ' 结算时间 ',
    vpo_extend_sa_user   varchar(20)  null comment ' 结算人 ',
    mtm_from_type        int(1)       null comment '发货单所属 0-pms 1-mes',
    mtm_attachmentfile   varchar(200) null comment '附件名称'
)
    comment '发货单主对象' row_format = DYNAMIC;

create table mstb_vendor_extend_transport_root_approval
(
    mtm_id                       int          null comment '序号',
    mtm_pro                      int          not null comment '项目序号',
    mtm_vendor                   varchar(50)  not null comment '供应商序号',
    mtm_vendor_cn                varchar(50)  not null comment '供应商名称，中文',
    mtm_number                   varchar(50)  not null comment '发货单号',
    mtm_pv                       int          not null comment '发货单类型，对照材料序号',
    mtm_express_number           varchar(100) not null comment '供应商手填运货单号',
    mtm_total_amount             double       null comment '发货单总数量，依据材料明细得出',
    mtm_total_weight             double       null comment '总重',
    mtm_status                   int          not null comment '状态
                        0：待收货
                        1：方大已收货
                        2：方大弃用',
    mtm_createtime               varchar(20)  not null comment '创建时间',
    mtm_createuser               varchar(20)  not null comment '创建人',
    mtm_updatetime               varchar(20)  null comment '更新人',
    mtm_updateuser               varchar(20)  null comment '更新时间',
    mtm_pro_name                 varchar(200) not null comment '项目名称',
    mtm_address                  varchar(200) not null comment '发货地址',
    mtm_receiver                 varchar(200) not null comment '方大收货人',
    mtm_receiver_mobile          varchar(200) not null comment '方大收货人联系方式',
    mtm_remark                   varchar(255) null comment '发货单单备注',
    vpo_extend_create_status     int          null comment '提交状态',
    vpo_extend_status            int          null comment '审核单状态',
    vpo_extend_id_approval       int auto_increment comment '审核单序号'
        primary key,
    vpo_extend_number            varchar(50)  null comment '审核单单号',
    vpo_extend_createtime        varchar(20)  null comment '审核单创建时间',
    vpo_extend_submit_time       varchar(20)  null comment '审核单提交时间',
    vpo_extend_submit_user       varchar(20)  null comment '审核单提交人',
    vpo_extend_materials_cost    varchar(200) null comment '材料费用',
    vpo_extend_transfer_cost     varchar(200) null comment '运费',
    vpo_extend_other_cost        varchar(200) null comment '其他费用',
    vpo_extend_remark            varchar(200) null comment '备注',
    vpo_extend_attachmentfile    varchar(200) null comment '附件名称',
    vpo_extend_updatetime        varchar(20)  null comment '更新时间',
    vpo_extend_updateuser        varchar(20)  null comment '更新人',
    vpo_extend_transfer_ck_cost  varchar(200) null comment '超宽费用',
    vpo_extend_transfer_dc_cost  varchar(200) null comment '定尺/倍尺费',
    vpo_extend_transfer_lw_cost  varchar(200) null comment '拉弯费',
    vpo_extend_other_cost_remark varchar(200) null comment '其他费用说明',
    vpo_extend_transfer_cost_01  text         null comment '扩展费用01',
    vpo_extend_transfer_cost_02  text         null comment '扩展费用02',
    vpo_extend_transfer_cost_03  text         null comment '扩展费用03',
    mtm_con_id                   int          null comment '合同序号',
    mtm_con_no                   varchar(100) null comment '合同编号',
    vpo_extend_end_date          varchar(20)  null comment '审核结束时间'
)
    comment '增值服务-货单-审核单';

create table mstb_vpo_extend_contract_approval
(
    ca_id           int auto_increment comment '序号'
        primary key,
    ca_number       varchar(50)   not null comment '审核单编号',
    ca_pro          int           not null comment '审核单所属项目',
    ca_type         int           not null comment '审核单提交的类型。ID#D30008-审核单类型',
    ca_pv_type      int           not null comment '审核单类型，对应材料类型',
    ca_content_type int           not null comment '审核单内容,ID#D30005-合同审核单-审核内容	0材料单价1开模费',
    ca_con_id       int           not null comment '审核单所属合同',
    ca_att_name     varchar(100)  not null comment '审核的附件名称',
    ca_sub_amount   varchar(50)   null comment '审核单审核数量',
    ca_status       int default 0 not null comment '审核单状态，字典，#D30006',
    ca_createtime   varchar(20)   not null comment '审核单创建时间',
    ca_createuser   varchar(20)   not null comment '审核单创建人',
    ca_updatetime   varchar(20)   null comment '审核单更新时间',
    ca_updateuser   varchar(20)   null comment '审核单更新人',
    ca_pro_name     varchar(100)  not null comment '项目名称',
    ca_vendor_name  varchar(100)  not null comment '供应商名称',
    ca_actived_date varchar(20)   not null comment '生效时间',
    ca_modify_from  varchar(20)   null comment '修改单价的起始时间',
    ca_modify_end   varchar(20)   null comment '修改单价的终止时间',
    ca_con_no       varchar(50)   null comment '合同编号',
    ca_con_name     varchar(50)   null comment '合同名称',
    ca_end_date     varchar(20)   null comment '审核结束时间',
    ca_copy_con_id  int           null comment '克隆目标合同'
)
    comment '合同单价审核单v2';

create table mstb_vpo_extend_contract_base_data_approval
(
    mcd_id           int          not null comment '序号',
    ca_id            int          not null comment '审核单序号',
    t_id             int auto_increment comment '审核序号'
        primary key,
    mcd_con          int          null comment '合同序号',
    mcd_pro          int          null comment '项目序号',
    mcd_pv           int          null comment '材料类型，09种',
    mcd_code         varchar(200) null comment '材料代码',
    mcd_design_size  varchar(200) null comment '设计尺寸',
    mcd_mpp_code     varchar(200) null comment '工程属性代码',
    mcd_mpp_detail   varchar(200) null comment '工程属性详情',
    mcd_action_area  varchar(200) null comment '表面处理',
    mcd_process_json varchar(200) null comment '工艺图JSON',
    mcd_weight       varchar(200) null comment '单重',
    mcd_price        varchar(200) null comment '加工价',
    mcd_att_01       varchar(200) null comment '属性01',
    mcd_att_02       varchar(200) null comment '属性02',
    mcd_att_03       varchar(200) null comment '属性03',
    mcd_att_04       varchar(200) null comment '属性04',
    mcd_status       int          null comment '状态，0：可用，9：弃用',
    mcd_createtime   varchar(20)  null comment '创建时间',
    mcd_createuser   varchar(20)  null comment '创建人',
    mcd_updatetime   varchar(20)  null comment '更新时间',
    mcd_updateuser   varchar(20)  null comment '更新人',
    mcd_show_type    int(1)       null comment '显示类型 1-修改前数据 2-修改后数据'
)
    comment '合同-材料数据-审核单详情';

create table mstb_vpo_extend_transport_main_detail_approval
(
    mtm_id                        int          not null comment '主对象id',
    mtr_id                        int          not null comment '二级对象序号',
    mtmd_id                       int          null comment '序号',
    mtmd_amount                   double       not null comment '发货数量',
    mtmd_status                   int          not null comment '采购单材料状态
                         1未收货 2已收货 3终止',
    mtmd_createuser               varchar(20)  not null comment '创建人',
    mtmd_createdate               varchar(20)  not null comment '创建时间',
    mtmd_updateuser               varchar(20)  null comment '更新人',
    mtmd_updatedate               varchar(20)  null comment '更新时间',
    mtmd_receiving_count          int          null comment '已收货数量',
    mtmd_pv_id                    int          not null comment '材料类型id',
    mtmd_pro_id                   int          not null comment '工程项目id',
    mtmd_vendor_id                varchar(50)  not null comment '供应商id',
    mtmd_vendor_symbol            varchar(100) null comment '供应商材料代码',
    mtmd_yh_length                varchar(20)  null comment '型材优化后长度',
    mtmd_design_size              varchar(200) null comment '设计尺寸',
    mtmd_process_size             varchar(200) null comment '加工尺寸',
    mtmd_weight_single            varchar(255) null comment '工程属性详情',
    mtmd_action_area              varchar(255) null comment '表面处理和颜色',
    mtmd_psam_weight              varchar(20)  null comment '重量（Kg）/面积（m2）',
    mtmd_plan_total               varchar(10)  null comment '提料单提料数量',
    mtmd_psam_code                varchar(500) null comment '材料编号',
    mtmd_psam_name                varchar(200) null comment '材料名称',
    mtmd_process_draw_number      varchar(50)  null comment '材料工艺图',
    mtmd_mpp_id                   varchar(255) null comment '物料工程属性代码',
    mtmd_total_weight             varchar(50)  null comment '单行的总重量/面积',
    mtmd_process_draw_numberJson  varchar(255) null comment '工艺图名称json格式',
    mtmd_generete_modelimg        varchar(100) null comment '铝型材开模图',
    mtmd_generete_modelimg_json   varchar(255) null comment '铝型材开模图Json格式',
    mtmd_remark                   varchar(255) null comment '备注',
    mtmd_linear_density           varchar(50)  null comment '线密度',
    mtmd_curve_making             varchar(10)  null comment '铝型材拉弯',
    mtmd_address                  int          not null comment '收货地址标示',
    mtmd_po_id                    int          not null comment '材料原始对应订单序号',
    mtmd_po_mid                   int          not null comment '材料原始对应订单材料序号',
    mtmd_po_number                varchar(50)  null comment '订单编号',
    vpo_extend_status             int          null comment '审核状态，和审核单同步，审核单弃用，则这里也是弃用',
    vpo_extend_id_approval        int          null comment '审核单序号',
    vpo_extend_id_approval_detail int auto_increment comment '详情序号'
        primary key,
    vpo_extend_price              varchar(50)  null comment '材料单价',
    vpo_extend_price_reserve      varchar(50)  null comment '材料保留单价',
    vpo_extend_remark             varchar(255) null comment '增值服务备注',
    vpo_extend_con_id             int          not null comment '合同序号',
    vpo_extend_updatetime         varchar(20)  null comment '审核单更新时间',
    vpo_extend_updateuser         varchar(20)  null comment '审核单更新人',
    vpo_extend_att_00             varchar(200) null comment '附加属性00',
    vpo_extend_att_01             varchar(200) null comment '附加属性01',
    vpo_extend_att_02             varchar(200) null comment '附加属性02',
    vpo_extend_att_03             varchar(200) null comment '附加属性03',
    vpo_extend_att_04             varchar(200) null comment '附加属性04',
    vpo_extend_att_05             varchar(200) null comment '附加属性05',
    vpo_extend_att_06             varchar(200) null comment '附加属性06',
    vpo_extend_att_07             varchar(200) null comment '附加属性07',
    vpo_extend_att_08             varchar(200) null comment '附加属性08',
    vpo_extend_att_09             varchar(200) null comment '附加属性09',
    vpo_extend_att_10             varchar(200) null comment '附加属性10',
    vpo_extend_att_11             varchar(200) null comment '附加属性11',
    vpo_extend_att_12             varchar(200) null comment '附加属性12',
    vpo_extend_att_13             varchar(200) null comment '附加属性13',
    vpo_extend_att_14             varchar(200) null comment '附加属性14',
    vpo_extend_att_15             varchar(200) null comment '附加属性15',
    vpo_extend_att_16             varchar(200) null comment '附加属性16',
    vpo_extend_att_17             varchar(200) null comment '附加属性17',
    vpo_extend_att_18             varchar(200) null comment '附加属性18',
    vpo_extend_att_19             varchar(200) null comment '附加属性19',
    vpo_extend_att_20             varchar(200) null comment '附加属性20',
    vpo_extend_att_json           text         null comment '存储扩展JSON属性，基础信息和即将生效属性都在'
)
    comment '增值服务，发货单详情-审核';

create table tstb_accounting
(
    ma_id                int             null comment '结算主表序号',
    ta_id                int auto_increment comment '结算从表序号'
        primary key,
    po_id                int             null comment '订单序号',
    po_number            varchar(128)    null comment '订单编号',
    po_date              varchar(32)     null comment '订单发出日期',
    psam_code            varchar(200)    null comment '材料编号',
    vendor_code          varchar(32)     null comment '供应商代码',
    pt_area              decimal(32, 8)  null comment '喷涂面积',
    pt_cost              decimal(32, 8)  null comment '喷涂费用',
    ta_amount            decimal(32, 10) null comment '结算数量',
    ta_total_weight      decimal(32, 10) null comment '总重',
    ta_gross_area        decimal(32, 10) null comment '总面积',
    ta_total_cost        decimal(32, 10) null comment '总费用',
    ta_status            varchar(2)      null comment '状态',
    ta_createuser        varchar(20)     null comment '创建人',
    ta_createusercode    varchar(20)     null comment '创建人代码',
    ta_createdate        varchar(20)     null comment '创建时间',
    ta_updateuser        varchar(20)     null comment '更新人',
    ta_updateusercode    varchar(20)     null comment '更新人代码',
    ta_updatedate        varchar(20)     null comment '更新时间',
    mpm_id               int             null comment '材料id',
    ta_square_meter_cost decimal(32, 10) null comment '平方米费用',
    ta_other_fees        decimal(32, 10) null comment '其他费用'
)
    comment '结算详情表';

create table tstb_accounting_attachment
(
    taa_id              int auto_increment
        primary key,
    ma_id               int           null comment '结算单序号',
    taa_attachment_name varchar(255)  null comment '结算单-附件名称',
    taa_attachment_path varchar(500)  null comment '结算单-附件路径
/cost/attachment/2021/02/25/dafsdfasfsfasfadsfadsfads。pdf',
    mtm_attachment_name varchar(255)  null comment '发货单附件名称',
    mtm_attachment_path varchar(500)  null comment '发货单附件序号
结算单-附件路径
/cost/attachment/2021/02/25/dafsdfasfsfasfadsfadsfads。pdf',
    mtm_original_name   varchar(255)  null comment '发货单附件原始名称',
    taa_original_name   varchar(255)  null comment '结算单附件原始名称',
    mtm_id              int           null comment '发货单序号',
    taa_status          int default 0 not null comment '状态，0：正常，1：弃用',
    taa_createtime      varchar(20)   not null comment '创建时间',
    taa_createuser      varchar(20)   not null comment '创建人',
    taa_updatetime      varchar(20)   null comment '更新时间',
    taa_updateuser      varchar(20)   null comment '更新人'
)
    comment '结算单附件表';

create table tstb_bl_cost_process_image
(
    tp_id                    int auto_increment comment '序号'
        primary key,
    tp_pro_id                int          null comment '项目序号',
    tp_process_image_id      int          null comment '工艺图序号',
    tp_process_image_name    varchar(100) null comment '工艺图名称',
    tp_process_image_version varchar(50)  null comment '工艺图版本',
    tp_process_image_json    varchar(100) null comment '工艺图json',
    tp_att_00                varchar(100) null comment '其他属性00',
    tp_att_01                varchar(100) null comment '其他属性01',
    tp_att_02                varchar(100) null comment '其他属性02',
    tp_att_03                varchar(100) null comment '其他属性03',
    tp_att_04                varchar(100) null comment '其他属性04',
    tp_att_05                varchar(100) null comment '其他属性05',
    tp_att_06                varchar(100) null comment '其他属性06',
    tp_att_07                varchar(100) null comment '其他属性07',
    tp_att_08                varchar(100) null comment '其他属性08',
    tp_att_09                varchar(100) null comment '其他属性09',
    tp_att_10                varchar(100) null comment '其他属性10',
    tp_att_11                varchar(100) null comment '其他属性11',
    tp_att_12                varchar(100) null comment '其他属性12',
    tp_att_13                varchar(100) null comment '其他属性13',
    tp_att_14                varchar(100) null comment '其他属性14',
    tp_att_15                varchar(100) null comment '其他属性15',
    tp_att_16                varchar(100) null comment '其他属性16',
    tp_att_17                varchar(100) null comment '其他属性17',
    tp_att_18                varchar(100) null comment '其他属性18',
    tp_att_19                varchar(100) null comment '其他属性19',
    tp_att_20                varchar(100) null comment '其他属性20',
    tp_status                int          null comment '状态: 0 正常，9 弃用',
    tp_createtime            varchar(50)  null comment '创建时间',
    tp_createuser            varchar(50)  null comment '创建人',
    tp_updatetime            varchar(50)  null comment '更新时间',
    tp_updateuser            varchar(50)  null comment '更新人'
)
    comment '玻璃工艺图';

create table tstb_bl_cost_process_image_not_entered
(
    tpnt_id                    int auto_increment comment '序号'
        primary key,
    tpnt_pro_id                int           null comment '项目序号',
    tpnt_pro_name              varchar(128)  null comment '项目名称',
    tpnt_process_image_name    varchar(100)  null comment '工艺图名称',
    tpnt_process_image_version varchar(50)   null comment '工艺图版本',
    tpnt_process_image_json    varchar(1000) null comment '工艺图版本Json',
    tpnt_status                int           null comment '状态 1.未录入 2.已录入',
    tpnt_createtime            varchar(50)   null comment '创建时间',
    tpnt_createuser            varchar(50)   null comment '创建人',
    tpnt_updatetime            varchar(50)   null comment '更新时间',
    tpnt_updateuser            varchar(50)   null comment '更新人'
)
    comment '玻璃工艺图录入状态';

create index nb_proId
    on tstb_bl_cost_process_image_not_entered (tpnt_pro_id);

create index nb_proId_processImageName_processImageVersion
    on tstb_bl_cost_process_image_not_entered (tpnt_pro_id, tpnt_process_image_name, tpnt_process_image_version);

create index nb_status
    on tstb_bl_cost_process_image_not_entered (tpnt_status);

create table tstb_bl_market_price
(
    tb_id         int auto_increment comment '序号'
        primary key,
    tb_date       varchar(10) not null comment '价格所属日期,yyyy-MM-dd',
    tb_bb_xy      varchar(50) null comment '白玻-信义',
    tb_bb_nb      varchar(50) null comment '白玻-南玻',
    tb_bb_qb      varchar(50) null comment '白玻-旗滨',
    tb_cbb_xy     varchar(50) null comment '超白玻-信义',
    tb_cbb_nb     varchar(50) null comment '超白玻-南玻',
    tb_cbb_qb     varchar(50) null comment '超白玻-旗滨',
    tb_status     int         null comment '状态，0：未录入全部价格，1：全部未录入，2：全部已录入',
    tb_bb_json    text        null comment '其他扩展属性，JSON格式，对应JSON配置对象返回值，例如{''name1'':''超黑'',''name2'':''100'',''name3'':''超红'',''name4'':''1003''}',
    tb_createtime varchar(50) null comment '创建时间',
    tb_createuser varchar(50) null comment '创建人',
    tb_updatetime varchar(50) null comment '更新时间',
    tb_updateuser varchar(50) null comment '更新人',
    tb_sc_300     text        null comment '动态增加列00',
    tb_sc_301     text        null comment '动态增加列01',
    tb_sc_302     text        null comment '动态增加列02',
    tb_sc_303     text        null comment '动态增加列03',
    tb_sc_304     text        null comment '动态增加列04',
    tb_sc_305     text        null comment '动态增加列05',
    tb_sc_306     text        null comment '动态增加列06',
    tb_sc_307     text        null comment '动态增加列07',
    tb_sc_308     text        null comment '动态增加列08',
    tb_sc_309     text        null comment '动态增加列09',
    tb_sc_310     text        null comment '动态增加列10',
    tb_sc_311     text        null comment '动态增加列11',
    tb_sc_312     text        null comment '动态增加列12',
    tb_sc_313     text        null comment '动态增加列13',
    tb_sc_314     text        null comment '动态增加列14',
    tb_sc_315     text        null comment '动态增加列15',
    tb_sc_316     text        null comment '动态增加列16',
    tb_sc_317     text        null comment '动态增加列17',
    tb_sc_318     text        null comment '动态增加列18',
    tb_sc_319     text        null comment '动态增加列19',
    tb_sc_320     text        null comment '动态增加列20',
    tb_sc_321     text        null comment '动态增加列21',
    tb_sc_322     text        null comment '动态增加列22',
    tb_sc_323     text        null comment '动态增加列23',
    tb_sc_324     text        null comment '动态增加列24',
    tb_sc_325     text        null comment '动态增加列25',
    tb_sc_326     text        null comment '动态增加列26',
    tb_sc_327     text        null comment '动态增加列27',
    tb_sc_328     text        null comment '动态增加列28',
    tb_sc_329     text        null comment '动态增加列29',
    tb_sc_330     text        null comment '动态增加列30',
    tb_sc_331     text        null comment '动态增加列31',
    tb_sc_332     text        null comment '动态增加列32',
    tb_sc_333     text        null comment '动态增加列33',
    tb_sc_334     text        null comment '动态增加列34',
    tb_sc_335     text        null comment '动态增加列35',
    tb_sc_336     text        null comment '动态增加列36',
    tb_sc_337     text        null comment '动态增加列37',
    tb_sc_338     text        null comment '动态增加列38',
    tb_sc_339     text        null comment '动态增加列39',
    tb_sc_340     text        null comment '动态增加列40',
    tb_sc_341     text        null comment '动态增加列41',
    tb_sc_342     text        null comment '动态增加列42',
    tb_sc_343     text        null comment '动态增加列43',
    tb_sc_344     text        null comment '动态增加列44',
    tb_sc_345     text        null comment '动态增加列45',
    tb_sc_346     text        null comment '动态增加列46',
    tb_sc_347     text        null comment '动态增加列47',
    tb_sc_348     text        null comment '动态增加列48',
    tb_sc_349     text        null comment '动态增加列49',
    tb_sc_350     text        null comment '动态增加列50',
    tb_sc_351     text        null comment '动态增加列51',
    tb_sc_352     text        null comment '动态增加列52',
    tb_sc_353     text        null comment '动态增加列53',
    tb_sc_354     text        null comment '动态增加列54',
    tb_sc_355     text        null comment '动态增加列55',
    tb_sc_356     text        null comment '动态增加列56',
    tb_sc_357     text        null comment '动态增加列57',
    tb_sc_358     text        null comment '动态增加列58',
    tb_sc_359     text        null comment '动态增加列59',
    tb_sc_360     text        null comment '动态增加列60',
    tb_sc_361     text        null comment '动态增加列61',
    tb_sc_362     text        null comment '动态增加列62',
    tb_sc_363     text        null comment '动态增加列63',
    tb_sc_364     text        null comment '动态增加列64',
    tb_sc_365     text        null comment '动态增加列65',
    tb_sc_366     text        null comment '动态增加列66',
    tb_sc_367     text        null comment '动态增加列67',
    tb_sc_368     text        null comment '动态增加列68',
    tb_sc_369     text        null comment '动态增加列69',
    tb_sc_370     text        null comment '动态增加列70',
    tb_sc_371     text        null comment '动态增加列71',
    tb_sc_372     text        null comment '动态增加列72',
    tb_sc_373     text        null comment '动态增加列73',
    tb_sc_374     text        null comment '动态增加列74',
    tb_sc_375     text        null comment '动态增加列75',
    tb_sc_376     text        null comment '动态增加列76',
    tb_sc_377     text        null comment '动态增加列77',
    tb_sc_378     text        null comment '动态增加列78',
    tb_sc_379     text        null comment '动态增加列79',
    tb_sc_380     text        null comment '动态增加列80',
    tb_sc_381     text        null comment '动态增加列81',
    tb_sc_382     text        null comment '动态增加列82',
    tb_sc_383     text        null comment '动态增加列83',
    tb_sc_384     text        null comment '动态增加列84',
    tb_sc_385     text        null comment '动态增加列85',
    tb_sc_386     text        null comment '动态增加列86',
    tb_sc_387     text        null comment '动态增加列87',
    tb_sc_388     text        null comment '动态增加列88',
    tb_sc_389     text        null comment '动态增加列89',
    tb_sc_390     text        null comment '动态增加列90',
    tb_sc_391     text        null comment '动态增加列91',
    tb_sc_392     text        null comment '动态增加列92',
    tb_sc_393     text        null comment '动态增加列93',
    tb_sc_394     text        null comment '动态增加列94',
    tb_sc_395     text        null comment '动态增加列95',
    tb_sc_396     text        null comment '动态增加列96',
    tb_sc_397     text        null comment '动态增加列97',
    tb_sc_398     text        null comment '动态增加列98',
    tb_sc_399     text        null comment '动态增加列99'
)
    comment '玻璃行情价-Table';

create table tstb_bl_po_approval_market
(
    tm_id             int auto_increment comment '序号'
        primary key,
    tm_po_date        varchar(20)  not null comment '下单时间',
    tm_market_from    varchar(20)  not null comment '行情价取自',
    tm_type           int          null comment '类型，0：调价，1：不调价',
    tm_formula        varchar(200) null comment '公式',
    tm_formula_sub    varchar(200) null comment '子公式',
    tm_formula_logic  varchar(200) null comment '正负逻辑',
    tm_formula_yz     int          null comment '阈值类型，0，百分比，1，数字',
    tm_limited_number varchar(50)  null comment '阈值',
    tm_ca_id          int          null comment '审核单序号',
    tm_con_id         int          null comment '合同序号',
    tm_status         int          null comment '状态: 0 正常，9 弃用',
    tm_createtime     varchar(50)  null comment '创建时间',
    tm_createuser     varchar(50)  null comment '创建人',
    tm_updatetime     varchar(50)  null comment '更新时间',
    tm_updateuser     varchar(50)  null comment '更新人'
)
    comment '玻璃预结算单审核单-合同调价信息';

create table tstb_bl_po_approval_market_detail
(
    td_id         int auto_increment comment '序号'
        primary key,
    td_ca_id      int         not null comment '审核单序号',
    td_con_id     int         not null comment '合同序号',
    td_jp_type    varchar(50) null comment '基片类型，白玻。超白玻',
    td_jp_qy      varchar(50) null comment '签约基价',
    td_jp_sc      varchar(50) null comment '参考市场，信义，南玻',
    td_jp_hq      varchar(50) null comment '行情价',
    td_jp_tj      varchar(50) null comment '是否调价。0：是，1：否',
    td_status     int         null comment '状态: 0 正常，9 弃用',
    td_createtime varchar(50) null comment '创建时间',
    td_createuser varchar(50) null comment '创建人',
    td_updatetime varchar(50) null comment '更新时间',
    td_updateuser varchar(50) null comment '更新人'
)
    comment '玻璃预结算单审核单-调价信息';

create table tstb_drawing_version
(
    tdv_id             int auto_increment comment '序号'
        primary key,
    pro_id             int          not null comment '项目id',
    pv_id              varchar(1)   not null comment '材料类型',
    att_id             bigint(1)    not null comment '附件id',
    tdv_draw_name      varchar(255) null comment '图名称',
    tdv_file_name      varchar(255) null comment '图文件名',
    tdv_draw_type      varchar(1)   not null comment '图纸类型:0.加工图 1.工艺图 2.组装图 3.大样图',
    tdv_version_number varchar(10)  not null comment '图纸版本号',
    tdv_status         varchar(1)   null comment '状态',
    tdv_createdate     varchar(20)  null comment '上传时间',
    tdv_createuser     varchar(20)  null comment '上传人',
    tdv_createUsercode varchar(20)  null comment '上传人编号',
    tdv_updatedate     varchar(20)  null comment '更新时间',
    tdv_updateuser     varchar(20)  null comment '更新人',
    tdv_updateUsercode varchar(20)  null comment '更新人编号',
    tdv_option1        varchar(500) null comment '备用字段1',
    tdv_option2        varchar(500) null comment '备用字段2',
    tdv_original_id    int          not null comment '图纸原始id'
)
    comment '图纸版本表' row_format = DYNAMIC;

create table tstb_gc_market_price_with_po
(
    tm_id                  int auto_increment comment '序号'
        primary key,
    po_id                  int                          null comment '订单序号',
    tm_att_00              varchar(100)                 null comment '原材料基价',
    tm_att_01              varchar(100)                 null comment '下单日市场行情价',
    tm_att_02              varchar(100)                 null comment '调价',
    tm_att_03              varchar(100)                 null comment '其他属性03',
    tm_att_04              varchar(100)                 null comment '其他属性04',
    tm_att_05              varchar(100)                 null comment '其他属性05',
    tm_is_price_adjustment int(3)      default 1        null comment '是否进行合同调价(1.合同调价 2.合同不调价)',
    tm_status              int         default 0        not null comment '状态，0：正常，9：失败',
    tm_createtime          varchar(20)                  not null comment '创建日期，yyyy-MM-dd HH:mm:ss',
    tm_createuser          varchar(20) default 'system' null comment '创建人',
    tm_updatetime          varchar(20)                  null comment '更新日期，yyyy-MM-dd HH:mm:ss',
    tm_updateuser          varchar(20)                  null comment '更新人',
    tpo_id                 int                          null comment '审核单序号'
)
    comment '钢材订单，调价信息';

create table tstb_lxc_market_price_daily_with_po
(
    cm_id         int auto_increment comment '序号'
        primary key,
    cm_date       varchar(10)                  null comment '价格所属日期，yyyy-MM-dd',
    cm_po_date    varchar(10)                  null comment '订单下单日，yyyy-MM-dd',
    cm_location   varchar(50)                  null comment '地区，长江/南海',
    cm_price      varchar(100)                 null comment '价格',
    cm_status     int         default 0        not null comment '状态，0：正常，1：已提交，9：弃用',
    cm_createtime varchar(20)                  not null comment '导入日期，yyyy-MM-dd HH:mm:ss',
    cm_createuser varchar(20) default 'system' null comment '导入人',
    cm_po         int                          not null comment '订单序号',
    cm_tep        int                          not null comment '审核单序号',
    cm_rule       int                          null comment '调价规则<br>BEFORE(0, "以下单日前一个交易日的铝锭价格计算", "BEFORE"),<br>AFTER(1, "以下单日后一个交易日的铝锭价格计算", "AFTER"),'
)
    comment '铝型材行情价。关联审核单表';

create table tstb_material_forward
(
    tmf_id         int auto_increment comment '序号'
        primary key,
    tmf_number     varchar(50) null comment '转发单号',
    tmf_refer_id   int         null comment '转发单序号',
    mmrm_id        int         null comment '收货单序号',
    pro_id         int         null comment '项目序号',
    pv_id          int         null comment '材料类型',
    tmf_status     int         null comment '状态
            0：正常
            1：弃用',
    tmf_createtime varchar(20) null comment '创建时间',
    tmf_createuser varchar(20) null,
    tmf_updatetime varchar(20) null,
    tmf_updateuser varchar(20) null
)
    comment '原材料转发单';

create table tstb_material_ld_price
(
    tmp_id             int auto_increment comment '铝锭价格序号'
        primary key,
    mk_id              int            null comment '市场序号',
    tmp_date           varchar(20)    null comment '价格日期',
    tmp_price          decimal(32, 8) null comment '价格',
    tmp_status         varchar(2)     null comment '状态',
    tmp_createuser     varchar(20)    null comment '创建人',
    tmp_createusercode varchar(20)    null comment '创建人代码',
    tmp_createdate     varchar(20)    null comment '创建时间',
    tmp_updateuser     varchar(20)    null comment '更新人',
    tmp_updateusercode varchar(20)    null comment '更新代码',
    tmp_updatedate     varchar(20)    null comment '更新时间'
)
    comment '铝锭价格表';

create table tstb_material_po
(
    mpm_id             int                    null comment '材料表序号',
    tmp_id             int auto_increment comment '订单表序号'
        primary key,
    vendor_name        varchar(128)           null comment '供应商名称',
    po_id              int                    null comment '订单序号',
    po_number          varchar(128)           null comment '订单编号',
    po_date            varchar(20)            null comment '订单发出日期',
    po_materail_id     int                    null comment '订单原始，材料的序号，操作流水时使用',
    po_amount          decimal(32, 10)        null comment '订购数量',
    tmp_status         varchar(2)             null comment '材料关系-订单-状态',
    po_type            varchar(2) default '0' null comment '订单类型  0:为普通订单   1:为加工件采购订单',
    tmp_createuser     varchar(20)            null comment '创建人',
    tmp_createtime     varchar(20)            null comment '创建时间',
    tmp_updateuser     varchar(20)            null comment '更新人',
    tmp_updatetime     varchar(20)            null comment '更新时间',
    mpom_vendor_symbol varchar(200)           null comment '材料供应商代码'
)
    comment '材料关系-订单';

create index index_mpm_id
    on tstb_material_po (mpm_id);

create index index_pro_id
    on tstb_material_po (po_id);

create index index_tmp_createtime
    on tstb_material_po (tmp_createtime);

create index tstb_material_po_vendor_name_tmp_status_index
    on tstb_material_po (vendor_name, tmp_status);

create table tstb_material_price
(
    mpm_id         int             null comment '材料表序号',
    tm_id          int auto_increment comment '材料关系-单价序号'
        primary key,
    pro_id         int             null comment '项目序号',
    prv_id         int             null comment '材料类型 1:铝型材
2:玻璃
3:铝板
4:石材
5:不锈钢
6:钢材
7:常规附件
8:非常规附件
9:辅材
10:铝锭
11:线密度
12:结算单',
    vendor_number  varchar(128)    null comment '供应商编号',
    tm_price       decimal(32, 10) null comment '价格',
    tmr_status     varchar(2)      null comment '材料关系-单价-状态',
    tmr_createuser varchar(20)     null comment '创建人',
    tmr_createtime varchar(20)     null comment '创建时间',
    tmr_updateuser varchar(20)     null comment '更新人',
    tmr_updatetime varchar(20)     null comment '更新时间'
)
    comment '材料关系-单价';

create index index_mpm_id
    on tstb_material_price (mpm_id);

create index index_pro_id
    on tstb_material_price (pro_id);

create index index_prv_id
    on tstb_material_price (prv_id);

create index tstb_material_price_prv_id_tm_price_pro_id_index
    on tstb_material_price (prv_id, tm_price, pro_id);

create table tstb_material_price_unit_mes
(
    tmpu_id              int auto_increment comment '序号'
        primary key,
    pro_id               int           not null comment '项目序号',
    prv_id               int           not null comment '材料类型序号',
    psam_code            varchar(200)  not null comment '材料编号',
    tmpu_area            varchar(200)  null comment '单件面积信息',
    tmpu_status          int default 0 not null comment '状态 状态：0，正常，5，弃用',
    tmpu_create_user     varchar(20)   not null comment '创建人 创建人',
    tmpu_create_usercode varchar(20)   not null comment '创建人工号 创建人工号',
    tmpu_create_time     varchar(20)   not null comment '创建时间 创建时间',
    tmpu_update_user     varchar(20)   null comment '更新人 更新人',
    tmpu_update_usercode varchar(20)   null comment '更新人工号 更新人工号',
    tmpu_update_time     varchar(20)   null comment '更新时间 更新时间',
    constraint tstb_material_price_unit_mes_uindex
        unique (pro_id, prv_id, psam_code)
)
    comment '项目材料单件面积，唯一表';

create table tstb_material_price_unit_pms
(
    tmpu_id              int auto_increment comment '序号'
        primary key,
    pro_id               int           not null comment '项目序号',
    prv_id               int           not null comment '材料类型序号',
    psam_code            varchar(200)  not null comment '材料编号',
    tmpu_area            varchar(200)  null comment '单件面积信息',
    tmpu_status          int default 0 not null comment '状态 状态：0，正常，5，弃用',
    tmpu_create_user     varchar(20)   not null comment '创建人 创建人',
    tmpu_create_usercode varchar(20)   not null comment '创建人工号 创建人工号',
    tmpu_create_time     varchar(20)   not null comment '创建时间 创建时间',
    tmpu_update_user     varchar(20)   null comment '更新人 更新人',
    tmpu_update_usercode varchar(20)   null comment '更新人工号 更新人工号',
    tmpu_update_time     varchar(20)   null comment '更新时间 更新时间',
    constraint tstb_material_price_unit_pms_uindex
        unique (pro_id, prv_id, psam_code)
)
    comment '项目材料单件面积，唯一表';

create table tstb_material_recevied
(
    mpm_id              int             null comment '材料表序号',
    tmr_id              int auto_increment comment '材料关系-收货序号'
        primary key,
    mmrm_id             int             null comment '收货主表序号',
    express_number      varchar(128)    null comment '送货单编号',
    receive_id          int             null comment '收货单序号',
    receive_number      varchar(128)    null comment '收货单编号',
    receive_date        varchar(20)     null comment '收货日期',
    receive_amount      decimal(32, 10) null comment '收货数量',
    tmr_po_id           int             null comment '收货材料，对应订单序号',
    tmr_po_materials_id int             null comment '收货材料，对应订单材料序号',
    tmr_status          varchar(2)      null comment '材料关系-收货-状态',
    tmr_createuser      varchar(20)     null comment '创建人',
    tmr_createtime      varchar(20)     null comment '创建时间',
    tmr_updateuser      varchar(20)     null comment '更新人',
    tmr_updatetime      varchar(20)     null comment '更新时间'
)
    comment '材料关系-收货';

create index index_mpm_id
    on tstb_material_recevied (mpm_id);

create index index_pro_id
    on tstb_material_recevied (mmrm_id);

create index index_tmr_po_id
    on tstb_material_recevied (tmr_po_id);

create table tstb_materials_receiving_log
(
    tmri_id         int auto_increment comment '材料收货序号'
        primary key,
    mmrm_id         int         null comment '收货序号',
    tmri_json       text        null comment 'JSON收货单明细数据',
    tmri_status     varchar(2)  null comment '状态',
    tmri_createuser varchar(20) null comment '创建人',
    tmri_createdate varchar(20) null comment '创建时间',
    tmri_updateuser varchar(20) null comment '更新人',
    tmri_updatedate varchar(20) null comment '更新时间'
)
    comment '材料收货数据表';

create index tstb_materials_receiving_log_mmrm_id_index
    on tstb_materials_receiving_log (mmrm_id);

create table tstb_operate_log
(
    tol_id         int auto_increment comment '序号'
        primary key,
    tol_module     varchar(64) null comment '模块名称',
    tol_business   varchar(64) null comment '业务方法',
    tol_op_type    varchar(32) null comment '操作类型',
    tol_params     longtext    null comment '操作数据',
    tol_return     longtext    null comment '返回值',
    tol_createtime varchar(20) null comment '创建时间',
    tol_status     varchar(2)  null comment '态 0:成功 1:失败'
)
    comment '操作日志表';

create table tstb_sent_approval_export_list
(
    ts_id          int auto_increment comment '序号'
        primary key,
    ts_file_name   varchar(255) null comment '生成的文件名',
    ts_vendor_id   varchar(255) null comment '供应商序号',
    ts_vendor_name varchar(255) null comment '供应商名称',
    ts_status      int          null comment '状态，0，待处理，1，处理中，2，完成处理',
    create_time    varchar(20)  null comment '创建时间',
    create_user    varchar(20)  null comment '创建人',
    update_user    varchar(20)  null comment '更新人',
    update_time    varchar(20)  null comment '更新时间',
    ts_pv          int          null comment '供货类型',
    ts_pro         int          null comment '项目序号',
    ts_date        varchar(255) null comment '搜索的时间区间'
)
    comment '导出审核单明细_任务;';

create table tstb_task_main
(
    ttm_id                    varchar(64) not null comment 'åºå·,UUID'
        primary key,
    ttm_source_id             varchar(32) null comment 'ä¸šåŠ¡ç³»ç»Ÿ,æºå¯¹è±¡åºå·,å¯ä»¥æ˜¯å¤šä¸ª,ä½¿ç”¨é€—å·è¿›è¡Œåˆ†å‰²',
    ttm_target_id             varchar(32) null comment 'ä¸šåŠ¡ç³»ç»Ÿ,ç›®æ ‡å¯¹è±¡åºå·,å¯ä»¥æ˜¯å¤šä¸ª,ä½¿ç”¨é€—å·è¿›è¡Œåˆ†å‰²',
    ttm_type                  varchar(2)  null comment 'ä»»åŠ¡ç±»åž‹ 0:JSON 1:FIle,éœ€è¦åœ¨æ•°æ®ç±»åž‹ä¸­,ç”³æ˜Žæ–‡ä»¶çš„åœ°å€ 2:SQL',
    ttm_business_id           varchar(64) null comment 'ä¸šåŠ¡ç³»ç»Ÿ,æºå¯¹è±¡åºå·,å¯ä»¥æ˜¯å¤šä¸ª,ä½¿ç”¨é€—å·è¿›è¡Œåˆ†å‰²',
    ttm_business_parent_id    varchar(64) null comment 'ä¸šåŠ¡ç³»ç»Ÿ,æºå¯¹è±¡çš„çˆ¶çº§åºå·,å”¯ä¸€',
    ttm_business_parent_codes varchar(64) null comment 'ä¸šåŠ¡ç³»ç»Ÿ,æºå¯¹è±¡çˆ¶çº§å¯¹è±¡ä¸šåŠ¡ä»£ç ,å”¯ä¸€,ä¾‹å¦‚,pms.project',
    ttm_action_type           varchar(2)  null comment 'æ“ä½œçš„ç±»åž‹ 0:æ–°å¢ž 1:ä¿®æ”¹',
    ttm_status                varchar(2)  null comment 'çŠ¶æ€ 0:å¾…åŒæ­¥ 1:åŒæ­¥ä¸­ 2:åŒæ­¥å®Œæˆ 3:åŒæ­¥å¤±è´¥',
    ttm_business_data         longtext    null comment 'å…·ä½“ä¸šåŠ¡æ•°æ®å¯¹è±¡,JSONæ ¼å¼æˆ–è€…æ–‡ä»¶åœ°å€æ ¼å¼',
    ttm_createtime            varchar(20) null comment 'åˆ›å»ºæ—¶é—´',
    ttm_updatetime            varchar(20) null comment 'æ›´æ–°æ—¶é—´',
    ttm_retrys                int         null comment 'é‡è¯•æ¬¡æ•°',
    ttm_block_type            varchar(2)  null comment 'é˜»æ–­ç±»åž‹ 0:ä¸é˜»æ–­ 1:é˜»æ–­',
    ttm_local_id              varchar(64) null comment 'æœ¬åœ°æœåŠ¡æäº¤çš„åºå·'
)
    comment 'æ•°æ®åŒæ­¥å¯¹è±¡è¡¨';

create table tstb_user_token
(
    tut_id              int auto_increment comment '序号'
        primary key,
    tut_usercode        varchar(50) null comment '用户代码',
    tut_username        varchar(50) null comment '用户姓名',
    tut_token           varchar(50) null comment '系统生成的token字符
使用usercode和时间戳进行MD5生成',
    tut_createtimestamp varchar(20) null comment '创建时间戳'
)
    comment '用户token表';

create table tstb_vendor_pv_data
(
    vendor_id     varchar(90)  not null comment '供应商序号'
        primary key,
    vendor_name   varchar(255) null comment '供应商名称',
    vendor_pv     int          null comment '供应商供货类型',
    vendor_status int          null comment '状态，0，待处理，1，处理中，2，完成处理',
    create_time   varchar(20)  null comment '创建时间',
    create_user   varchar(20)  null comment '创建人',
    update_user   varchar(20)  null comment '更新人',
    update_time   varchar(20)  null comment '更新时间'
)
    comment '成本供应商列表;';

create table tstb_vpo_extend_contract_baserule_approval
(
    mcb_id                  int auto_increment comment '序号'
        primary key,
    ca_id                   int              null comment '合同审核单序号',
    mcb_con                 int              null comment '合同序号',
    mcb_pro                 int              null comment '项目序号',
    mcb_pv                  int              null comment '材料类型，09种',
    mcb_input_date          varchar(20)      null comment '录入日',
    mcb_location            varchar(50)      null comment '地区',
    mcb_name                varchar(50)      null comment '名称',
    mcb_code                varchar(50)      null comment '代码',
    mcb_size                varchar(50)      null comment '规格',
    mcb_material            varchar(50)      null comment '材质',
    mcb_from                varchar(50)      null comment '原产地',
    mcb_price               varchar(50)      null comment '价格',
    mcb_jj_01               varchar(50)      null comment '基价01',
    mcb_jj_02               varchar(50)      null comment '基价02',
    mcb_jj_03               varchar(50)      null comment '基价03',
    mcb_jj_remark           varchar(50)      null comment '基价备注',
    mcb_is_price_adjustment int(5) default 1 null comment '是否进行合同调价(1.合同调价 2.合同不调价)',
    mcb_status              int              null comment '状态，0：可用，9：弃用',
    mcb_createtime          varchar(20)      null comment '创建时间',
    mcb_createuser          varchar(20)      null comment '创建人',
    mcb_updatetime          varchar(20)      null comment '更新时间',
    mcb_updateuser          varchar(20)      null comment '更新人',
    mcb_show_type           int(1)           null comment '显示类型 1-修改前数据 2-修改后数据'
)
    comment '合同基价规则-审核单-详情';

create table tstb_vpo_extend_meterial_att_approval
(
    tmfrt_id             int(1) auto_increment comment '序号'
        primary key,
    ca_id                int(1)           null comment '审核单序号',
    mfp_symbol           varchar(100)     null comment '材料代码',
    mfp_id               int(1)           null comment '工程属性-序号',
    mbp_id               int              null comment '基本属性序号',
    mbp_name             varchar(100)     null comment '基础属性名称',
    mbp_code             varchar(100)     null comment '基础属性代码',
    tmfrt_pro            int(1)           not null comment '项目序号',
    con_id               int(1)           not null comment '合同序号',
    tmfrt_att_00         varchar(100)     null comment '当前有效属性00',
    tmfrt_att_start_from varchar(20)      null comment '当前有效属性开始时间',
    tmfrt_att_end_before varchar(20)      null comment '当前有效属性结束时间',
    tmfrt_att_01         varchar(100)     null comment '当前有效属性01',
    tmfrt_att_02         varchar(100)     null comment '当前有效属性02',
    tmfrt_att_03         varchar(100)     null comment '当前有效属性03',
    tmfrt_att_04         varchar(100)     null comment '当前有效属性04',
    tmfrt_att_05         varchar(100)     null comment '当前有效属性05',
    tmfrt_att_06         varchar(100)     null comment '当前有效属性06',
    tmfrt_att_07         varchar(100)     null comment '当前有效属性07',
    tmfrt_att_08         varchar(100)     null comment '当前有效属性08',
    tmfrt_att_09         varchar(100)     null comment '当前有效属性09',
    tmfrt_att_10         varchar(100)     null comment '当前有效属性10',
    tmfrt_status         int(1) default 0 not null comment '状态,1：正常，0：待审核，2：审核驳回，9，弃用',
    tmfrt_createtime     varchar(20)      null comment '创建时间',
    tmfrt_createuser     varchar(20)      null comment '创建人',
    tmfrt_updatetime     varchar(20)      null comment '更新时间',
    tmfrt_updateuser     varchar(20)      null comment '更新人',
    tmfrt_comment        varchar(100)     null comment '备注',
    tmfrt_att_11         varchar(100)     null comment '当前有效属性11',
    tmfrt_att_12         varchar(100)     null comment '当前有效属性12',
    tmfrt_att_13         varchar(100)     null comment '当前有效属性13',
    tmfrt_att_14         varchar(100)     null comment '当前有效属性14',
    tmfrt_att_15         varchar(100)     null comment '当前有效属性15',
    tmfrt_att_16         varchar(100)     null comment '当前有效属性16',
    tmfrt_att_17         varchar(100)     null comment '当前有效属性17',
    tmfrt_att_18         varchar(100)     null comment '当前有效属性18',
    tmfrt_att_19         varchar(100)     null comment '当前有效属性19',
    tmfrt_att_20         varchar(1000)    null comment '当前有效属性20',
    ttfrt_att_json       text             null comment '存储扩展JSON属性，基础信息和即将生效属性都在',
    tmfrt_show_type      int(1)           null comment '显示类型 1-修改前数据 2-修改后数据'
)
    comment '其他材料属性_审核表';

create table tstb_vpo_extend_meterial_fj_price
(
    tmfr_id               int(1) auto_increment comment '序号'
        primary key,
    ca_id                 int(1)           null comment '审核单序号',
    mfp_symbol            varchar(100)     not null comment '附件材料代码',
    mfr_id                int(1)           not null comment '附件材料-单价序号',
    mfp_id                int(1)           not null comment '附件属性代号-序号',
    tmfr_pro              int(1)           not null comment '项目序号',
    con_id                int(1)           not null comment '合同序号',
    tmfr_price            varchar(100)     null comment '当前有效单价',
    tmfr_price_start_from varchar(20)      null comment '当前有效单价开始时间',
    tmfr_price_end_before varchar(20)      null comment '当前有效单价结束时间',
    tmfr_status           int(1) default 0 not null comment '状态,1：正常，0：待审核，2：审核驳回，9，弃用',
    tmfr_createtime       varchar(20)      null comment '创建时间',
    tmfr_createuser       varchar(20)      null comment '创建人',
    tmfr_updatetime       varchar(20)      null comment '更新时间',
    tmfr_updateuser       varchar(20)      null comment '更新人',
    tmfr_comment          varchar(100)     null comment '备注',
    tmfr_show_type        int(1)           null comment '显示类型 1-修改前数据 2-修改后数据'
)
    comment '附件材料单价_审核表';

create table tstb_vpo_extend_poapproval
(
    tep_id            int auto_increment comment '序号'
        primary key,
    tep_po_id         int           not null comment '订单序号',
    tep_number        varchar(50)   not null comment '单号',
    tep_status        int default 0 not null comment '状态，0，待成本审核，1，驳回，2，审核通过，9，弃用',
    tep_createtime    varchar(20)   not null comment '创建时间',
    tep_createuser    varchar(20)   not null comment '创建人',
    tep_updatetime    varchar(20)   null comment '更新时间',
    tep_updateuser    varchar(20)   null comment '更新人',
    tep_create_status int default 0 not null comment '提交状态，0：待提交，1，不可提交，2，已提交，9，系统弃用',
    tep_submit_time   varchar(20)   null comment '提交时间',
    tep_submit_user   varchar(20)   null comment '提交人',
    tep_pro_name      varchar(100)  null comment '项目名称',
    tep_vendor_name   varchar(100)  not null comment '供应商名称',
    tep_vendor_id     varchar(100)  not null comment '供应商序号',
    tep_pro_id        int           not null comment '项目序号',
    tep_pv_id         int           not null comment '供货类型,9种',
    tep_cost          varchar(100)  null comment '总金额',
    tep_con_id        int           null comment '合同序号',
    tep_po_gc_type    int           null comment 'PMS订单，钢材类型，0：原材料，1：钢制件',
    tep_po_createtime varchar(20)   null comment '下单时间',
    tep_con_no        varchar(100)  null comment '合同编号',
    tep_end_date      varchar(20)   null comment '审核结束时间'
)
    comment '订单预结算审核单';

create definer = fangda@`%` trigger tb_poapproval_insert_trigger
    after insert
    on tstb_vpo_extend_poapproval
    for each row
BEGIN
INSERT INTO tstb_vpo_extend_poapproval_id ( tep_id )
VALUES
    ( NEW.tep_id ); END;

create table tstb_vpo_extend_poapproval_id
(
    tep_id int not null comment '预结算审核单序号'
        primary key
)
    comment '订单预结算审核单id表' row_format = DYNAMIC;

create
definer = fangda@`%` procedure _tempAdd()
begin
    set
@_i = 0;
    while
@_i < 100
        do
            set @_c = lpad(@_i, 2, '0');
            SET
@sqlStr :=
                    CONCAT("alter table tstb_bl_market_price add tb_sc_3", @_c, " text null comment '动态增加列", @_c, "'");
PREPARE stmt FROM @sqlStr;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

set
@_i := @_i + 1;
end while;
end;

