#!/bin/bash
# ERD模型验证脚本 - vLLM + sLoRA方式
# 训练完成后自动启动验证服务

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

echo "🧠 ERD模型验证 - vLLM + sLoRA"
echo "============================="

# 检测Python路径
PYTHON_CMD=""
if [ -f "/root/miniconda/bin/python" ]; then
    PYTHON_CMD="/root/miniconda/bin/python"
elif [ -f "/root/miniconda3/bin/python" ]; then
    PYTHON_CMD="/root/miniconda3/bin/python"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    log_error "未找到Python环境"
    exit 1
fi

log_info "使用Python: $PYTHON_CMD"

# 配置参数
BASE_MODEL="Qwen/Qwen2.5-3B-Instruct"
LORA_PATH="data/models/erd_conservative"  # 默认LoRA路径
VLLM_PORT=8000
TEST_SAMPLES=10

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --lora-path)
            LORA_PATH="$2"
            shift 2
            ;;
        --port)
            VLLM_PORT="$2"
            shift 2
            ;;
        --samples)
            TEST_SAMPLES="$2"
            shift 2
            ;;
        --help)
            echo "用法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  --lora-path PATH    LoRA模型路径 (默认: data/models/erd_conservative)"
            echo "  --port PORT         vLLM服务端口 (默认: 8000)"
            echo "  --samples N         测试样本数量 (默认: 10)"
            echo "  --help              显示此帮助信息"
            exit 0
            ;;
        *)
            log_error "未知选项: $1"
            exit 1
            ;;
    esac
done

# 检查LoRA模型是否存在
log_step "检查LoRA模型..."
if [ ! -d "$LORA_PATH" ]; then
    log_error "LoRA模型路径不存在: $LORA_PATH"
    log_info "请确保训练已完成并生成了LoRA权重"
    exit 1
fi

# 检查必要文件
REQUIRED_FILES=("adapter_config.json" "adapter_model.safetensors")
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$LORA_PATH/$file" ]; then
        log_error "缺少LoRA文件: $LORA_PATH/$file"
        exit 1
    fi
done

log_info "✅ LoRA模型检查通过: $LORA_PATH"

# 检查vLLM是否安装
log_step "检查vLLM环境..."
if ! $PYTHON_CMD -c "import vllm" 2>/dev/null; then
    log_warn "vLLM未安装，正在安装..."
    $PYTHON_CMD -m pip install vllm -i https://mirrors.aliyun.com/pypi/simple/
    
    if [ $? -ne 0 ]; then
        log_error "vLLM安装失败"
        exit 1
    fi
fi

log_info "✅ vLLM环境检查通过"

# 检查端口是否被占用
log_step "检查端口可用性..."
if lsof -Pi :$VLLM_PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
    log_warn "端口 $VLLM_PORT 已被占用，尝试停止现有服务..."
    pkill -f "vllm.entrypoints.openai.api_server" || true
    sleep 3
fi

# 启动vLLM服务
log_step "启动vLLM + sLoRA服务..."
log_info "基础模型: $BASE_MODEL"
log_info "LoRA路径: $LORA_PATH"
log_info "服务端口: $VLLM_PORT"

# 创建vLLM启动脚本
cat > start_vllm_service.py << EOF
import asyncio
import sys
import argparse
from vllm.entrypoints.openai.api_server import run_server

async def main():
    # 创建参数对象
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="$BASE_MODEL")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=$VLLM_PORT)
    parser.add_argument("--enable-lora", action="store_true", default=True)
    parser.add_argument("--lora-modules", nargs="+", default=["erd_lora=$LORA_PATH"])
    parser.add_argument("--max-lora-rank", type=int, default=8)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.8)
    parser.add_argument("--trust-remote-code", action="store_true", default=True)

    # 解析参数
    args = parser.parse_args([])

    # 手动设置参数
    args.model = "$BASE_MODEL"
    args.host = "0.0.0.0"
    args.port = $VLLM_PORT
    args.enable_lora = True
    args.lora_modules = ["erd_lora=$LORA_PATH"]
    args.max_lora_rank = 8
    args.gpu_memory_utilization = 0.8
    args.trust_remote_code = True

    print(f"🚀 启动vLLM服务...")
    print(f"📊 模型: {args.model}")
    print(f"🌐 地址: {args.host}:{args.port}")
    print(f"🔧 LoRA: {args.lora_modules}")

    # 启动服务器
    await run_server(args)

if __name__ == "__main__":
    asyncio.run(main())
EOF

# 后台启动vLLM服务
log_info "正在启动vLLM服务..."

# 方法1：使用Python脚本启动（推荐）
if nohup $PYTHON_CMD start_vllm_service.py > vllm_service.log 2>&1 &
then
    VLLM_PID=$!
    log_info "vLLM服务已启动，PID: $VLLM_PID"
else
    log_warn "Python脚本启动失败，尝试命令行方式..."

    # 方法2：使用命令行启动（备用）
    nohup $PYTHON_CMD -m vllm.entrypoints.openai.api_server \
        --model "$BASE_MODEL" \
        --host 0.0.0.0 \
        --port $VLLM_PORT \
        --enable-lora \
        --lora-modules erd_lora="$LORA_PATH" \
        --max-lora-rank 8 \
        --gpu-memory-utilization 0.8 \
        --trust-remote-code > vllm_service.log 2>&1 &

    VLLM_PID=$!
    log_info "vLLM服务已启动（命令行方式），PID: $VLLM_PID"
fi

# 等待服务启动
log_info "等待vLLM服务启动..."
for i in {1..30}; do
    if curl -s http://localhost:$VLLM_PORT/health >/dev/null 2>&1; then
        log_info "✅ vLLM服务启动成功"
        break
    fi
    
    if [ $i -eq 30 ]; then
        log_error "vLLM服务启动超时"
        kill $VLLM_PID 2>/dev/null || true
        exit 1
    fi
    
    sleep 2
done

# 创建ERD验证测试脚本
log_step "创建ERD验证测试..."
cat > erd_verification_test.py << 'EOF'
import requests
import json
import time
from typing import List, Dict

class ERDVerifier:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
    
    def query_model(self, prompt: str, lora_name: str = "erd_lora") -> str:
        """查询vLLM + LoRA模型"""
        data = {
            "model": lora_name,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 512,
            "temperature": 0.1,
            "top_p": 0.8
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/v1/chat/completions",
                headers=self.headers,
                json=data,
                timeout=30
            )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"错误: {str(e)}"
    
    def test_relationship_recognition(self) -> Dict:
        """测试关系识别能力"""
        test_cases = [
            {
                "name": "直接关系识别",
                "prompt": "在ERD中，订单表(orders)和客户表(customers)之间是什么关系？请分析它们的关联字段。",
                "expected_keywords": ["外键", "一对多", "customer_id", "关联"]
            },
            {
                "name": "间接关系推理",
                "prompt": "客户表(customers)如何通过订单表(orders)关联到产品表(products)？请描述完整的关联路径。",
                "expected_keywords": ["路径", "订单明细", "product_id", "间接关联"]
            },
            {
                "name": "复杂关系分析",
                "prompt": "分析员工表(employees)、部门表(departments)和项目表(projects)之间的多重关系。",
                "expected_keywords": ["多对多", "中间表", "部门", "项目分配"]
            }
        ]
        
        results = []
        for case in test_cases:
            print(f"\n🧪 测试: {case['name']}")
            print(f"📝 提示: {case['prompt']}")
            
            start_time = time.time()
            response = self.query_model(case['prompt'])
            response_time = time.time() - start_time
            
            print(f"🤖 回答: {response}")
            print(f"⏱️  响应时间: {response_time:.2f}秒")
            
            # 简单的关键词匹配评估
            score = sum(1 for keyword in case['expected_keywords'] 
                       if keyword.lower() in response.lower())
            max_score = len(case['expected_keywords'])
            
            results.append({
                "test": case['name'],
                "response": response,
                "response_time": response_time,
                "score": score,
                "max_score": max_score,
                "accuracy": score / max_score if max_score > 0 else 0
            })
            
            print(f"📊 得分: {score}/{max_score} ({score/max_score*100:.1f}%)")
            print("-" * 50)
        
        return results
    
    def test_sql_generation(self) -> Dict:
        """测试SQL生成能力"""
        test_cases = [
            {
                "name": "简单查询生成",
                "prompt": "根据ERD结构，生成查询所有客户信息的SQL语句。",
                "expected_keywords": ["SELECT", "FROM", "customers"]
            },
            {
                "name": "关联查询生成",
                "prompt": "生成查询客户及其订单信息的SQL语句，包含客户名称和订单总金额。",
                "expected_keywords": ["JOIN", "customers", "orders", "SUM"]
            }
        ]
        
        results = []
        for case in test_cases:
            print(f"\n🧪 测试: {case['name']}")
            response = self.query_model(case['prompt'])
            
            score = sum(1 for keyword in case['expected_keywords'] 
                       if keyword.upper() in response.upper())
            max_score = len(case['expected_keywords'])
            
            results.append({
                "test": case['name'],
                "response": response,
                "score": score,
                "max_score": max_score,
                "accuracy": score / max_score if max_score > 0 else 0
            })
            
            print(f"🤖 SQL: {response}")
            print(f"📊 得分: {score}/{max_score} ({score/max_score*100:.1f}%)")
            print("-" * 50)
        
        return results

def main():
    print("🚀 开始ERD模型验证测试")
    print("=" * 50)
    
    verifier = ERDVerifier()
    
    # 测试关系识别
    print("\n📊 关系识别能力测试")
    relationship_results = verifier.test_relationship_recognition()
    
    # 测试SQL生成
    print("\n🔧 SQL生成能力测试")
    sql_results = verifier.test_sql_generation()
    
    # 计算总体评估
    all_results = relationship_results + sql_results
    total_score = sum(r['score'] for r in all_results)
    total_max = sum(r['max_score'] for r in all_results)
    overall_accuracy = total_score / total_max if total_max > 0 else 0
    
    print("\n🎯 验证结果总结")
    print("=" * 50)
    print(f"📊 总体准确率: {overall_accuracy*100:.1f}% ({total_score}/{total_max})")
    print(f"🧪 测试用例数: {len(all_results)}")
    
    avg_response_time = sum(r.get('response_time', 0) for r in relationship_results) / len(relationship_results)
    print(f"⏱️  平均响应时间: {avg_response_time:.2f}秒")
    
    if overall_accuracy >= 0.8:
        print("✅ 模型验证通过！ERD理解能力优秀")
    elif overall_accuracy >= 0.6:
        print("⚠️  模型验证基本通过，有改进空间")
    else:
        print("❌ 模型验证未通过，需要进一步训练")

if __name__ == "__main__":
    main()
EOF

# 运行验证测试
log_step "运行ERD验证测试..."
$PYTHON_CMD erd_verification_test.py

# 清理
log_step "清理资源..."
log_info "停止vLLM服务..."
kill $VLLM_PID 2>/dev/null || true

# 清理临时文件
rm -f start_vllm_service.py erd_verification_test.py

log_info "✅ ERD模型验证完成"
log_info "📋 详细日志请查看: vllm_service.log"
