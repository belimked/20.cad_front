#!/bin/bash
# ERD训练+验证自动化脚本
# 训练完成后自动启动vLLM+sLoRA验证

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 显示使用说明
show_usage() {
    echo "🧠 ERD训练+验证自动化脚本"
    echo "=========================="
    echo ""
    echo "用法: $0 [配置类型] [选项]"
    echo ""
    echo "配置类型:"
    echo "  conservative      保守配置 (推荐)"
    echo "  memory_optimized  内存优化配置"
    echo "  original          原始配置"
    echo "  5table_experiment 5表精准实验配置 (新)"
    echo ""
    echo "选项:"
    echo "  --samples N      训练样本数量 (默认: 3000)"
    echo "  --verify         训练完成后自动验证 (默认: 启用)"
    echo "  --no-verify      跳过验证步骤"
    echo "  --help           显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0 conservative                    # 训练+验证"
    echo "  $0 conservative --no-verify       # 仅训练"
    echo "  $0 memory_optimized --samples 5000 # 自定义样本数"
    echo ""
}

# 解析参数
CONFIG_TYPE=${1:-conservative}
MAX_SAMPLES=3000
AUTO_VERIFY=true

# 解析选项
shift
while [[ $# -gt 0 ]]; do
    case $1 in
        --samples)
            MAX_SAMPLES="$2"
            shift 2
            ;;
        --verify)
            AUTO_VERIFY=true
            shift
            ;;
        --no-verify)
            AUTO_VERIFY=false
            shift
            ;;
        --help)
            show_usage
            exit 0
            ;;
        *)
            log_error "未知选项: $1"
            show_usage
            exit 1
            ;;
    esac
done

echo "🚀 ERD训练+验证自动化流程"
echo "========================="
log_info "配置类型: $CONFIG_TYPE"
log_info "训练样本: $MAX_SAMPLES"
log_info "自动验证: $([ "$AUTO_VERIFY" = true ] && echo "启用" || echo "禁用")"
echo ""

# 第一阶段：训练
log_step "第一阶段: 开始ERD模型训练..."
echo ""

# 启动训练
if ./train_erd.sh $CONFIG_TYPE --samples $MAX_SAMPLES; then
    log_info "✅ 训练阶段完成"
else
    log_error "❌ 训练阶段失败"
    exit 1
fi

# 检查训练输出
if [ "$CONFIG_TYPE" = "5table_experiment" ]; then
    EXPECTED_LORA_PATH="data/models/5table_experiment_model"
else
    EXPECTED_LORA_PATH="data/models/erd_${CONFIG_TYPE}"
fi
if [ ! -d "$EXPECTED_LORA_PATH" ]; then
    log_warn "⚠️  预期LoRA路径不存在: $EXPECTED_LORA_PATH"
    log_info "正在搜索LoRA模型..."
    
    # 搜索可能的LoRA路径
    LORA_PATHS=(
        "data/models"
        "data/generated"
        "outputs"
        "."
    )
    
    FOUND_LORA=""
    for base_path in "${LORA_PATHS[@]}"; do
        if [ -d "$base_path" ]; then
            FOUND_LORA=$(find "$base_path" -name "adapter_config.json" -type f | head -1)
            if [ -n "$FOUND_LORA" ]; then
                EXPECTED_LORA_PATH=$(dirname "$FOUND_LORA")
                log_info "✅ 找到LoRA模型: $EXPECTED_LORA_PATH"
                break
            fi
        fi
    done
    
    if [ -z "$FOUND_LORA" ]; then
        log_error "❌ 未找到LoRA模型，训练可能未成功完成"
        exit 1
    fi
fi

# 第二阶段：验证（如果启用）
if [ "$AUTO_VERIFY" = true ]; then
    echo ""
    log_step "第二阶段: 开始模型验证..."
    echo ""
    
    # 等待一下让系统稳定
    log_info "等待系统稳定..."
    sleep 5
    
    # 启动验证
    if ./verify_erd_model.sh --lora-path "$EXPECTED_LORA_PATH"; then
        log_info "✅ 验证阶段完成"
    else
        log_error "❌ 验证阶段失败"
        exit 1
    fi
else
    echo ""
    log_info "⏭️  跳过验证阶段"
    log_info "如需验证，请运行:"
    log_info "  ./verify_erd_model.sh --lora-path $EXPECTED_LORA_PATH"
fi

# 完成总结
echo ""
log_step "🎉 ERD训练+验证流程完成"
echo "========================="
log_info "📊 训练配置: $CONFIG_TYPE"
log_info "📁 LoRA模型: $EXPECTED_LORA_PATH"
log_info "🧪 验证状态: $([ "$AUTO_VERIFY" = true ] && echo "已完成" || echo "已跳过")"

if [ "$AUTO_VERIFY" = true ]; then
    echo ""
    log_info "🎯 验证结果总结:"
    log_info "  • 关系识别能力测试"
    log_info "  • SQL生成能力测试"
    log_info "  • 响应时间性能测试"
    log_info "  • 详细结果请查看上方输出"
fi

echo ""
log_info "🔧 后续操作建议:"
log_info "  • 查看训练日志: logs/training_progress_*.md"
log_info "  • 重新验证: ./verify_erd_model.sh --lora-path $EXPECTED_LORA_PATH"
log_info "  • 部署生产: 使用vLLM + LoRA配置"

echo ""
log_info "✅ 所有流程已完成，ERD模型已就绪！"
