# ERD自监督学习项目 - GPU清理集成指南

## 🔥 GPU内存清理自动化

项目已完全集成GPU内存清理功能，解决训练启动失败的问题！

### ✅ **自动GPU清理流程**

训练启动时会自动执行：
1. **检查GPU状态** - 检测占用GPU的进程
2. **智能清理** - 使用你的GPU清理脚本或内置清理
3. **强制清理** - 如果智能清理不完全，执行强制清理
4. **优化配置** - 设置RTX 4090优化参数
5. **启动训练** - 在清理后的环境中启动训练

## 🚀 集成的清理脚本

### 1. 项目GPU清理脚本优先
```bash
# 优先使用你的GPU清理脚本
examples/shell/clear_gpu_memory.sh
```

### 2. 集成GPU清理脚本
```bash
# 新增的集成清理脚本
deploy/gpu_cleanup.sh --auto
```

### 3. 内置清理逻辑
```bash
# 如果没有专用脚本，使用内置清理
pkill -f "train_model"
rm -rf ~/.cache/torch/*
sleep 3
```

## 📊 GPU清理功能

### 智能清理 (`--auto`)
```bash
./deploy/gpu_cleanup.sh --auto

# 执行效果：
🔥 ERD项目GPU自动清理和优化
================================
[22:30:15] 🧠 智能GPU清理...
[22:30:15] 📊 检查GPU状态...
[22:30:15] GPU信息: NVIDIA GeForce RTX 4090, 2048, 24564
[22:30:15] ⚠️  检测到GPU进程:
    12345, python, 8192
[22:30:15] 使用项目GPU清理脚本...
[22:30:18] ✅ 项目脚本清理成功
[22:30:18] ⚡ 设置GPU优化参数...
[22:30:18] 检测到RTX 4090，启用优化配置
[22:30:18] ✅ RTX 4090优化配置已启用
[22:30:18] ✅ GPU优化参数设置完成
[22:30:18] 📊 GPU环境信息...

GPU硬件信息:
index, name, memory.total [MiB], driver_version
0, NVIDIA GeForce RTX 4090, 24564, 535.104.05

GPU使用情况:
index, utilization.gpu [%], memory.used [MiB], memory.total [MiB], temperature.gpu
0, 0, 0, 24564, 45

GPU进程:
pid, process_name, used_gpu_memory [MiB]

环境变量:
  CUDA_VISIBLE_DEVICES: 0
  PYTORCH_CUDA_ALLOC_CONF: max_split_size_mb:512
  CUDA_LAUNCH_BLOCKING: 0

[22:30:19] ✅ GPU自动清理和优化完成
```

### 手动清理选项
```bash
# 检查GPU状态
./deploy/gpu_cleanup.sh --check

# 智能清理
./deploy/gpu_cleanup.sh --clear

# 强制清理
./deploy/gpu_cleanup.sh --force

# 设置优化参数
./deploy/gpu_cleanup.sh --optimize

# 显示GPU信息
./deploy/gpu_cleanup.sh --info
```

## 🔧 训练流程集成

### 自动清理流程
```bash
# 一键部署时自动执行
./one_click_deploy.sh

# 训练启动时的清理流程：
[22:30:20] 🔧 准备训练环境...
[22:30:21] ✅ ERD训练环境已配置 (Miniconda)
[22:30:21] ✅ 训练环境准备完成
[22:30:21] 🔥 清理GPU内存...
[22:30:21] 使用集成GPU清理脚本...
[22:30:25] ✅ GPU清理完成
[22:30:25] 🚀 启动训练进程...
[22:30:28] ✅ 训练进程启动成功 (PID: 12345)
```

### 手动训练时的清理
```bash
# 连接服务器后
cd /root/lanyun-tmp/erd

# 手动清理GPU
./deploy/gpu_cleanup.sh --auto

# 启动训练
./deploy/train_on_server.sh
```

## ⚡ RTX 4090优化配置

### 自动检测和优化
```bash
# 检测到RTX 4090时自动启用：
export PYTORCH_CUDA_ALLOC_CONF="max_split_size_mb:512"
export CUDA_LAUNCH_BLOCKING="0"
export TORCH_CUDNN_V8_API_ENABLED="1"
export TOKENIZERS_PARALLELISM="false"
export OMP_NUM_THREADS="4"
```

### 通用GPU优化
```bash
# 其他GPU使用通用配置：
export PYTORCH_CUDA_ALLOC_CONF="max_split_size_mb:256"
export CUDA_VISIBLE_DEVICES="0"
export TOKENIZERS_PARALLELISM="false"
```

## 🛠️ 清理策略

### 1. 进程清理
```bash
# 清理训练相关进程
pkill -f "train_model"
pkill -f "python.*train"
pkill -f "torchrun"
pkill -f "torch.*distributed"
pkill -f "transformers"
```

### 2. 设备文件清理
```bash
# 清理GPU设备文件（需要sudo）
sudo fuser -k /dev/nvidia*
```

### 3. 缓存清理
```bash
# PyTorch缓存
rm -rf ~/.cache/torch/*

# HuggingFace缓存
rm -rf ~/.cache/huggingface/transformers/*/tmp*
rm -rf ~/.cache/huggingface/hub/*/tmp*

# 项目缓存
rm -rf ./cache/huggingface/transformers/*/tmp*

# 系统临时文件
rm -rf /tmp/torch_*
rm -rf /tmp/transformers_*
rm -rf /tmp/pytorch_*
```

### 4. Python缓存清理
```bash
# Python字节码缓存
find . -name "__pycache__" -type d -exec rm -rf {} +
find . -name "*.pyc" -delete
find . -name "*.pyo" -delete
```

## 🎯 使用场景

### 训练启动失败时
```bash
# 如果训练启动失败，手动清理GPU
./deploy/gpu_cleanup.sh --force

# 然后重新启动训练
./deploy/train_on_server.sh
```

### 切换训练任务时
```bash
# 停止当前训练
kill $(cat logs/train.pid)

# 清理GPU
./deploy/gpu_cleanup.sh --auto

# 启动新训练
./deploy/train_on_server.sh
```

### 定期维护时
```bash
# 检查GPU状态
./deploy/gpu_cleanup.sh --info

# 清理缓存文件
./deploy/gpu_cleanup.sh --clear
```

## 📈 清理效果

### 清理前
```
GPU进程:
  12345, python, 8192MB
  12346, train_model.py, 4096MB

GPU内存使用: 12288MB / 24564MB (50%)
```

### 清理后
```
GPU进程:
  (无进程)

GPU内存使用: 0MB / 24564MB (0%)
```

## 🎉 总结

现在GPU清理已完全集成到训练流程中：

1. ✅ **自动检测** - 智能检测GPU占用情况
2. ✅ **多级清理** - 项目脚本 → 集成脚本 → 内置清理
3. ✅ **优化配置** - RTX 4090专项优化
4. ✅ **无缝集成** - 训练启动前自动清理
5. ✅ **手动控制** - 提供完整的手动清理工具

**再也不用担心GPU内存占用导致的训练启动失败！** 🔥✨
