# ERD自监督学习项目配置化自动部署指南

## 🎯 功能概述

支持完全自动化的配置化部署流程：
**本地打包 → 上传服务器 → 解压缩 → 后台训练 → 删除本地打包**

## 🚀 两种部署方式

### 方式一：一键部署（推荐新手）

#### 1. 配置服务器信息
```bash
# 编辑一键部署脚本
vim one_click_deploy.sh

# 修改配置区域（第12-30行）
SERVER_HOST="your-server.com"          # 改为你的服务器地址
SERVER_USER="root"                     # 改为你的用户名
SERVER_PORT="22"                       # 改为你的SSH端口
SERVER_PASSWORD=""                     # 密码（留空使用SSH密钥）
USE_SSH_KEY=true                       # 是否使用SSH密钥
```

#### 2. 执行一键部署
```bash
./one_click_deploy.sh
```

**完整流程自动执行**：
- ✅ 检查配置和连接
- ✅ 本地项目打包
- ✅ 上传到服务器
- ✅ 服务器解压和环境部署
- ✅ 自动启动后台训练
- ✅ 删除本地打包文件

### 方式二：高级配置部署（推荐高级用户）

#### 1. 初始化配置
```bash
./deploy/auto_deploy.sh --init
```

#### 2. 编辑配置文件
```bash
vim deploy/deploy_config.conf

# 配置示例
SERVER_HOST=192.168.1.100
SERVER_USER=root
SERVER_PORT=22
USE_SSH_KEY=true
AUTO_START_TRAINING=true
AUTO_CLEANUP_LOCAL=true
MAX_SAMPLES=8000
```

#### 3. 测试连接
```bash
./deploy/auto_deploy.sh --test
```

#### 4. 执行自动部署
```bash
./deploy/auto_deploy.sh --deploy
```

## 📋 配置参数说明

### 🌐 服务器连接配置
```bash
SERVER_HOST="your-server.com"          # 服务器地址或IP
SERVER_USER="root"                     # SSH用户名
SERVER_PORT="22"                       # SSH端口
SERVER_PASSWORD=""                     # SSH密码（可选）
USE_SSH_KEY=true                       # 是否使用SSH密钥认证
```

### 📁 服务器路径配置
```bash
SERVER_BASE_PATH="/root"               # 服务器基础路径
SERVER_PROJECT_NAME="erd-training"     # 项目目录名
# 最终路径：/root/erd-training
```

### 🧠 训练配置
```bash
MAX_SAMPLES=8000                       # 训练样本数（推荐8000）
GPU_DEVICE=0                          # GPU设备号（0表示第一块GPU）
ENABLE_RTX4090_OPT=true               # 启用RTX4090优化
```

### ⚙️ 部署选项
```bash
AUTO_START_TRAINING=true              # 自动开始训练
AUTO_CLEANUP_LOCAL=true               # 自动清理本地打包文件
KEEP_REMOTE_BACKUP=true               # 保留远程备份
FORCE_REINSTALL=false                 # 强制重新安装环境
```

## 🔧 部署流程详解

### 阶段1：本地打包
- 执行 `package_project.sh`
- 生成 `erd-self-supervised-learning-v1.0.0.tar.gz`
- 包含完整项目代码、配置、数据

### 阶段2：上传服务器
- 通过SCP上传压缩包到服务器
- 支持SSH密钥和密码两种认证方式
- 自动处理网络超时和重试

### 阶段3：服务器解压
- 自动备份现有项目（如果存在）
- 解压新项目到指定目录
- 设置正确的文件权限

### 阶段4：环境部署
- 执行 `deploy/setup_server.sh`
- 自动检测GPU类型并优化配置
- 安装Python环境和依赖包
- 创建训练配置文件

### 阶段5：启动训练
- 执行 `deploy/train_on_server.sh`
- 后台启动训练进程
- 记录进程ID到 `logs/train.pid`
- 开始训练63张表的ERD数据

### 阶段6：清理本地
- 删除本地打包文件
- 释放本地存储空间
- 保持工作目录整洁

## 📊 部署后管理

### 连接服务器
```bash
# SSH密钥方式
ssh -p 22 root@your-server.com

# 密码方式
sshpass -p 'password' ssh -p 22 root@your-server.com
```

### 监控训练
```bash
# 进入项目目录
cd /root/erd-training

# 综合监控面板
./deploy/monitor_training.sh

# 实时日志
tail -f logs/training.log

# GPU监控
watch -n 1 nvidia-smi
```

### 控制训练
```bash
# 停止训练
kill $(cat logs/train.pid)

# 重新启动训练
./deploy/train_on_server.sh

# 查看训练状态
ps aux | grep train_model
```

## 🛠️ 故障排除

### 连接问题
```bash
# 测试SSH连接
ssh -p 22 root@your-server.com "echo 'test'"

# 检查SSH密钥
ssh-add -l

# 生成SSH密钥（如果没有）
ssh-keygen -t rsa -b 4096
ssh-copy-id root@your-server.com
```

### 上传问题
```bash
# 检查网络连接
ping your-server.com

# 手动上传测试
scp test.txt root@your-server.com:/tmp/

# 检查服务器磁盘空间
ssh root@your-server.com "df -h"
```

### 训练问题
```bash
# 检查GPU状态
ssh root@your-server.com "nvidia-smi"

# 查看错误日志
ssh root@your-server.com "cd /root/erd-training && tail -50 logs/training.log"

# 检查Python环境
ssh root@your-server.com "cd /root/erd-training && source erd_env/bin/activate && python --version"
```

## 📈 预期结果

### 训练时间
- **RTX 4090**: 3-4小时
- **RTX 3090**: 4-5小时
- **其他GPU**: 根据性能调整

### 性能指标
- **直接关系查询**: 85-90%准确率
- **间接关系推理**: 75-80%准确率
- **SQL生成**: 70-75%准确率

### 输出文件
- `data/models/final_model/`: 训练完成的模型
- `data/generated/training_data.json`: 生成的训练数据
- `logs/training.log`: 完整训练日志

## 🎉 部署完成

部署成功后，你将拥有：
- ✅ 完全自动化的部署流程
- ✅ 基于63张真实企业数据库表的训练模型
- ✅ 零人工标注的自监督学习系统
- ✅ 专业级的监控和管理工具

现在可以开始使用你的ERD自监督学习模型了！
