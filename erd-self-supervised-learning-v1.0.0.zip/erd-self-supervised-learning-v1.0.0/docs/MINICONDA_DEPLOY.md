# ERD自监督学习项目 - Miniconda环境部署指南

## 🐍 专门适配 `/root/miniconda/bin/python` 环境

### 🎯 自动检测和适配

项目已经完全适配你的Miniconda环境！部署脚本会自动检测 `/root/miniconda/bin/python` 并使用专用的设置流程。

## 🚀 一键部署（推荐）

### 1. 配置服务器信息
```bash
# 编辑一键部署脚本
vim one_click_deploy.sh

# 修改配置（第12-30行）
SERVER_HOST="your-server.com"          # 改为你的服务器地址
SERVER_USER="root"                     # 用户名
SERVER_PORT="22"                       # SSH端口
USE_SSH_KEY=true                       # 使用SSH密钥
```

### 2. 执行一键部署
```bash
./one_click_deploy.sh
```

**自动执行流程**：
- ✅ 检测到 `/root/miniconda/bin/python`
- ✅ 自动使用Miniconda专用设置脚本
- ✅ 创建conda环境 `erd_env`
- ✅ 安装优化版本的PyTorch和依赖
- ✅ 自动启动后台训练

## 📊 Miniconda环境特殊处理

### 自动检测逻辑
```bash
# 脚本会自动检测以下路径：
/root/miniconda/bin/python      # 优先检测
/root/miniconda3/bin/python     # 备选路径
```

### Conda环境管理
```bash
# 自动创建conda环境
conda create -n erd_env python=3.10 -y

# 自动激活环境
source /root/miniconda/etc/profile.d/conda.sh
conda activate erd_env

# 安装依赖
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
```

### 环境配置文件
自动生成的 `erd_env_config.sh` 包含：
```bash
#!/bin/bash
# ERD训练环境配置 - Miniconda版本

# 初始化conda
source /root/miniconda/etc/profile.d/conda.sh
conda activate erd_env

# Python路径
export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"
export PYTHON_CMD="/root/miniconda/bin/python"

# CUDA配置
export CUDA_VISIBLE_DEVICES=0
export TOKENIZERS_PARALLELISM=false

# HuggingFace配置
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_CACHE=$(pwd)/cache/huggingface

# RTX 4090优化配置
if nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | grep -q "4090"; then
    export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512
    export CUDA_LAUNCH_BLOCKING=0
fi

echo "✅ ERD训练环境已配置 (Miniconda)"
```

## 🔧 手动部署（高级用户）

### 1. 解压项目
```bash
tar -xzf erd-self-supervised-learning-v1.0.0.tar.gz
cd erd-self-supervised-learning-v1.0.0
```

### 2. 直接使用Miniconda设置脚本
```bash
./deploy/miniconda_setup.sh
```

### 3. 启动训练
```bash
# 使用专用的Miniconda启动脚本
./quick_train_miniconda.sh

# 或使用通用脚本（会自动适配）
./deploy/train_on_server.sh
```

## 📈 部署效果演示

### 自动检测Miniconda
```
🚀 ERD自监督学习项目服务器部署
================================
🐍 检测到Miniconda环境，使用专用设置脚本

🐍 ERD项目Miniconda环境设置
================================
专门适配 /root/miniconda/bin/python

[22:10:15] 🔍 检测Miniconda环境...
[22:10:15] ✅ 检测到Miniconda: /root/miniconda
[22:10:15] Python版本: Python 3.10.12
[22:10:15] Conda版本: conda 23.7.4

[22:10:15] 🐍 设置Conda环境...
[22:10:16] 创建ERD conda环境...
[22:10:25] 当前Python路径: /root/miniconda/envs/erd_env/bin/python

[22:10:25] 📦 安装依赖包...
[22:10:26] 检测到RTX 4090，安装优化版PyTorch...
[22:11:30] 安装其他依赖...

[22:12:15] 🔧 创建环境配置...
[22:12:15] ✅ 环境配置文件已创建

[22:12:15] ✅ 验证安装...
[22:12:16] PyTorch版本: 2.1.0+cu121
[22:12:16] CUDA可用: True
[22:12:16] Transformers版本: 4.35.2
[22:12:16] PEFT版本: 0.6.2
[22:12:17] GPU数量: 1
[22:12:17] GPU 0: NVIDIA GeForce RTX 4090

[22:12:17] 🚀 创建快速启动脚本...
[22:12:17] ✅ 快速启动脚本已创建

🎉 Miniconda环境设置完成！
================================

📊 环境信息:
  • Conda路径: /root/miniconda
  • Python命令: /root/miniconda/bin/python
  • 环境名称: erd_env

🚀 使用方法:
  ./quick_train_miniconda.sh          # 快速训练
  ./deploy/train_on_server.sh         # 后台训练
  ./deploy/monitor_training.sh        # 监控训练
```

### 启动训练
```
[22:12:20] 🧠 启动远程训练...

🧠 ERD自监督学习模型训练
================================
[22:12:21] 🔍 检查训练前置条件...
[22:12:21] ✅ 前置条件检查通过
[22:12:21] 🔧 准备训练环境...
[22:12:22] ✅ ERD训练环境已配置 (Miniconda)
[22:12:22] ✅ 训练环境准备完成
[22:12:22] 🚀 启动训练进程...
[22:12:25] ✅ 训练进程启动成功 (PID: 12345)

🎉 ERD自监督学习训练已启动！
================================

📊 训练信息:
  • 进程ID: 12345
  • ERD数据: 63张表，1330个字段，38个关系
  • 训练样本: 8000个（自动生成）
  • 基础模型: Qwen2.5-3B-Instruct
  • 预计时间: 3-4小时
  • Python环境: Miniconda erd_env
```

## 🔧 Miniconda环境管理

### 查看conda环境
```bash
# 连接服务器后
source /root/miniconda/etc/profile.d/conda.sh
conda env list

# 输出示例：
# conda environments:
# base                  *  /root/miniconda
# erd_env                  /root/miniconda/envs/erd_env
```

### 激活环境
```bash
# 方法1：使用配置脚本（推荐）
source erd_env_config.sh

# 方法2：手动激活
source /root/miniconda/etc/profile.d/conda.sh
conda activate erd_env
```

### 检查环境
```bash
# 检查当前Python路径
which python
# 输出：/root/miniconda/envs/erd_env/bin/python

# 检查已安装包
pip list | grep torch
# 输出：torch 2.1.0+cu121
```

## 🛠️ 故障排除

### 常见问题

#### 1. Conda环境激活失败
```bash
# 解决方案：重新初始化conda
source /root/miniconda/etc/profile.d/conda.sh
conda init bash
source ~/.bashrc
```

#### 2. PyTorch CUDA版本不匹配
```bash
# 检查CUDA版本
nvidia-smi

# 重新安装对应版本的PyTorch
conda activate erd_env
pip uninstall torch torchvision torchaudio
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

#### 3. 权限问题
```bash
# 确保conda目录权限正确
chown -R root:root /root/miniconda
chmod -R 755 /root/miniconda
```

## 🎯 优势总结

### ✅ **完全适配Miniconda**
- 自动检测 `/root/miniconda/bin/python`
- 专用的conda环境管理
- 优化的依赖安装流程

### ✅ **智能环境管理**
- 自动创建独立的 `erd_env` 环境
- 避免与base环境冲突
- 支持环境备份和恢复

### ✅ **无缝集成**
- 与现有部署脚本完全兼容
- 自动选择最佳安装方式
- 统一的监控和管理接口

现在你的 `/root/miniconda/bin/python` 环境已经完全支持了！🐍🚀
