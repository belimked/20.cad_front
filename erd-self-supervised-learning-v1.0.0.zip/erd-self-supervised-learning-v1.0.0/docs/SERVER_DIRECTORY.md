# ERD自监督学习项目 - 服务器目录配置

## 📁 服务器目录结构

项目已配置为使用 `/root/lanyun-tmp/erd/` 作为服务器部署目录。

### 🎯 目录路径配置

```bash
# 服务器基础路径
SERVER_BASE_PATH="/root/lanyun-tmp"

# 项目目录名
SERVER_PROJECT_NAME="erd"

# 完整项目路径
SERVER_FULL_PATH="/root/lanyun-tmp/erd"
```

### 📊 完整目录结构

```
/root/lanyun-tmp/erd/
├── README_DIRECTORY.md          # 目录说明文件
├── src/                         # 源代码目录
│   ├── data/                    # 数据处理模块
│   ├── training/                # 训练模块
│   └── utils/                   # 工具模块
├── config/                      # 配置文件
│   └── qwen_3b_config.yaml      # 模型配置
├── examples/                    # 示例脚本
│   ├── train_model.py           # 训练脚本
│   └── convert_sql_to_erd.py    # SQL转换脚本
├── deploy/                      # 部署脚本
│   ├── setup_server.sh          # 环境设置
│   ├── train_on_server.sh       # 训练启动
│   ├── monitor_training.sh      # 训练监控
│   ├── miniconda_setup.sh       # Miniconda专用设置
│   └── create_server_dirs.sh    # 目录创建脚本
├── data/                        # 数据目录
│   ├── erd/                     # ERD文件
│   │   ├── cost.sql             # 原始SQL文件
│   │   ├── cost_erd.json        # 转换后的ERD（63张表）
│   │   └── cost_erd.stats.json  # 统计信息
│   ├── generated/               # 生成的训练数据
│   │   ├── training_data.json   # 8000个训练样本
│   │   └── evaluation_results.json # 评估结果
│   └── models/                  # 训练好的模型
│       └── final_model/         # 最终模型
├── logs/                        # 日志文件
│   ├── training.log             # 训练日志
│   ├── train.pid                # 训练进程ID
│   └── setup.log                # 部署日志
├── cache/                       # 缓存目录
│   └── huggingface/             # HuggingFace模型缓存
├── backup/                      # 备份目录
├── erd_env/                     # Python虚拟环境（自动创建）
├── erd_env_config.sh            # 环境配置脚本（自动创建）
├── quick_train_miniconda.sh     # 快速训练脚本（Miniconda版）
└── requirements.txt             # 依赖包列表
```

## 🚀 自动目录创建

### 一键部署自动创建

执行一键部署时，脚本会自动：

```bash
# 1. 创建基础目录
mkdir -p /root/lanyun-tmp

# 2. 创建项目目录
mkdir -p /root/lanyun-tmp/erd

# 3. 创建子目录结构
mkdir -p /root/lanyun-tmp/erd/{logs,data/{erd,generated,models},cache/huggingface,backup}

# 4. 设置正确的权限
chown -R root:root /root/lanyun-tmp
chmod -R 755 /root/lanyun-tmp
```

### 手动创建目录

如果需要手动创建目录结构：

```bash
# 连接服务器后执行
cd /path/to/project
./deploy/create_server_dirs.sh
```

## 🔧 目录权限设置

### 自动权限配置

```bash
# 所有者设置
chown -R root:root /root/lanyun-tmp

# 目录权限
find /root/lanyun-tmp -type d -exec chmod 755 {} \;

# 文件权限
find /root/lanyun-tmp -type f -exec chmod 644 {} \;

# 脚本执行权限
chmod +x /root/lanyun-tmp/erd/deploy/*.sh
chmod +x /root/lanyun-tmp/erd/*.sh
```

### 权限说明

- **755** - 目录权限（所有者读写执行，组和其他用户读执行）
- **644** - 文件权限（所有者读写，组和其他用户只读）
- **755** - 脚本权限（可执行）

## 📊 磁盘空间要求

### 最小空间要求

```bash
# 项目文件
项目代码和配置: ~50MB
ERD数据文件: ~5MB
训练数据生成: ~100MB
模型缓存: ~3GB
训练模型: ~2GB
日志文件: ~100MB

# 总计最小要求: ~6GB
# 推荐可用空间: 10GB+
```

### 空间检查

```bash
# 检查可用空间
df -h /root/lanyun-tmp

# 检查目录大小
du -sh /root/lanyun-tmp/erd
```

## 🔍 目录监控

### 实时监控

```bash
# 进入项目目录
cd /root/lanyun-tmp/erd

# 监控训练状态
./deploy/monitor_training.sh

# 查看目录使用情况
du -sh * | sort -hr
```

### 日志文件管理

```bash
# 查看训练日志
tail -f /root/lanyun-tmp/erd/logs/training.log

# 查看部署日志
cat /root/lanyun-tmp/erd/logs/setup.log

# 清理旧日志（可选）
find /root/lanyun-tmp/erd/logs -name "*.log" -mtime +7 -delete
```

## 🛠️ 目录维护

### 定期清理

```bash
# 清理缓存文件
rm -rf /root/lanyun-tmp/erd/cache/huggingface/transformers/tmp*

# 清理临时文件
find /root/lanyun-tmp/erd -name "*.tmp" -delete
find /root/lanyun-tmp/erd -name "*.pyc" -delete

# 备份重要文件
cp -r /root/lanyun-tmp/erd/data/models /root/lanyun-tmp/erd/backup/
```

### 备份策略

```bash
# 创建完整备份
tar -czf /root/lanyun-tmp/erd_backup_$(date +%Y%m%d).tar.gz -C /root/lanyun-tmp erd

# 仅备份模型
tar -czf /root/lanyun-tmp/erd_models_$(date +%Y%m%d).tar.gz -C /root/lanyun-tmp/erd data/models

# 仅备份配置
tar -czf /root/lanyun-tmp/erd_config_$(date +%Y%m%d).tar.gz -C /root/lanyun-tmp/erd config erd_env_config.sh
```

## 🎯 使用示例

### 部署后的典型操作

```bash
# 1. 连接服务器
ssh root@your-server.com

# 2. 进入项目目录
cd /root/lanyun-tmp/erd

# 3. 检查环境
source erd_env_config.sh
python --version

# 4. 开始训练
./deploy/train_on_server.sh

# 5. 监控训练
./deploy/monitor_training.sh

# 6. 查看结果
ls -la data/models/
```

### 故障排除

```bash
# 检查目录是否存在
ls -la /root/lanyun-tmp/

# 检查权限
ls -la /root/lanyun-tmp/erd/

# 重新创建目录（如果需要）
./deploy/create_server_dirs.sh

# 检查磁盘空间
df -h /root/lanyun-tmp
```

## 📝 配置文件位置

所有配置文件都已更新为使用新的目录路径：

- `one_click_deploy.sh` - 一键部署脚本
- `deploy/auto_deploy.sh` - 高级部署脚本
- `deploy/server_config.sh` - 服务器配置
- `deploy/create_server_dirs.sh` - 目录创建脚本

现在所有部署脚本都会自动使用 `/root/lanyun-tmp/erd/` 作为项目目录！🚀
