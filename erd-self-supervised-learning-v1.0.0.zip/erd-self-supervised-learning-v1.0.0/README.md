# ERD自监督学习项目

## 项目概述
基于ERD（实体关系图）的自监督学习系统，能够仅通过数据库表结构信息自动学习表之间的关联关系，并回答相关查询问题。

## 核心特性
- 🤖 **零人工标注**：完全基于ERD结构自动学习
- 🚀 **轻量高效**：基于Qwen2.5-3B模型，适配RTX 4090
- 📊 **数据增强**：从50张表生成5000+训练样本
- 🔄 **多任务学习**：关系预测、路径发现、SQL生成
- 🌏 **中文原生**：优秀的中文数据库术语理解

## 项目结构
```
├── README.md                 # 项目说明
├── requirements.txt          # 依赖包
├── config/                   # 配置文件
├── src/                      # 源代码
│   ├── data/                 # 数据处理模块
│   ├── models/               # 模型相关
│   ├── training/             # 训练流程
│   └── utils/                # 工具函数
├── data/                     # 数据目录
│   ├── erd/                  # ERD输入文件
│   ├── generated/            # 生成的训练数据
│   └── models/               # 训练好的模型
├── examples/                 # 示例和测试
└── docs/                     # 文档

```

## 快速开始

### 1. 环境准备
```bash
pip install -r requirements.txt
```

### 2. 准备ERD数据
将ERD文件放入 `data/erd/` 目录

### 3. 生成训练数据
```bash
python src/data/generate_training_data.py --erd_file data/erd/your_erd.json
```

### 4. 训练模型
```bash
python src/training/train_model.py --config config/qwen_3b_config.yaml
```

### 5. 测试模型
```bash
python examples/test_model.py --model_path data/models/erd_model
```

## 技术架构

### 数据增强策略
- **关系路径挖掘**：直接关系 + 间接关系
- **自动问题生成**：基于模板生成问答对
- **SQL模板生成**：自动生成JOIN查询示例
- **负样本构造**：生成无关联的表对

### 自监督学习任务
1. **关系掩码预测**：预测被掩盖的关联字段
2. **关系类型分类**：判断表间关系类型
3. **路径发现**：找到表间最短关联路径
4. **SQL生成验证**：根据关系生成正确SQL

## 性能指标
- 直接关系查询：85-90%准确率
- 间接关系推理：75-80%准确率
- SQL生成：70-75%准确率
- 训练时间：3-4小时（RTX 4090）

## 贡献指南
欢迎提交Issue和Pull Request！

## 许可证
MIT License
