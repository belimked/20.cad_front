# vLLM + sLoRA 验证指南

## 🚀 验证方案概述

训练完成后，我们使用 vLLM + sLoRA 方式来验证ERD模型的实际效果，这是最接近生产环境的验证方式。

## 📋 验证流程

### 1. 自动化验证（推荐）
```bash
# 训练+验证一体化
./train_and_verify.sh conservative

# 仅验证已训练模型
./verify_erd_model.sh --lora-path data/models/erd_conservative
```

### 2. 手动验证步骤
```bash
# 1. 确认训练完成
ls -la data/models/erd_conservative/

# 2. 启动验证
./verify_erd_model.sh --lora-path data/models/erd_conservative --port 8000

# 3. 查看结果
cat vllm_service.log
```

## 🧪 验证测试内容

### 关系识别能力测试
- **直接关系识别**: 测试识别表间直接外键关系
- **间接关系推理**: 测试通过中间表推理复杂关系
- **复杂关系分析**: 测试多表多重关系理解

### SQL生成能力测试
- **简单查询生成**: 基础SELECT语句生成
- **关联查询生成**: JOIN语句和聚合查询生成

### 性能指标测试
- **响应时间**: 平均推理延迟
- **准确率**: 关键词匹配准确度
- **一致性**: 多次查询结果稳定性

## 📊 验证结果示例

### 成功验证输出
```
🚀 开始ERD模型验证测试
==================================================

📊 关系识别能力测试

🧪 测试: 直接关系识别
📝 提示: 在ERD中，订单表(orders)和客户表(customers)之间是什么关系？
🤖 回答: 订单表和客户表之间是一对多关系。customers表的主键customer_id作为orders表的外键，建立关联关系。一个客户可以有多个订单，但每个订单只属于一个客户。
⏱️  响应时间: 1.23秒
📊 得分: 4/4 (100.0%)

🧪 测试: 间接关系推理
📝 提示: 客户表如何通过订单表关联到产品表？
🤖 回答: 客户表通过以下路径关联到产品表：customers → orders → order_items → products。具体路径是customer_id关联到orders表，然后通过order_id关联到order_items表，最后通过product_id关联到products表。
⏱️  响应时间: 1.45秒
📊 得分: 4/4 (100.0%)

🎯 验证结果总结
==================================================
📊 总体准确率: 85.7% (12/14)
🧪 测试用例数: 5
⏱️  平均响应时间: 1.34秒
✅ 模型验证通过！ERD理解能力优秀
```

### 验证失败输出
```
🎯 验证结果总结
==================================================
📊 总体准确率: 45.2% (6/14)
🧪 测试用例数: 5
⏱️  平均响应时间: 2.15秒
❌ 模型验证未通过，需要进一步训练
```

## 🔧 验证配置选项

### 基本选项
```bash
./verify_erd_model.sh \
    --lora-path data/models/erd_conservative \  # LoRA模型路径
    --port 8000 \                               # vLLM服务端口
    --samples 10                                # 测试样本数量
```

### 高级配置
```bash
# 使用不同的LoRA模型
./verify_erd_model.sh --lora-path data/models/erd_memory_optimized

# 自定义端口（避免冲突）
./verify_erd_model.sh --port 8001

# 增加测试样本
./verify_erd_model.sh --samples 20
```

## 🎯 验证标准

### 优秀模型标准
- **总体准确率**: ≥ 80%
- **关系识别**: ≥ 85%
- **SQL生成**: ≥ 75%
- **响应时间**: ≤ 2.0秒

### 合格模型标准
- **总体准确率**: ≥ 60%
- **关系识别**: ≥ 65%
- **SQL生成**: ≥ 55%
- **响应时间**: ≤ 3.0秒

### 需要重训练
- **总体准确率**: < 60%
- **响应时间**: > 3.0秒
- **关键功能失效**: 无法识别基本关系

## 🚀 生产部署建议

### vLLM服务配置
```python
# 生产环境vLLM配置
from vllm import LLM, SamplingParams

llm = LLM(
    model="Qwen/Qwen2.5-3B-Instruct",
    enable_lora=True,
    lora_modules=[("erd_lora", "path/to/lora")],
    max_lora_rank=8,
    gpu_memory_utilization=0.8,
    tensor_parallel_size=1,  # 根据GPU数量调整
    trust_remote_code=True
)
```

### API服务部署
```bash
# 启动生产API服务
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-3B-Instruct \
    --enable-lora \
    --lora-modules erd_lora=path/to/lora \
    --host 0.0.0.0 \
    --port 8000 \
    --gpu-memory-utilization 0.8
```

## 🔍 故障排除

### 常见问题

#### 1. vLLM启动失败
```bash
# 检查CUDA环境
nvidia-smi

# 检查vLLM安装
pip install vllm --upgrade

# 检查内存使用
free -h
```

#### 2. LoRA模型加载失败
```bash
# 检查LoRA文件
ls -la data/models/erd_conservative/
# 应该包含: adapter_config.json, adapter_model.safetensors

# 检查文件完整性
python -c "
import torch
model = torch.load('data/models/erd_conservative/adapter_model.safetensors')
print('LoRA模型加载成功')
"
```

#### 3. 端口占用问题
```bash
# 查看端口使用
lsof -i :8000

# 杀死占用进程
pkill -f vllm

# 使用其他端口
./verify_erd_model.sh --port 8001
```

#### 4. 内存不足
```bash
# 清理GPU内存
./clear_gpu_memory.sh --all

# 降低GPU内存使用率
# 修改脚本中的 gpu_memory_utilization=0.6
```

## 📈 性能优化

### 推理加速
- **批处理**: 同时处理多个请求
- **KV缓存**: 启用键值缓存
- **量化**: 使用INT8/FP16量化

### 内存优化
- **分页注意力**: vLLM默认启用
- **动态批处理**: 自动批处理优化
- **内存映射**: 减少内存占用

## 🎉 验证成功后

### 下一步操作
1. **保存最佳模型** - 备份验证通过的LoRA权重
2. **部署生产环境** - 使用vLLM + LoRA配置
3. **监控性能** - 持续监控推理质量
4. **收集反馈** - 基于实际使用优化模型

### 模型版本管理
```bash
# 创建模型版本标签
cp -r data/models/erd_conservative data/models/erd_v1.0_verified

# 记录验证结果
echo "验证时间: $(date)" > data/models/erd_v1.0_verified/verification_result.txt
echo "准确率: 85.7%" >> data/models/erd_v1.0_verified/verification_result.txt
```

现在你的ERD模型具备了完整的训练+验证流程！🚀
