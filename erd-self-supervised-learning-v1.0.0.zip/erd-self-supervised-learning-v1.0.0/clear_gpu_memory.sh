#!/bin/bash
# GPU内存清理脚本
# 用于解决CUDA内存不足问题

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

echo "🧹 GPU内存清理工具"
echo "==================="

# 检测Python路径
PYTHON_CMD=""
if [ -f "/root/miniconda/bin/python" ]; then
    PYTHON_CMD="/root/miniconda/bin/python"
elif [ -f "/root/miniconda3/bin/python" ]; then
    PYTHON_CMD="/root/miniconda3/bin/python"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    log_error "未找到Python环境"
    exit 1
fi

# 显示当前GPU状态
show_gpu_status() {
    log_step "检查GPU状态..."
    
    if command -v nvidia-smi &> /dev/null; then
        echo ""
        nvidia-smi --query-gpu=index,name,memory.used,memory.free,memory.total,utilization.gpu --format=csv
        echo ""
        
        # 显示进程信息
        log_info "GPU进程信息:"
        nvidia-smi pmon -c 1 2>/dev/null || nvidia-smi
    else
        log_warn "nvidia-smi 不可用"
    fi
}

# 清理GPU内存
clear_gpu_memory() {
    log_step "清理GPU内存..."
    
    # 使用Python清理PyTorch缓存
    $PYTHON_CMD -c "
import torch
import gc

if torch.cuda.is_available():
    print(f'GPU数量: {torch.cuda.device_count()}')
    for i in range(torch.cuda.device_count()):
        print(f'GPU {i}: {torch.cuda.get_device_name(i)}')
        
        # 清理缓存
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        
        # 强制垃圾回收
        gc.collect()
        
        # 显示内存使用情况
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated(i) / 1024**3
            cached = torch.cuda.memory_reserved(i) / 1024**3
            print(f'GPU {i} - 已分配: {allocated:.2f}GB, 已缓存: {cached:.2f}GB')
    
    print('✅ GPU内存清理完成')
else:
    print('⚠️  CUDA不可用')
" 2>/dev/null || log_warn "Python GPU清理失败"
}

# 杀死占用GPU的进程
kill_gpu_processes() {
    log_step "检查GPU进程..."
    
    if command -v nvidia-smi &> /dev/null; then
        # 获取GPU进程PID
        local gpu_pids=$(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null)
        
        if [ -n "$gpu_pids" ]; then
            log_warn "发现GPU进程:"
            for pid in $gpu_pids; do
                if ps -p $pid > /dev/null 2>&1; then
                    local cmd=$(ps -p $pid -o comm= 2>/dev/null || echo "unknown")
                    echo "  PID: $pid, 命令: $cmd"
                fi
            done
            
            read -p "是否杀死这些进程? (y/N): " -n 1 -r
            echo
            
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                for pid in $gpu_pids; do
                    if ps -p $pid > /dev/null 2>&1; then
                        log_info "杀死进程: $pid"
                        kill -9 $pid 2>/dev/null || log_warn "无法杀死进程 $pid"
                    fi
                done
                sleep 2
                log_info "✅ GPU进程清理完成"
            else
                log_info "跳过进程清理"
            fi
        else
            log_info "✅ 没有发现GPU进程"
        fi
    fi
}

# 设置内存优化环境变量
set_memory_env() {
    log_step "设置内存优化环境变量..."
    
    export PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True,max_split_size_mb:256"
    export CUDA_LAUNCH_BLOCKING=0
    export TOKENIZERS_PARALLELISM=false
    
    # 写入环境配置文件
    cat > gpu_memory_env.sh << 'EOF'
#!/bin/bash
# GPU内存优化环境变量

export PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True,max_split_size_mb:256"
export CUDA_LAUNCH_BLOCKING=0
export TOKENIZERS_PARALLELISM=false

echo "✅ GPU内存优化环境变量已设置"
EOF
    
    chmod +x gpu_memory_env.sh
    log_info "✅ 环境变量配置文件已创建: gpu_memory_env.sh"
}

# 显示使用建议
show_recommendations() {
    echo ""
    log_info "🎯 内存优化建议:"
    echo "  1. 使用内存优化配置: config/qwen_3b_memory_optimized.yaml"
    echo "  2. 运行优化训练脚本: ./quick_train_memory_optimized.sh"
    echo "  3. 减少批次大小: batch_size=4"
    echo "  4. 增加梯度累积: gradient_accumulation_steps=8"
    echo "  5. 减少序列长度: max_length=1024"
    echo "  6. 使用更小的LoRA参数: r=4, alpha=8"
    echo ""
    log_info "🔧 如果仍然内存不足，可以进一步:"
    echo "  - 减少batch_size到2或1"
    echo "  - 减少max_length到512"
    echo "  - 使用更小的LoRA: r=2"
    echo ""
}

# 主函数
main() {
    case "${1:-}" in
        --status)
            show_gpu_status
            ;;
        --clear)
            clear_gpu_memory
            ;;
        --kill)
            kill_gpu_processes
            ;;
        --env)
            set_memory_env
            ;;
        --all)
            show_gpu_status
            kill_gpu_processes
            clear_gpu_memory
            set_memory_env
            show_recommendations
            ;;
        --help|"")
            echo "GPU内存清理工具"
            echo ""
            echo "用法: $0 [选项]"
            echo ""
            echo "选项:"
            echo "  --status      显示GPU状态"
            echo "  --clear       清理GPU内存"
            echo "  --kill        杀死GPU进程"
            echo "  --env         设置内存优化环境"
            echo "  --all         执行所有清理操作"
            echo "  --help        显示此帮助信息"
            echo ""
            ;;
        *)
            log_error "未知选项: $1"
            exit 1
            ;;
    esac
}

# 脚本入口
main "$@"
