#!/bin/bash
# SwanLab环境配置

# 完全禁用wandb
export WANDB_DISABLED=true
export WANDB_MODE=disabled
export WANDB_SILENT=true

# SwanLab配置
export SWANLAB_LOG_LEVEL=INFO
export SWANLAB_OFFLINE=false

echo "✅ SwanLab环境已配置"
