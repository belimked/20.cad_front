#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
智能自适应首次训练脚本 - Qwen3-8B
基于项目10轮训练成功经验，自动检测硬件并调整参数
作者：Claude 4.0 sonnet
版本：v1.1

使用方法：
单GPU训练：
    python first_time_training.py --data_path your_data.json

启用评估和双指标EarlyStopping（推荐）：
    python first_time_training.py --data_path your_data.json --enable_evaluation --enable_early_stopping

启用单指标EarlyStopping：
    python first_time_training.py --data_path your_data.json --enable_evaluation --enable_early_stopping --early_stopping_metric eval_loss

自定义双指标EarlyStopping参数：
    python first_time_training.py --data_path your_data.json --enable_evaluation --enable_early_stopping --early_stopping_patience 5 --early_stopping_threshold 0.0001

多GPU训练（推荐使用torchrun）：
    torchrun --nproc_per_node=2 first_time_training.py --data_path your_data.json --enable_distributed

旧版分布式启动（已弃用）：
    python -m torch.distributed.launch --nproc_per_node=2 first_time_training.py --data_path your_data.json --enable_distributed
"""

import os
import json
import torch
import logging
import time
import math
import sys
import argparse
import datetime
import smtplib
import subprocess
import requests
import signal
import psutil
from pathlib import Path
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig
)
from transformers.trainer_callback import TrainerCallback
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel
from datasets import Dataset
import warnings

# 过滤 bitsandbytes 的数据类型转换警告
warnings.filterwarnings("ignore", message="MatMul8bitLt: inputs will be cast from .* to float16 during quantization")

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# SwanLab 集成检测
try:
    import swanlab
    from swanlab.integration.transformers import SwanLabCallback
    SWANLAB_AVAILABLE = True
    logger.info("✅ SwanLab 已安装并可用")
except ImportError:
    SWANLAB_AVAILABLE = False
    logger.warning("⚠️ SwanLab 未安装，将跳过 SwanLab 集成")
    logger.info("💡 安装命令: pip install swanlab")

class GPUProcessManager:
    """GPU进程管理器 - 检查和清理占用GPU的进程"""

    def __init__(self):
        self.system_processes = {
            'Xorg', 'gnome-shell', 'kwin', 'plasmashell', 'compiz',
            'nvidia-persistenced', 'nvidia-modeset', 'systemd'
        }

    def get_gpu_processes(self):
        """获取所有占用GPU的进程信息"""
        try:
            # 使用nvidia-smi获取GPU进程信息
            result = subprocess.run([
                'nvidia-smi', '--query-compute-apps=pid,process_name,used_memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=10)

            if result.returncode != 0:
                logger.warning("无法获取GPU进程信息，nvidia-smi命令失败")
                return []

            processes = []
            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    parts = line.split(', ')
                    if len(parts) >= 3:
                        pid = int(parts[0])
                        process_name = parts[1]
                        memory_mb = int(parts[2])

                        # 获取更详细的进程信息
                        try:
                            proc = psutil.Process(pid)
                            cmd_line = ' '.join(proc.cmdline()[:3])  # 只取前3个参数
                            processes.append({
                                'pid': pid,
                                'name': process_name,
                                'cmdline': cmd_line,
                                'memory_mb': memory_mb,
                                'is_system': process_name in self.system_processes
                            })
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            processes.append({
                                'pid': pid,
                                'name': process_name,
                                'cmdline': process_name,
                                'memory_mb': memory_mb,
                                'is_system': process_name in self.system_processes
                            })

            return processes

        except subprocess.TimeoutExpired:
            logger.warning("nvidia-smi命令超时")
            return []
        except Exception as e:
            logger.warning(f"获取GPU进程信息失败: {str(e)}")
            return []

    def display_gpu_processes(self, processes):
        """显示GPU进程信息"""
        if not processes:
            logger.info("✅ 没有发现占用GPU的进程")
            return

        print("\n" + "="*80)
        print("🔍 发现以下进程正在占用GPU:")
        print("="*80)
        print(f"{'序号':<4} {'PID':<8} {'进程名':<20} {'显存(MB)':<10} {'类型':<8} {'命令行'}")
        print("-"*80)

        for i, proc in enumerate(processes, 1):
            proc_type = "系统" if proc['is_system'] else "用户"
            type_color = "🟡" if proc['is_system'] else "🔴"

            print(f"{i:<4} {proc['pid']:<8} {proc['name']:<20} {proc['memory_mb']:<10} "
                  f"{type_color}{proc_type:<7} {proc['cmdline'][:40]}")

        print("="*80)

    def kill_process_safely(self, pid, process_name):
        """安全地终止进程"""
        try:
            proc = psutil.Process(pid)

            # 先尝试优雅终止 (SIGTERM)
            logger.info(f"🔄 正在优雅终止进程 {process_name} (PID: {pid})...")
            proc.terminate()

            # 等待进程退出
            try:
                proc.wait(timeout=5)
                logger.info(f"✅ 进程 {process_name} (PID: {pid}) 已优雅退出")
                return True
            except psutil.TimeoutExpired:
                # 如果5秒后还没退出，强制终止 (SIGKILL)
                logger.warning(f"⚠️ 进程 {process_name} (PID: {pid}) 未响应，强制终止...")
                proc.kill()
                proc.wait(timeout=3)
                logger.info(f"✅ 进程 {process_name} (PID: {pid}) 已强制终止")
                return True

        except psutil.NoSuchProcess:
            logger.info(f"ℹ️ 进程 {process_name} (PID: {pid}) 已不存在")
            return True
        except psutil.AccessDenied:
            logger.error(f"❌ 没有权限终止进程 {process_name} (PID: {pid})")
            return False
        except Exception as e:
            logger.error(f"❌ 终止进程 {process_name} (PID: {pid}) 失败: {str(e)}")
            return False

    def interactive_cleanup(self, processes):
        """交互式清理GPU进程"""
        if not processes:
            return True

        user_processes = [p for p in processes if not p['is_system']]
        system_processes = [p for p in processes if p['is_system']]

        if not user_processes and system_processes:
            print("\n🟡 只发现系统进程占用GPU，通常不需要清理")
            return True

        print(f"\n📊 进程统计:")
        print(f"  用户进程: {len(user_processes)} 个")
        print(f"  系统进程: {len(system_processes)} 个")
        print(f"  总显存占用: {sum(p['memory_mb'] for p in processes)} MB")

        while True:
            print(f"\n🤔 请选择操作:")
            print("  1. 清理所有用户进程 (推荐)")
            print("  2. 选择性清理进程")
            print("  3. 清理所有进程 (包括系统进程)")
            print("  4. 跳过清理，继续训练")
            print("  5. 退出程序")

            choice = input("\n请输入选择 (1-5): ").strip()

            if choice == '1':
                return self._cleanup_processes(user_processes)
            elif choice == '2':
                return self._selective_cleanup(processes)
            elif choice == '3':
                return self._cleanup_processes(processes)
            elif choice == '4':
                print("⚠️ 跳过GPU清理，继续训练...")
                return True
            elif choice == '5':
                print("👋 程序已退出")
                sys.exit(0)
            else:
                print("❌ 无效选择，请重新输入")

    def _cleanup_processes(self, processes):
        """清理指定的进程列表"""
        if not processes:
            return True

        print(f"\n🚀 开始清理 {len(processes)} 个进程...")
        success_count = 0

        for proc in processes:
            if self.kill_process_safely(proc['pid'], proc['name']):
                success_count += 1

        print(f"\n📊 清理结果: {success_count}/{len(processes)} 个进程已清理")

        # 验证清理效果
        time.sleep(2)
        remaining = self.get_gpu_processes()
        if remaining:
            print(f"⚠️ 仍有 {len(remaining)} 个进程占用GPU")
            self.display_gpu_processes(remaining)
            return False
        else:
            print("✅ GPU清理完成，所有进程已释放GPU资源")
            return True

    def _selective_cleanup(self, processes):
        """选择性清理进程"""
        print(f"\n📝 请选择要清理的进程 (输入序号，多个序号用空格分隔):")

        selected_input = input("序号: ").strip()
        if not selected_input:
            return True

        try:
            selected_indices = [int(x) - 1 for x in selected_input.split()]
            selected_processes = []

            for idx in selected_indices:
                if 0 <= idx < len(processes):
                    selected_processes.append(processes[idx])
                else:
                    print(f"⚠️ 序号 {idx + 1} 无效，已忽略")

            if selected_processes:
                return self._cleanup_processes(selected_processes)
            else:
                print("❌ 没有选择有效的进程")
                return False

        except ValueError:
            print("❌ 输入格式错误，请输入数字序号")
            return False

    def _force_cleanup_gpu(self):
        """强力清理GPU显存（处理僵尸进程）"""
        logger.warning("🔥 执行强力GPU清理...")

        try:
            # 方法1：使用fuser清理GPU设备文件
            logger.info("🔧 尝试使用fuser清理GPU设备...")
            try:
                result = subprocess.run([
                    'fuser', '-k', '/dev/nvidia0', '/dev/nvidia1', '/dev/nvidiactl', '/dev/nvidia-uvm'
                ], capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    logger.info("✅ fuser清理完成")
                else:
                    logger.warning("⚠️ fuser清理可能需要sudo权限")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                logger.warning("⚠️ fuser命令不可用或超时")

            # 方法2：强制杀死所有Python训练进程
            logger.info("🔧 强制清理Python训练进程...")
            try:
                # 查找并杀死训练相关的Python进程
                result = subprocess.run([
                    'pkill', '-f', 'first_time_training'
                ], capture_output=True, text=True, timeout=5)

                result2 = subprocess.run([
                    'pkill', '-f', 'torch.*distributed'
                ], capture_output=True, text=True, timeout=5)

                logger.info("✅ Python训练进程清理完成")
            except subprocess.TimeoutExpired:
                logger.warning("⚠️ pkill命令超时")

            # 等待GPU状态更新
            time.sleep(3)

            # 验证清理效果
            remaining = self.get_gpu_processes()
            if not remaining:
                logger.info("✅ 强力清理成功，GPU已释放")
                return True
            else:
                logger.warning(f"⚠️ 强力清理后仍有 {len(remaining)} 个进程占用GPU")
                logger.info("💡 建议手动执行: sudo fuser -k /dev/nvidia* 或重启系统")
                return False

        except Exception as e:
            logger.error(f"❌ 强力清理失败: {str(e)}")
            return False

    def check_and_cleanup_gpu(self, auto_cleanup=True):
        """检查并清理GPU进程的主入口"""
        logger.info("🔍 检查GPU进程占用情况...")

        processes = self.get_gpu_processes()
        self.display_gpu_processes(processes)

        if not processes:
            return True

        # 直接清理用户进程，不需要交互
        user_processes = [p for p in processes if not p['is_system']]
        system_processes = [p for p in processes if p['is_system']]

        if user_processes:
            logger.info(f"🚀 发现 {len(user_processes)} 个用户进程占用GPU，开始清理...")
            success = self._cleanup_processes(user_processes)

            # 如果常规清理失败，尝试强力清理
            if not success:
                logger.warning("⚠️ 常规清理失败，尝试强力清理...")
                success = self._force_cleanup_gpu()

            if system_processes:
                logger.info(f"ℹ️ 保留 {len(system_processes)} 个系统进程（{', '.join(p['name'] for p in system_processes)}）")

            return success
        elif system_processes:
            logger.info(f"ℹ️ 只有 {len(system_processes)} 个系统进程占用GPU，跳过清理")
            return True
        else:
            return True

class HardwareDetector:
    """硬件检测和参数自适应类"""
    
    def __init__(self, check_gpu_processes=True):
        self.gpu_info = self._detect_gpu()
        self.recommended_params = self._get_recommended_params()
        self.gpu_process_manager = GPUProcessManager()

        # 检查GPU进程占用
        if check_gpu_processes and self.gpu_info["type"] != "cpu":
            self.check_gpu_processes()
    
    def _detect_gpu(self):
        """检测GPU硬件信息"""
        if not torch.cuda.is_available():
            return {"type": "cpu", "count": 0, "memory": 0}
        
        gpu_count = torch.cuda.device_count()
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1024**3  # GB
        
        # 检测GPU类型
        gpu_type = "unknown"
        if "4090" in gpu_name or "RTX 4090" in gpu_name:
            gpu_type = "rtx4090"
        elif "A100" in gpu_name:
            gpu_type = "a100"
        elif "3090" in gpu_name or "RTX 3090" in gpu_name:
            gpu_type = "rtx3090"
        elif "V100" in gpu_name:
            gpu_type = "v100"
        
        return {
            "type": gpu_type,
            "name": gpu_name,
            "count": gpu_count,
            "memory": gpu_memory
        }
    
    def _get_recommended_params(self):
        """根据硬件获取推荐参数"""
        gpu_type = self.gpu_info["type"]
        gpu_count = self.gpu_info["count"]
        gpu_memory = self.gpu_info["memory"]
        
        # 基于项目成功经验的参数配置
        if gpu_type == "rtx4090":
            # RTX 4090双卡优化配置
            if gpu_count >= 2:
                return {
                    "batch_size": 2,  # 降低batch_size以减少显存占用
                    "gradient_accumulation_steps": 8,  # 增加梯度累积步数保持有效批次大小
                    "learning_rate": 5e-6,
                    "max_length": 1024,
                    "lora_r": 16,
                    "lora_alpha": 16,
                    "use_8bit": True,
                    "use_flash_attention": True,
                    "dataloader_num_workers": 2  # 减少数据加载线程
                }
            else:
                return {
                    "batch_size": 2 if gpu_memory >= 20 else 1,
                    "gradient_accumulation_steps": 8,
                    "learning_rate": 5e-6,
                    "max_length": 1024,
                    "lora_r": 16,
                    "lora_alpha": 16,
                    "use_8bit": True,
                    "use_flash_attention": True,
                    "dataloader_num_workers": 2
                }
        elif gpu_type == "a100":
            return {
                "batch_size": 4 if gpu_count >= 2 else 2,
                "gradient_accumulation_steps": 4,
                "learning_rate": 5e-6,
                "max_length": 1024,
                "lora_r": 16,
                "lora_alpha": 16,
                "use_8bit": True,
                "use_flash_attention": True
            }
        elif gpu_type == "rtx3090":
            return {
                "batch_size": 1,
                "gradient_accumulation_steps": 16,
                "learning_rate": 5e-6,
                "max_length": 1024,
                "lora_r": 16,
                "lora_alpha": 16,
                "use_8bit": True,
                "use_flash_attention": False
            }
        else:
            # 保守配置
            return {
                "batch_size": 1,
                "gradient_accumulation_steps": 8,
                "learning_rate": 5e-6,
                "max_length": 512,
                "lora_r": 8,
                "lora_alpha": 16,
                "use_8bit": True,
                "use_flash_attention": False
            }
    
    def print_hardware_info(self):
        """打印硬件信息"""
        logger.info("=== 硬件检测结果 ===")
        logger.info(f"GPU类型: {self.gpu_info['name']}")
        logger.info(f"GPU数量: {self.gpu_info['count']}")
        logger.info(f"GPU显存: {self.gpu_info['memory']:.1f}GB")
        logger.info(f"检测类型: {self.gpu_info['type']}")
        
        logger.info("=== 推荐参数 ===")
        for key, value in self.recommended_params.items():
            logger.info(f"{key}: {value}")

    def check_gpu_processes(self, auto_cleanup=False):
        """检查GPU进程占用"""
        return self.gpu_process_manager.check_and_cleanup_gpu(auto_cleanup)

class DataProcessor:
    """数据处理和验证类"""
    
    def __init__(self, data_path):
        self.data_path = data_path
        self.data = None
        self.data_format = None
    
    def load_and_validate(self):
        """加载和验证数据"""
        logger.info(f"加载数据: {self.data_path}")
        
        if not os.path.exists(self.data_path):
            raise FileNotFoundError(f"数据文件不存在: {self.data_path}")
        
        # 根据文件扩展名加载数据
        if self.data_path.endswith('.json'):
            with open(self.data_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        elif self.data_path.endswith('.jsonl'):
            self.data = []
            with open(self.data_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        self.data.append(json.loads(line))
        else:
            raise ValueError("不支持的数据格式，请使用JSON或JSONL文件")
        
        # 验证数据格式
        self._validate_format()
        
        logger.info(f"数据加载成功，共 {len(self.data)} 条记录")
        logger.info(f"数据格式: {self.data_format}")
        
        return self.data
    
    def _validate_format(self):
        """验证数据格式"""
        if not self.data:
            raise ValueError("数据为空")

        sample = self.data[0]

        # 检查messages格式（ChatML格式）
        if "messages" in sample:
            if isinstance(sample["messages"], list) and len(sample["messages"]) >= 2:
                # 验证messages格式的基本结构
                for msg in sample["messages"]:
                    if not isinstance(msg, dict) or "role" not in msg or "content" not in msg:
                        raise ValueError("messages格式错误：每个消息必须包含role和content字段")
                self.data_format = "messages"
        # 检查prompt-completion格式
        elif "prompt" in sample and "completion" in sample:
            self.data_format = "prompt-completion"
        elif "instruction" in sample and "output" in sample:
            self.data_format = "instruction-output"
        elif "input" in sample and "target" in sample:
            self.data_format = "input-target"
        else:
            raise ValueError(f"不支持的数据格式，样本键: {list(sample.keys())}")

class WeChatNotifier:
    """微信推送通知类"""

    def __init__(self, enabled=True, push_url="https://nsocra.test.belimked.com:9002/wechat/api/message/push", timeout=10):
        self.enabled = enabled
        self.push_url = push_url
        self.timeout = timeout

        # 检查微信推送服务连通性
        if self.enabled:
            self._check_service_connectivity()

    def _check_service_connectivity(self):
        """检查微信推送服务连通性"""
        try:
            logger.info("🔍 检查微信推送服务连通性...")
            test_response = requests.post(
                self.push_url,
                json={"message_type": "test", "extra_vars": {}},
                timeout=5,
                headers={"Content-Type": "application/json"}
            )

            if test_response.status_code in [200, 400, 422]:
                logger.info("✅ 微信推送服务连接正常")
            else:
                logger.warning(f"⚠️ 微信推送服务连接异常(HTTP:{test_response.status_code})，将禁用微信通知")
                self.enabled = False

        except Exception as e:
            logger.warning(f"⚠️ 微信推送服务连接失败: {str(e)}，将禁用微信通知")
            self.enabled = False

    def _create_payload(self, notification_type, title, task_info, status, result, time_info, details, task_id):
        """构造微信推送数据"""
        # 根据通知类型设置颜色
        title_color = "#173177"
        status_color = "#00AA00"

        if notification_type in ["ai_task_unified", "process_start"]:
            status_color = "#0066CC"
        elif notification_type in ["error", "failed"]:
            status_color = "#FF0000"
        elif notification_type == "warning":
            status_color = "#FF6600"
        elif notification_type in ["complete", "success"]:
            status_color = "#00AA00"

        return {
            "message_type": "ai_task_unified",
            "extra_vars": {
                "title": {"value": title, "color": title_color},
                "task_info": {"value": task_info, "color": "#0066CC"},
                "status": {"value": status, "color": status_color},
                "result": {"value": result, "color": "#666666"},
                "time_info": {"value": time_info, "color": "#999999"},
                "details": {"value": details, "color": "#0066CC"},
                "task_id": {"value": task_id, "color": "#666666"},
                "task_type": {"value": notification_type, "color": "#666666"}
            }
        }

    def send_notification(self, notification_type, title, task_info, status, result, time_info, details, task_id):
        """发送微信推送通知"""
        if not self.enabled:
            return False

        try:
            payload = self._create_payload(notification_type, title, task_info, status, result, time_info, details, task_id)

            response = requests.post(
                self.push_url,
                json=payload,
                timeout=self.timeout,
                headers={"Content-Type": "application/json"}
            )

            if response.status_code == 200:
                result_data = response.json()
                if result_data.get("success") or result_data.get("errcode") == 0:
                    logger.info("📱 微信推送通知发送成功")
                    return True

            logger.warning(f"📱 微信推送通知发送失败: {response.text}")
            return False

        except Exception as e:
            logger.warning(f"📱 微信推送通知发送异常: {str(e)}")
            return False

class EarlyStoppingCallback(TrainerCallback):
    """
    智能早停回调 - 基于双指标联合监控自动停止训练

    同时监控train_loss和eval_loss的变化趋势，当两个指标都停止改善时，
    自动停止训练，避免过拟合并节省计算资源。
    """

    def __init__(self, patience=3, min_delta=0.0001, metric_for_best_model="dual_loss",
                 train_metric="loss", eval_metric="eval_loss",
                 email_config=None, wechat_config=None,
                 task_name="训练任务", is_main_process=True):
        """
        初始化早停回调

        Args:
            patience (int): 容忍的评估轮次，默认3
            min_delta (float): 最小改善阈值，默认0.0001（更敏感的改善检测）
            metric_for_best_model (str): 监控模式，"dual_loss"表示双指标模式
            train_metric (str): 训练指标名称，默认"loss"
            eval_metric (str): 评估指标名称，默认"eval_loss"
            email_config (dict): 邮件配置
            wechat_config (dict): 微信配置
            task_name (str): 任务名称
            is_main_process (bool): 是否为主进程
        """
        self.patience = patience
        self.min_delta = min_delta
        self.metric_for_best_model = metric_for_best_model
        self.train_metric = train_metric
        self.eval_metric = eval_metric
        self.email_config = email_config
        self.wechat_notifier = WeChatNotifier(**wechat_config) if wechat_config else None
        self.task_name = task_name
        self.is_main_process = is_main_process

        # 双指标模式检测
        self.is_dual_mode = metric_for_best_model == "dual_loss"

        if self.is_dual_mode:
            # 双指标早停状态
            self.best_train_loss = None
            self.best_eval_loss = None
            self.patience_counter = 0
            self.should_stop = False
            self.best_step = 0
            self.best_epoch = 0

            logger.info(f"🛑 双指标EarlyStopping已启用:")
            logger.info(f"   训练指标: {self.train_metric}")
            logger.info(f"   评估指标: {self.eval_metric}")
            logger.info(f"   耐心值: {self.patience}")
            logger.info(f"   最小改善: {self.min_delta}")
            logger.info(f"   停止条件: 两个指标都无改善时增加耐心计数")
        else:
            # 单指标模式（兼容原有逻辑）
            self.greater_is_better = False if "loss" in metric_for_best_model.lower() else True
            self.best_metric = None
            self.patience_counter = 0
            self.should_stop = False
            self.best_step = 0
            self.best_epoch = 0

            logger.info(f"🛑 单指标EarlyStopping已启用:")
            logger.info(f"   监控指标: {self.metric_for_best_model}")
            logger.info(f"   耐心值: {self.patience}")
            logger.info(f"   最小改善: {self.min_delta}")
            logger.info(f"   越大越好: {self.greater_is_better}")

    def on_evaluate(self, args, state, control, **kwargs):
        """评估结束后检查是否需要早停"""
        if not state.log_history:
            return control

        # 获取最新的评估结果
        current_logs = state.log_history[-1]

        if self.is_dual_mode:
            return self._dual_metric_early_stopping(current_logs, state, control)
        else:
            return self._single_metric_early_stopping(current_logs, state, control)

    def _dual_metric_early_stopping(self, current_logs, state, control):
        """双指标早停逻辑"""
        # 检查评估指标是否存在
        if self.eval_metric not in current_logs:
            logger.warning(f"⚠️ 评估指标 {self.eval_metric} 未在日志中找到")
            return control

        current_eval_loss = current_logs[self.eval_metric]

        # 从历史日志中查找最近的训练损失
        current_train_loss = None
        for log_entry in reversed(state.log_history):
            if self.train_metric in log_entry:
                current_train_loss = log_entry[self.train_metric]
                break

        if current_train_loss is None:
            logger.warning(f"⚠️ 训练指标 {self.train_metric} 未在历史日志中找到")
            return control

        logger.debug(f"🔍 双指标早停检查: {self.train_metric}={current_train_loss:.6f}, {self.eval_metric}={current_eval_loss:.6f}")

        # 初始化最佳指标
        if self.best_train_loss is None or self.best_eval_loss is None:
            self.best_train_loss = current_train_loss
            self.best_eval_loss = current_eval_loss
            self.best_step = state.global_step
            self.best_epoch = state.epoch
            logger.info(f"📊 初始化双指标:")
            logger.info(f"   最佳{self.train_metric}: {self.best_train_loss:.6f}")
            logger.info(f"   最佳{self.eval_metric}: {self.best_eval_loss:.6f}")
            logger.info(f"   步数: {self.best_step}")
            return control

        # 计算改善幅度
        train_improvement = self.best_train_loss - current_train_loss
        eval_improvement = self.best_eval_loss - current_eval_loss

        # 检查训练损失是否改善
        train_improved = current_train_loss < self.best_train_loss - self.min_delta
        # 检查评估损失是否改善
        eval_improved = current_eval_loss < self.best_eval_loss - self.min_delta

        # 检查是否有微小变化（在阈值内）
        train_stable = abs(current_train_loss - self.best_train_loss) <= self.min_delta
        eval_stable = abs(current_eval_loss - self.best_eval_loss) <= self.min_delta

        # 调试信息
        logger.debug(f"🔍 早停判断详情:")
        logger.debug(f"   训练损失改善: {train_improvement:.6f} (阈值: {self.min_delta:.6f}) -> {'✅' if train_improved else '❌'}")
        logger.debug(f"   评估损失改善: {eval_improvement:.6f} (阈值: {self.min_delta:.6f}) -> {'✅' if eval_improved else '❌'}")
        logger.debug(f"   训练损失稳定: {'✅' if train_stable else '❌'}")
        logger.debug(f"   评估损失稳定: {'✅' if eval_stable else '❌'}")

        # 决策逻辑（在更新最佳值之前进行判断）
        should_continue = False
        reason = ""

        if train_improved and eval_improved:
            should_continue = True
            reason = "训练损失和评估损失都改善"
        elif train_improved and (eval_improved or eval_stable):
            should_continue = True
            reason = "训练损失改善，评估损失稳定或改善"
        elif train_improved and not eval_improved:
            should_continue = True
            reason = "训练损失改善（评估损失变差但继续观察）"
        elif train_stable and eval_improved:
            should_continue = True
            reason = "评估损失改善，训练损失稳定"
        else:
            # train_stable/变差 且 eval_stable/变差
            should_continue = False
            reason = "训练损失和评估损失都无明显改善"

        # 更新最佳值（在决策完成后）
        if train_improved:
            self.best_train_loss = current_train_loss
        if eval_improved:
            self.best_eval_loss = current_eval_loss

        if should_continue:
            # 重置耐心计数器
            if self.patience_counter > 0:
                logger.info(f"🔄 重置耐心计数器: {reason}")
            self.patience_counter = 0
            self.best_step = state.global_step
            self.best_epoch = state.epoch

            logger.info(f"✅ 继续训练: {reason}")
            logger.info(f"   当前{self.train_metric}: {current_train_loss:.6f} (最佳: {self.best_train_loss:.6f})")
            logger.info(f"   当前{self.eval_metric}: {current_eval_loss:.6f} (最佳: {self.best_eval_loss:.6f})")
        else:
            # 增加耐心计数器
            self.patience_counter += 1
            logger.info(f"⏳ {reason}")
            # 显示原始的最佳值（未更新前的）
            display_best_train = self.best_train_loss if not train_improved else current_train_loss
            display_best_eval = self.best_eval_loss if not eval_improved else current_eval_loss
            logger.info(f"   当前{self.train_metric}: {current_train_loss:.6f} (最佳: {display_best_train:.6f})")
            logger.info(f"   当前{self.eval_metric}: {current_eval_loss:.6f} (最佳: {display_best_eval:.6f})")
            logger.info(f"   耐心计数: {self.patience_counter}/{self.patience}")

            # 检查是否达到早停条件
            if self.patience_counter >= self.patience:
                self.should_stop = True
                logger.warning(f"🛑 触发双指标EarlyStopping!")
                logger.info(f"   最佳{self.train_metric}: {self.best_train_loss:.6f}")
                logger.info(f"   最佳{self.eval_metric}: {self.best_eval_loss:.6f}")
                logger.info(f"   最佳步数: {self.best_step}")
                logger.info(f"   最佳轮次: {self.best_epoch:.2f}")
                logger.info(f"   当前步数: {state.global_step}")
                logger.info(f"   节省步数: {state.max_steps - state.global_step}")

                # 发送早停通知
                if self.is_main_process:
                    self._send_dual_early_stopping_notification(state)

                # 设置停止信号
                control.should_training_stop = True
                return control

    def _single_metric_early_stopping(self, current_logs, state, control):
        """单指标早停逻辑（兼容原有功能）"""
        if self.metric_for_best_model not in current_logs:
            logger.warning(f"⚠️ 监控指标 {self.metric_for_best_model} 未在评估结果中找到")
            return control

        current_metric = current_logs[self.metric_for_best_model]

        # 初始化最佳指标
        if self.best_metric is None:
            self.best_metric = current_metric
            self.best_step = state.global_step
            self.best_epoch = state.epoch
            logger.info(f"📊 初始化最佳{self.metric_for_best_model}: {self.best_metric:.6f} (步数: {self.best_step})")
            return control

        # 检查是否有改善
        improved = False
        if self.greater_is_better:
            if current_metric > self.best_metric + self.min_delta:
                improved = True
        else:
            if current_metric < self.best_metric - self.min_delta:
                improved = True

        if improved:
            # 有改善，重置计数器
            improvement = abs(current_metric - self.best_metric)
            self.best_metric = current_metric
            self.best_step = state.global_step
            self.best_epoch = state.epoch
            self.patience_counter = 0

            logger.info(f"✅ {self.metric_for_best_model}改善: {current_metric:.6f} "
                       f"(改善: {improvement:.6f}, 步数: {state.global_step})")
        else:
            # 没有改善，增加计数器
            self.patience_counter += 1
            logger.info(f"⏳ {self.metric_for_best_model}无改善: {current_metric:.6f} "
                       f"(最佳: {self.best_metric:.6f}, 耐心: {self.patience_counter}/{self.patience})")

            # 检查是否达到早停条件
            if self.patience_counter >= self.patience:
                self.should_stop = True
                logger.warning(f"🛑 触发EarlyStopping!")
                logger.info(f"   最佳{self.metric_for_best_model}: {self.best_metric:.6f}")
                logger.info(f"   最佳步数: {self.best_step}")
                logger.info(f"   最佳轮次: {self.best_epoch:.2f}")
                logger.info(f"   当前步数: {state.global_step}")
                logger.info(f"   节省步数: {state.max_steps - state.global_step}")

                # 发送早停通知
                if self.is_main_process:
                    self._send_early_stopping_notification(state)

                # 设置停止信号
                control.should_training_stop = True
                return control

    def _send_dual_early_stopping_notification(self, state):
        """发送双指标早停通知"""
        try:
            current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            saved_steps = state.max_steps - state.global_step
            saved_percentage = (saved_steps / state.max_steps) * 100

            # 发送邮件通知
            if self.email_config:
                try:
                    subject = f"🛑 {self.task_name} - 双指标EarlyStopping触发"
                    content = f"""
双指标EarlyStopping已触发，训练提前结束 🛑

任务名称: {self.task_name}
触发时间: {current_time}
监控模式: 双指标联合监控
训练指标: {self.train_metric} = {self.best_train_loss:.6f}
评估指标: {self.eval_metric} = {self.best_eval_loss:.6f}
最佳步数: {self.best_step}
最佳轮次: {self.best_epoch:.2f}
当前步数: {state.global_step}
总计划步数: {state.max_steps}
节省步数: {saved_steps} ({saved_percentage:.1f}%)
耐心值: {self.patience}

停止原因: 训练损失和评估损失都停止改善
这是一个正常的训练优化，表明模型已达到最佳性能点 ✅
"""

                    message = MIMEMultipart()
                    message['From'] = self.email_config["smtp_user"]
                    message['To'] = self.email_config["email_to"]
                    message['Subject'] = Header(subject, 'utf-8')
                    message.attach(MIMEText(content, 'plain', 'utf-8'))

                    smtp_obj = smtplib.SMTP_SSL(self.email_config["smtp_host"])
                    smtp_obj.connect(self.email_config["smtp_host"], 465)
                    smtp_obj.login(self.email_config["smtp_user"], self.email_config["smtp_pass"])
                    smtp_obj.sendmail(self.email_config["smtp_user"], [self.email_config["email_to"]], message.as_string())
                    smtp_obj.quit()

                    logger.info("📧 双指标EarlyStopping邮件通知已发送")
                except Exception as e:
                    logger.warning(f"📧 双指标EarlyStopping邮件发送失败: {str(e)}")

            # 发送微信通知
            if self.wechat_notifier:
                try:
                    task_id = f"dual_early_stop_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

                    title = f"🛑 {self.task_name} - 双指标EarlyStopping触发"
                    task_info = f"监控: {self.train_metric} + {self.eval_metric}"
                    status = "训练提前结束"
                    result = f"最佳训练损失: {self.best_train_loss:.6f}, 最佳评估损失: {self.best_eval_loss:.6f}"
                    time_info = f"触发时间: {current_time}"
                    details = f"双指标都停止改善，节省了 {saved_steps} 步训练 ({saved_percentage:.1f}%)"

                    success = self.wechat_notifier.send_notification(
                        notification_type="warning",
                        title=title,
                        task_info=task_info,
                        status=status,
                        result=result,
                        time_info=time_info,
                        details=details,
                        task_id=task_id
                    )

                    if success:
                        logger.info("📱 双指标EarlyStopping微信通知已发送")
                    else:
                        logger.warning("📱 双指标EarlyStopping微信通知发送失败")

                except Exception as e:
                    logger.warning(f"📱 双指标EarlyStopping微信通知发送异常: {str(e)}")

        except Exception as e:
            logger.error(f"❌ 双指标EarlyStopping通知发送过程出错: {str(e)}")

    def _send_early_stopping_notification(self, state):
        """发送早停通知"""
        try:
            current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            saved_steps = state.max_steps - state.global_step
            saved_percentage = (saved_steps / state.max_steps) * 100

            # 发送邮件通知
            if self.email_config:
                try:
                    subject = f"🛑 {self.task_name} - EarlyStopping触发"
                    content = f"""
EarlyStopping已触发，训练提前结束 🛑

任务名称: {self.task_name}
触发时间: {current_time}
监控指标: {self.metric_for_best_model}
最佳指标值: {self.best_metric:.6f}
最佳步数: {self.best_step}
最佳轮次: {self.best_epoch:.2f}
当前步数: {state.global_step}
总计划步数: {state.max_steps}
节省步数: {saved_steps} ({saved_percentage:.1f}%)
耐心值: {self.patience}

这是一个正常的训练优化，表明模型已达到最佳性能点 ✅
"""

                    message = MIMEMultipart()
                    message['From'] = self.email_config["smtp_user"]
                    message['To'] = self.email_config["email_to"]
                    message['Subject'] = Header(subject, 'utf-8')
                    message.attach(MIMEText(content, 'plain', 'utf-8'))

                    smtp_obj = smtplib.SMTP_SSL(self.email_config["smtp_host"])
                    smtp_obj.connect(self.email_config["smtp_host"], 465)
                    smtp_obj.login(self.email_config["smtp_user"], self.email_config["smtp_pass"])
                    smtp_obj.sendmail(self.email_config["smtp_user"], [self.email_config["email_to"]], message.as_string())
                    smtp_obj.quit()

                    logger.info("📧 EarlyStopping邮件通知已发送")
                except Exception as e:
                    logger.warning(f"📧 EarlyStopping邮件发送失败: {str(e)}")

            # 发送微信通知
            if self.wechat_notifier:
                try:
                    task_id = f"early_stop_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

                    title = f"🛑 {self.task_name} - EarlyStopping触发"
                    task_info = f"监控指标: {self.metric_for_best_model}"
                    status = "训练提前结束"
                    result = f"最佳指标: {self.best_metric:.6f} (步数: {self.best_step})"
                    time_info = f"触发时间: {current_time}"
                    details = f"节省了 {saved_steps} 步训练 ({saved_percentage:.1f}%)，这是正常的训练优化"

                    success = self.wechat_notifier.send_notification(
                        notification_type="warning",
                        title=title,
                        task_info=task_info,
                        status=status,
                        result=result,
                        time_info=time_info,
                        details=details,
                        task_id=task_id
                    )

                    if success:
                        logger.info("📱 EarlyStopping微信通知已发送")
                    else:
                        logger.warning("📱 EarlyStopping微信通知发送失败")

                except Exception as e:
                    logger.warning(f"📱 EarlyStopping微信通知发送异常: {str(e)}")

        except Exception as e:
            logger.error(f"❌ EarlyStopping通知发送过程出错: {str(e)}")


class SmartTrainingCallback(TrainerCallback):
    """智能训练回调"""

    def __init__(self, log_file=None, email_config=None, wechat_config=None, task_name="首次训练", is_main_process=True):
        self.log_file = log_file
        self.start_time = time.time()
        self.email_config = email_config
        self.wechat_notifier = WeChatNotifier(**wechat_config) if wechat_config else None
        self.task_name = task_name
        self.last_notification_step = 0
        self.notification_interval = 100  # 每100步通知一次
        self.is_main_process = is_main_process  # 只有主进程发送通知
    
    def on_step_end(self, args, state, control, **kwargs):
        if state.global_step % args.logging_steps == 0 and state.global_step > 0:
            self._log_progress(state)
            
        # 智能通知（仅邮件，微信不发送进度通知）- 仅主进程发送
        if self.is_main_process and state.global_step - self.last_notification_step >= self.notification_interval:
            self._send_progress_notification(state)
            self.last_notification_step = state.global_step
    
    def _log_progress(self, state):
        """记录训练进度"""
        elapsed = time.time() - self.start_time
        avg_step_time = elapsed / state.global_step
        
        remaining_steps = state.max_steps - state.global_step
        remaining_seconds = remaining_steps * avg_step_time
        remaining_hours = int(remaining_seconds // 3600)
        remaining_minutes = int((remaining_seconds % 3600) // 60)
        
        current_time = datetime.datetime.now()
        completion_time = current_time + datetime.timedelta(seconds=remaining_seconds)
        
        progress_info = f"""
🚀 训练进度更新:
📊 当前步数: {state.global_step}/{state.max_steps} ({state.global_step/state.max_steps*100:.2f}%)
⏱️  已用时间: {elapsed/3600:.2f}小时
⚡ 平均步时间: {avg_step_time:.2f}秒/步
⏳ 预估剩余: {remaining_hours}小时{remaining_minutes}分钟
🎯 预计完成: {completion_time.strftime('%Y-%m-%d %H:%M:%S')}
📉 当前损失: {state.log_history[-1].get('loss', 'N/A') if state.log_history else 'N/A'}
"""
        logger.info(progress_info)
        
        if self.log_file:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(f"[{current_time.strftime('%Y-%m-%d %H:%M:%S')}] {progress_info}\n")
    
    def _send_progress_notification(self, state):
        """发送进度通知（邮件+微信）"""
        elapsed = time.time() - self.start_time
        progress_percent = state.global_step / state.max_steps * 100
        current_loss = state.log_history[-1].get('loss', 'N/A') if state.log_history else 'N/A'

        # 发送邮件通知
        if self.email_config and self.email_config.get("smtp_pass"):
            try:
                subject = f"🚀 {self.task_name} - 进度 {progress_percent:.1f}%"
                content = f"""
训练进度通知 📊

任务名称: {self.task_name}
当前进度: {state.global_step}/{state.max_steps} ({progress_percent:.2f}%)
已用时间: {elapsed/3600:.2f}小时
当前损失: {current_loss}

继续努力中... 💪
"""

                self._send_email(subject, content)
                logger.info(f"📧 进度通知邮件已发送")

            except Exception as e:
                logger.warning(f"邮件发送失败: {str(e)}")

        # 微信进度通知已禁用（避免频繁推送）
        # 只保留训练开始、完成和错误通知
    
    def _send_email(self, subject, content):
        """发送邮件"""
        message = MIMEMultipart()
        message['From'] = self.email_config["smtp_user"]
        message['To'] = self.email_config["email_to"]
        message['Subject'] = Header(subject, 'utf-8')
        
        message.attach(MIMEText(content, 'plain', 'utf-8'))
        
        smtp_obj = smtplib.SMTP_SSL(self.email_config["smtp_host"])
        smtp_obj.connect(self.email_config["smtp_host"], 465)
        smtp_obj.login(self.email_config["smtp_user"], self.email_config["smtp_pass"])
        smtp_obj.sendmail(self.email_config["smtp_user"], [self.email_config["email_to"]], message.as_string())
        smtp_obj.quit()

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="智能自适应首次训练脚本")
    
    # 必需参数
    parser.add_argument("--data_path", type=str, required=True,
                        help="训练数据文件路径 (JSON或JSONL格式)")
    
    # 可选参数
    parser.add_argument("--model_path", type=str,
                        default="/root/lanyun-tmp/modelscope_cache/qwen/Qwen3-1.7B",
                        help="预训练模型路径")
    
    parser.add_argument("--output_dir", type=str, default=None,
                        help="输出目录 (默认自动生成)")
    
    parser.add_argument("--num_epochs", type=int, default=3,
                        help="训练轮数 (默认3轮)")
    
    parser.add_argument("--test_mode", action="store_true",
                        help="测试模式，只使用10%数据")
    
    parser.add_argument("--override_batch_size", type=int, default=None,
                        help="覆盖自动检测的批次大小")
    
    parser.add_argument("--override_learning_rate", type=float, default=None,
                        help="覆盖自动检测的学习率")
    
    # 通知参数
    parser.add_argument("--email_to", type=str, default="",
                        help="通知邮件接收地址")

    parser.add_argument("--smtp_user", type=str, default="",
                        help="SMTP用户名")

    parser.add_argument("--smtp_pass", type=str, default="",
                        help="SMTP密码")

    parser.add_argument("--enable_wechat", action="store_true",
                        help="启用微信推送通知")

    parser.add_argument("--wechat_push_url", type=str,
                        default="https://nsocra.test.belimked.com:9002/wechat/api/message/push",
                        help="微信推送API地址")

    # SwanLab 参数
    parser.add_argument("--enable_swanlab", action="store_true",
                        help="启用 SwanLab 实验跟踪")

    parser.add_argument("--swanlab_project", type=str, default="qwen3-8b-training",
                        help="SwanLab 项目名称")

    parser.add_argument("--swanlab_experiment", type=str, default=None,
                        help="SwanLab 实验名称（默认自动生成）")

    parser.add_argument("--swanlab_description", type=str, default="",
                        help="SwanLab 实验描述")

    parser.add_argument("--swanlab_tags", type=str, nargs="*", default=[],
                        help="SwanLab 实验标签")

    parser.add_argument("--swanlab_api_key", type=str, default="",
                        help="SwanLab API Key（可选，也可通过环境变量或登录设置）")

    # 阶段评估参数
    parser.add_argument("--enable_evaluation", action="store_true",
                        help="启用阶段评估（将训练数据的10%用作评估，90%用于训练）")

    parser.add_argument("--eval_split_ratio", type=float, default=0.1,
                        help="评估数据占比（默认0.1，即10%）")

    parser.add_argument("--eval_steps", type=int, default=100,
                        help="评估间隔步数（默认100步）")

    parser.add_argument("--skip_gpu_check", action="store_true",
                        help="跳过GPU进程检查")

    # 分布式训练参数（兼容新旧启动方式）
    parser.add_argument("--local-rank", type=int, default=None,
                        help="本地进程排名（分布式训练，已弃用，请使用torchrun）")

    parser.add_argument("--per_device_train_batch_size", type=int, default=None,
                        help="每个设备的训练批次大小")

    parser.add_argument("--gradient_accumulation_steps", type=int, default=None,
                        help="梯度累积步数")

    parser.add_argument("--learning_rate", type=float, default=None,
                        help="学习率")

    parser.add_argument("--lr_scheduler_type", type=str, default="constant",
                        help="学习率调度器类型")

    parser.add_argument("--warmup_ratio", type=float, default=None,
                        help="预热比例")

    parser.add_argument("--logging_steps", type=int, default=20,
                        help="日志记录步数")

    parser.add_argument("--save_steps", type=int, default=50,
                        help="模型保存步数")

    parser.add_argument("--save_total_limit", type=int, default=3,
                        help="保存模型的最大数量")

    # 评估显存优化参数
    parser.add_argument("--per_device_eval_batch_size", type=int, default=None,
                        help="每个设备的评估批次大小")
    parser.add_argument("--eval_accumulation_steps", type=int, default=None,
                        help="评估时累积步骤数，降低显存峰值")

    parser.add_argument("--weight_decay", type=float, default=0.01,
                        help="权重衰减")

    parser.add_argument("--max_grad_norm", type=float, default=0.5,
                        help="梯度裁剪阈值")

    parser.add_argument("--lora_r", type=int, default=None,
                        help="LoRA rank")

    parser.add_argument("--lora_alpha", type=int, default=None,
                        help="LoRA alpha")

    parser.add_argument("--enable_distributed", action="store_true",
                        help="启用分布式训练")

    # 第二轮训练参数
    parser.add_argument("--second_round_training", action="store_true",
                        help="启用第二轮迭代训练模式")

    parser.add_argument("--first_lora_adapter_path", type=str, default="",
                        help="第一轮LoRA适配器路径")

    parser.add_argument("--combine_loras", action="store_true",
                        help="组合第一轮和第二轮LoRA适配器")

    # EarlyStopping 参数
    parser.add_argument("--enable_early_stopping", action="store_true",
                        help="启用EarlyStopping，基于评估损失自动停止训练")

    parser.add_argument("--early_stopping_patience", type=int, default=3,
                        help="EarlyStopping耐心值，连续多少个评估周期无改善后停止 (默认3)")

    parser.add_argument("--early_stopping_threshold", type=float, default=0.0001,
                        help="EarlyStopping最小改善阈值 (默认0.0001，更敏感的改善检测)")

    parser.add_argument("--early_stopping_metric", type=str, default="dual_loss",
                        help="EarlyStopping监控的指标名称 (dual_loss=双指标模式, eval_loss=单指标模式)")

    parser.add_argument("--early_stopping_train_metric", type=str, default="loss",
                        help="双指标模式下的训练指标名称 (默认loss)")

    parser.add_argument("--early_stopping_eval_metric", type=str, default="eval_loss",
                        help="双指标模式下的评估指标名称 (默认eval_loss)")

    return parser.parse_args()

def main():
    """主函数"""
    print("🎯 智能自适应首次训练脚本启动中...")
    
    # 解析参数
    args = parse_args()
    
    # 硬件检测
    check_gpu_processes = not args.skip_gpu_check
    detector = HardwareDetector(check_gpu_processes=check_gpu_processes)
    detector.print_hardware_info()

    # GPU进程检查和清理
    if not args.skip_gpu_check and detector.gpu_info["type"] != "cpu":
        logger.info("🔍 执行GPU进程检查和清理...")
        if not detector.check_gpu_processes():
            logger.warning("⚠️ GPU进程清理未完全成功，但将继续训练")
            logger.info("💡 如果训练因显存不足失败，请手动清理GPU进程后重试")
    
    # 数据处理
    processor = DataProcessor(args.data_path)
    data = processor.load_and_validate()
    
    # 测试模式
    if args.test_mode:
        sample_size = max(10, len(data) // 10)  # 至少10条，最多10%
        data = data[:sample_size]
        logger.info(f"🧪 测试模式: 使用 {sample_size} 条数据")
    
    # 生成输出目录
    if args.output_dir is None:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        data_name = Path(args.data_path).stem
        mode_suffix = "_test" if args.test_mode else ""
        args.output_dir = f"trainning/new/outputs/first_training_{data_name}_{timestamp}{mode_suffix}"
    
    os.makedirs(args.output_dir, exist_ok=True)
    logger.info(f"📁 输出目录: {args.output_dir}")
    
    # 获取推荐参数
    params = detector.recommended_params.copy()

    # 用户覆盖参数
    if args.override_batch_size:
        params["batch_size"] = args.override_batch_size
        logger.info(f"🔧 用户覆盖批次大小: {args.override_batch_size}")

    if args.override_learning_rate:
        params["learning_rate"] = args.override_learning_rate
        logger.info(f"🔧 用户覆盖学习率: {args.override_learning_rate}")

    # 分布式训练参数覆盖
    if args.per_device_train_batch_size:
        params["batch_size"] = args.per_device_train_batch_size
        logger.info(f"🔧 分布式批次大小: {args.per_device_train_batch_size}")

    if args.gradient_accumulation_steps:
        params["gradient_accumulation_steps"] = args.gradient_accumulation_steps
        logger.info(f"🔧 分布式梯度累积: {args.gradient_accumulation_steps}")

    if args.learning_rate:
        params["learning_rate"] = args.learning_rate
        logger.info(f"🔧 分布式学习率: {args.learning_rate}")

    if args.warmup_ratio:
        params["warmup_ratio"] = args.warmup_ratio
        logger.info(f"🔧 分布式预热比例: {args.warmup_ratio}")

    # 评估显存优化参数覆盖
    if args.per_device_eval_batch_size:
        params["eval_batch_size"] = args.per_device_eval_batch_size
        logger.info(f"🔧 评估批次大小: {args.per_device_eval_batch_size}")
    if args.eval_accumulation_steps:
        params["eval_accumulation_steps"] = args.eval_accumulation_steps
        logger.info(f"🔧 评估累积步数: {args.eval_accumulation_steps}")

    # 新增参数处理
    if args.weight_decay is not None:
        params["weight_decay"] = args.weight_decay
        logger.info(f"🔧 权重衰减: {args.weight_decay}")

    if args.max_grad_norm is not None:
        params["max_grad_norm"] = args.max_grad_norm
        logger.info(f"🔧 梯度裁剪: {args.max_grad_norm}")

    if args.lora_r is not None:
        params["lora_r"] = args.lora_r
        logger.info(f"🔧 LoRA rank: {args.lora_r}")

    if args.lora_alpha is not None:
        params["lora_alpha"] = args.lora_alpha
        logger.info(f"🔧 LoRA alpha: {args.lora_alpha}")

    # 其他训练参数
    params["lr_scheduler_type"] = args.lr_scheduler_type
    params["logging_steps"] = args.logging_steps
    params["save_steps"] = args.save_steps
    params["save_total_limit"] = args.save_total_limit

    # 第二轮训练参数处理
    if args.second_round_training:
        logger.info("🔄 启用第二轮迭代训练模式")
        params["second_round_training"] = True

        if args.first_lora_adapter_path:
            if not os.path.exists(args.first_lora_adapter_path):
                logger.error(f"❌ 第一轮LoRA适配器路径不存在: {args.first_lora_adapter_path}")
                sys.exit(1)

            # 验证必要文件
            required_files = ["adapter_config.json", "adapter_model.safetensors"]
            for file in required_files:
                file_path = os.path.join(args.first_lora_adapter_path, file)
                if not os.path.exists(file_path):
                    logger.error(f"❌ 缺少必要的LoRA文件: {file_path}")
                    sys.exit(1)

            params["first_lora_adapter_path"] = args.first_lora_adapter_path
            logger.info(f"✅ 第一轮LoRA适配器路径: {args.first_lora_adapter_path}")
        else:
            logger.error("❌ 第二轮训练模式需要指定 --first_lora_adapter_path 参数")
            sys.exit(1)

        if args.combine_loras:
            params["combine_loras"] = True
            logger.info("🔗 启用LoRA适配器组合模式")

    # 分布式训练设置 - 兼容新旧启动方式
    # 优先从环境变量读取（torchrun方式）
    local_rank = int(os.environ.get('LOCAL_RANK', -1))

    # 如果环境变量没有设置，则从命令行参数读取（旧方式）
    if local_rank == -1 and args.local_rank is not None:
        local_rank = args.local_rank
        logger.warning("⚠️ 使用已弃用的--local-rank参数，建议使用torchrun启动")

    # 如果仍然是-1，说明不是分布式训练
    if local_rank == -1:
        local_rank = 0

    if args.enable_distributed or local_rank > 0:
        logger.info(f"🚀 启用分布式训练，本地排名: {local_rank}")
        params["enable_distributed"] = True
        params["local_rank"] = local_rank

    # 通知配置
    email_config = None
    if args.email_to and args.smtp_user and args.smtp_pass:
        email_config = {
            "email_to": args.email_to,
            "smtp_host": "smtp.qiye.aliyun.com",
            "smtp_user": args.smtp_user,
            "smtp_pass": args.smtp_pass
        }
        logger.info("📧 邮件通知已启用")

    wechat_config = None
    if args.enable_wechat:
        wechat_config = {
            "enabled": True,
            "push_url": args.wechat_push_url,
            "timeout": 10
        }
        logger.info("📱 微信推送通知已启用")

    # SwanLab 配置
    swanlab_config = None
    if args.enable_swanlab and SWANLAB_AVAILABLE:
        # 生成实验名称
        if args.swanlab_experiment is None:
            timestamp = datetime.datetime.now().strftime("%m%d_%H%M")
            data_name = Path(args.data_path).stem
            mode_suffix = "_test" if args.test_mode else ""
            round_suffix = "_2nd" if args.second_round_training else "_1st"
            args.swanlab_experiment = f"qwen3-8b{round_suffix}_{data_name}_{timestamp}{mode_suffix}"

        swanlab_config = {
            "enabled": True,
            "project": args.swanlab_project,
            "experiment": args.swanlab_experiment,
            "description": args.swanlab_description,
            "tags": args.swanlab_tags,
            "api_key": args.swanlab_api_key if args.swanlab_api_key else None,
            "config": {
                "model_path": args.model_path,
                "data_path": args.data_path,
                "num_epochs": args.num_epochs,
                "test_mode": args.test_mode,
                "second_round_training": args.second_round_training,
                **params  # 包含所有训练参数
            }
        }
        logger.info(f"🦢 SwanLab 实验跟踪已启用")
        logger.info(f"   项目: {args.swanlab_project}")
        logger.info(f"   实验: {args.swanlab_experiment}")
    elif args.enable_swanlab and not SWANLAB_AVAILABLE:
        logger.warning("⚠️ SwanLab 未安装，无法启用实验跟踪")
        logger.info("💡 安装命令: pip install swanlab")

    # 阶段评估配置
    if args.enable_evaluation:
        logger.info("📊 阶段评估已启用")
        logger.info(f"   评估数据占比: {args.eval_split_ratio*100:.1f}%")
        logger.info(f"   评估间隔: 每 {args.eval_steps} 步")
    else:
        logger.info("📋 使用全部数据进行训练（未启用阶段评估）")

    # EarlyStopping配置
    early_stopping_config = None
    if args.enable_early_stopping:
        if not args.enable_evaluation:
            logger.warning("⚠️ EarlyStopping需要启用评估功能，自动启用评估")
            args.enable_evaluation = True
            args.eval_split_ratio = 0.1
            args.eval_steps = 100
            logger.info("📊 自动启用评估: 10%数据用于评估，每100步评估一次")

        early_stopping_config = {
            "enabled": True,
            "patience": args.early_stopping_patience,
            "min_delta": args.early_stopping_threshold,
            "metric_for_best_model": args.early_stopping_metric,
            "train_metric": args.early_stopping_train_metric,
            "eval_metric": args.early_stopping_eval_metric
        }

        if args.early_stopping_metric == "dual_loss":
            logger.info("🛑 双指标EarlyStopping已启用")
            logger.info(f"   训练指标: {args.early_stopping_train_metric}")
            logger.info(f"   评估指标: {args.early_stopping_eval_metric}")
            logger.info(f"   耐心值: {args.early_stopping_patience}")
            logger.info(f"   改善阈值: {args.early_stopping_threshold}")
            logger.info(f"   停止条件: 两个指标都无改善时增加耐心计数")
        else:
            early_stopping_config["greater_is_better"] = False if "loss" in args.early_stopping_metric.lower() else True
            logger.info("🛑 单指标EarlyStopping已启用")
            logger.info(f"   监控指标: {args.early_stopping_metric}")
            logger.info(f"   耐心值: {args.early_stopping_patience}")
            logger.info(f"   改善阈值: {args.early_stopping_threshold}")
    else:
        logger.info("⏳ EarlyStopping未启用，将训练完整的轮数")

    # 开始训练
    success = train_model(
        data=data,
        data_format=processor.data_format,
        model_path=args.model_path,
        output_dir=args.output_dir,
        num_epochs=args.num_epochs,
        params=params,
        email_config=email_config,
        wechat_config=wechat_config,
        swanlab_config=swanlab_config,
        test_mode=args.test_mode,
        enable_evaluation=args.enable_evaluation,
        eval_split_ratio=args.eval_split_ratio,
        eval_steps=args.eval_steps,
        early_stopping_config=early_stopping_config
    )

    if success:
        logger.info("🎉 训练完成！")
    else:
        logger.error("❌ 训练失败！")
        sys.exit(1)

def train_model(data, data_format, model_path, output_dir, num_epochs, params, email_config=None, wechat_config=None, swanlab_config=None, test_mode=False, enable_evaluation=False, eval_split_ratio=0.1, eval_steps=100, early_stopping_config=None):
    """执行模型训练"""
    # 提前定义 is_main_process 变量，避免异常处理中的引用错误
    is_main_process = not params.get("enable_distributed", False) or params.get("local_rank", 0) == 0

    try:
        start_time = time.time()
        # 根据训练轮次设置任务名称
        if params.get("second_round_training", False):
            task_name = f"第二轮训练-{datetime.datetime.now().strftime('%m%d_%H%M')}"
        else:
            task_name = f"首次训练-{datetime.datetime.now().strftime('%m%d_%H%M')}"

        # 设置CUDA内存优化环境变量
        os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
        logger.info("🔧 已设置CUDA内存优化: expandable_segments:True")

        # 初始化 SwanLab
        swanlab_run = None
        if swanlab_config and swanlab_config.get("enabled", False) and SWANLAB_AVAILABLE:
            try:
                # 设置 API Key（如果提供）
                if swanlab_config.get("api_key"):
                    os.environ["SWANLAB_API_KEY"] = swanlab_config["api_key"]
                    logger.info("🔑 SwanLab API Key 已设置")

                swanlab_run = swanlab.init(
                    project=swanlab_config["project"],
                    experiment_name=swanlab_config["experiment"],
                    description=swanlab_config["description"],
                    config=swanlab_config["config"],
                    tags=swanlab_config["tags"]
                )
                logger.info(f"🦢 SwanLab 实验已初始化: {swanlab_config['experiment']}")
            except Exception as e:
                logger.warning(f"⚠️ SwanLab 初始化失败: {str(e)}")
                logger.info("💡 请检查 API Key 或网络连接")
                swanlab_run = None

        # 初始化分布式训练
        if params.get("enable_distributed", False):
            logger.info("🚀 初始化分布式训练...")
            torch.distributed.init_process_group(backend="nccl")
            local_rank = params.get("local_rank", 0)
            torch.cuda.set_device(local_rank)
            logger.info(f"📍 当前进程本地排名: {local_rank}")
            # 重新计算 is_main_process（分布式环境下）
            is_main_process = local_rank == 0

        logger.info("🚀 开始模型训练...")
        logger.info(f"📊 训练参数: {params}")

        # 加载分词器
        logger.info(f"📝 加载分词器: {model_path}")
        tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True,
            local_files_only=True
        )

        # 配置量化
        bnb_config = BitsAndBytesConfig(
            load_in_8bit=params["use_8bit"],
            llm_int8_threshold=6.0,
            llm_int8_has_fp16_weight=False,
            bnb_8bit_compute_dtype=torch.bfloat16
        ) if params["use_8bit"] else None

        # 加载模型
        logger.info(f"🤖 加载模型: {model_path}")

        # 分布式训练时不使用device_map="auto"
        device_map = None if params.get("enable_distributed", False) else "auto"

        # 根据配置决定注意力机制实现
        if params.get("use_flash_attention", False):
            try:
                import flash_attn
                attn_implementation = "flash_attention_2"
                logger.info("⚡ Flash Attention 2 已启用")
            except ImportError:
                attn_implementation = "sdpa"  # 使用 PyTorch 内置的 SDPA
                logger.info("⚡ 使用 PyTorch 内置 SDPA (Scaled Dot Product Attention)，性能接近 Flash Attention")
        else:
            attn_implementation = "sdpa"  # 默认使用 SDPA，比 eager 更高效
            logger.info("⚡ 使用 PyTorch 内置 SDPA 优化")

        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            device_map=device_map,
            quantization_config=bnb_config,
            trust_remote_code=True,
            local_files_only=True,
            attn_implementation=attn_implementation
        )

        # 评估阶段显存优化：关闭 KV cache
        if hasattr(model, "config"):
            try:
                model.config.use_cache = False
                logger.info("🔧 已关闭 model.config.use_cache 以降低评估显存占用")
            except Exception:
                logger.warning("⚠️ 未能设置 model.config.use_cache=False，但不影响训练")

        # 准备QLoRA训练
        if params["use_8bit"]:
            model = prepare_model_for_kbit_training(model)

        # 第二轮训练：加载第一轮LoRA适配器
        if params.get("second_round_training", False):
            first_lora_path = params.get("first_lora_adapter_path")
            logger.info(f"🔄 第二轮训练模式：加载第一轮LoRA适配器")
            logger.info(f"📁 第一轮适配器路径: {first_lora_path}")

            try:
                # 加载第一轮的LoRA适配器
                model = PeftModel.from_pretrained(model, first_lora_path)
                logger.info("✅ 第一轮LoRA适配器加载成功")

                # 为第二轮训练创建新的LoRA配置
                target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
                second_lora_config = LoraConfig(
                    r=params["lora_r"],
                    lora_alpha=params["lora_alpha"],
                    target_modules=target_modules,
                    lora_dropout=0.1,
                    bias="none",
                    task_type="CAUSAL_LM"
                )

                # 添加新的LoRA适配器用于第二轮训练
                model.add_adapter("second_round", second_lora_config)
                model.set_adapter("second_round")
                logger.info("✅ 第二轮LoRA适配器配置完成")

            except Exception as e:
                logger.error(f"❌ 加载第一轮LoRA适配器失败: {str(e)}")
                raise e
        else:
            # 第一轮训练：标准LoRA配置
            target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
            lora_config = LoraConfig(
                r=params["lora_r"],
                lora_alpha=params["lora_alpha"],
                target_modules=target_modules,
                lora_dropout=0.1,
                bias="none",
                task_type="CAUSAL_LM"
            )

            model = get_peft_model(model, lora_config)
            logger.info("✅ 第一轮LoRA配置完成")

        # 分布式训练时将模型移动到正确的设备
        if params.get("enable_distributed", False):
            local_rank = params.get("local_rank", 0)
            model = model.to(f"cuda:{local_rank}")
            logger.info(f"📍 模型已移动到 cuda:{local_rank}")

        # 输出模型参数量
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        logger.info(f"📈 模型总参数: {total_params:,}")
        logger.info(f"🎯 可训练参数: {trainable_params:,} ({trainable_params/total_params:.2%})")

        # 准备数据集
        train_dataset, eval_dataset = prepare_dataset(
            data,
            data_format,
            tokenizer,
            params["max_length"],
            enable_evaluation=enable_evaluation,
            eval_split_ratio=eval_split_ratio
        )

        # 数据收集器
        data_collator = DataCollatorForSeq2Seq(
            tokenizer=tokenizer,
            padding=True,
            return_tensors="pt"
        )

        # 日志文件
        log_file = os.path.join(output_dir, "training_progress.log")

        # 确定报告目标
        report_to = "none"
        run_name = None
        if swanlab_run is not None:
            report_to = "swanlab"
            run_name = swanlab_config["experiment"]

        # 训练参数（支持动态配置）
        training_args = TrainingArguments(
            output_dir=output_dir,
            per_device_train_batch_size=params["batch_size"],
            gradient_accumulation_steps=params["gradient_accumulation_steps"],
            learning_rate=params["learning_rate"],
            num_train_epochs=num_epochs,
            weight_decay=params.get("weight_decay", 0.01),
            warmup_ratio=params.get("warmup_ratio", 0.1),
            lr_scheduler_type=params.get("lr_scheduler_type", "constant"),
            save_strategy="steps",
            save_steps=params.get("save_steps", 100),
            save_total_limit=params.get("save_total_limit", 3),
            eval_strategy="steps" if enable_evaluation and eval_dataset is not None else "no",
            eval_steps=eval_steps if enable_evaluation and eval_dataset is not None else None,
            per_device_eval_batch_size=params.get("eval_batch_size", max(1, params["batch_size"])),
            eval_accumulation_steps=params.get("eval_accumulation_steps", 8),
            bf16=True,
            fp16=False,
            logging_steps=params.get("logging_steps", 10),
            gradient_checkpointing=True,
            optim="adamw_torch",
            max_grad_norm=params.get("max_grad_norm", 0.3),
            report_to=report_to,  # SwanLab 集成
            run_name=run_name,    # 实验名称
            # 分布式训练参数
            ddp_find_unused_parameters=False,
            dataloader_pin_memory=False,
            local_rank=params.get("local_rank", -1) if params.get("enable_distributed", False) else -1
        )

        # 创建回调列表
        callbacks = []

        # 添加智能训练回调
        smart_callback = SmartTrainingCallback(
            log_file=log_file,
            email_config=email_config,
            wechat_config=wechat_config,
            task_name=task_name,
            is_main_process=is_main_process
        )
        callbacks.append(smart_callback)

        # 添加 SwanLab 回调（如果启用）
        if swanlab_run is not None and SWANLAB_AVAILABLE:
            try:
                swanlab_callback = SwanLabCallback()
                callbacks.append(swanlab_callback)
                logger.info("🦢 SwanLab 回调已添加")
            except Exception as e:
                logger.warning(f"⚠️ SwanLab 回调添加失败: {str(e)}")

        # 添加 EarlyStopping 回调（如果启用）
        if early_stopping_config and early_stopping_config.get("enabled", False):
            if eval_dataset is not None:
                try:
                    early_stopping_callback = EarlyStoppingCallback(
                        patience=early_stopping_config.get("patience", 3),
                        min_delta=early_stopping_config.get("min_delta", 0.001),
                        metric_for_best_model=early_stopping_config.get("metric_for_best_model", "dual_loss"),
                        train_metric=early_stopping_config.get("train_metric", "loss"),
                        eval_metric=early_stopping_config.get("eval_metric", "eval_loss"),
                        email_config=email_config,
                        wechat_config=wechat_config,
                        task_name=task_name,
                        is_main_process=is_main_process
                    )
                    callbacks.append(early_stopping_callback)
                    logger.info("🛑 EarlyStopping 回调已添加")
                except Exception as e:
                    logger.warning(f"⚠️ EarlyStopping 回调添加失败: {str(e)}")
            else:
                logger.warning("⚠️ 未启用评估，无法使用EarlyStopping")

        # 创建训练器
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset if enable_evaluation else None,
            data_collator=data_collator,
            tokenizer=tokenizer,
            callbacks=callbacks
        )

        # 计算训练信息
        total_batch_size = params["batch_size"] * params["gradient_accumulation_steps"]
        total_steps = math.ceil(len(train_dataset) / total_batch_size) * num_epochs

        logger.info(f"📊 训练信息:")
        logger.info(f"   训练数据量: {len(train_dataset)} 条")
        if eval_dataset is not None:
            logger.info(f"   评估数据量: {len(eval_dataset)} 条")
            logger.info(f"   评估间隔: 每 {eval_steps} 步")
        logger.info(f"   批次大小: {params['batch_size']}")
        logger.info(f"   梯度累积: {params['gradient_accumulation_steps']}")
        logger.info(f"   有效批次: {total_batch_size}")
        logger.info(f"   训练轮数: {num_epochs}")
        logger.info(f"   总步数: {total_steps}")

        # 发送开始通知（仅主进程发送）
        if is_main_process and email_config:
            send_start_notification(email_config, task_name, len(train_dataset), total_steps, test_mode, params.get("second_round_training", False))

        if is_main_process and wechat_config:
            send_wechat_start_notification(wechat_config, task_name, len(train_dataset), total_steps, test_mode, params.get("second_round_training", False), params.get("first_lora_adapter_path"))

        # 执行训练
        logger.info("🎯 开始训练...")
        trainer.train()

        # 保存模型
        logger.info("💾 保存模型...")
        trainer.save_model()
        tokenizer.save_pretrained(output_dir)

        # 计算训练时间
        end_time = time.time()
        elapsed_time = end_time - start_time
        hours = int(elapsed_time // 3600)
        minutes = int((elapsed_time % 3600) // 60)

        logger.info(f"⏱️  实际训练时间: {hours}小时{minutes}分钟")

        # 检查训练是否真正完成
        training_success = check_training_completion(output_dir)
        if training_success:
            if params.get("second_round_training", False):
                logger.info("✅ 第二轮迭代训练成功完成！")
                logger.info("🔄 第二轮训练特性:")
                logger.info(f"   - 基于第一轮适配器: {params.get('first_lora_adapter_path', 'N/A')}")
                logger.info("   - 使用精细化学习率和优化参数")
                logger.info("   - 在第一轮基础上进行增量学习")
            else:
                logger.info("✅ 第一轮基础训练成功完成！")

            logger.info("📋 模型合并说明:")
            logger.info("   由于分布式训练环境的限制，模型合并已分离为独立脚本")
            logger.info("   请使用以下命令进行模型合并:")
            logger.info(f"   python trainning/new/merge_lora_model.py --base_model_path {model_path} --lora_adapter_path {output_dir}")
            logger.info("   或者使用自动发现模式:")
            logger.info(f"   python trainning/new/merge_lora_model.py --base_model_path {model_path} --auto_discover")
        else:
            if params.get("second_round_training", False):
                logger.warning("⚠️ 第二轮训练可能未完全成功，请检查输出文件")
            else:
                logger.warning("⚠️ 第一轮训练可能未完全成功，请检查输出文件")

        # 发送完成通知（仅主进程发送）
        if is_main_process and email_config:
            send_completion_notification(email_config, task_name, output_dir, elapsed_time, params.get("second_round_training", False))

        if is_main_process and wechat_config:
            send_wechat_completion_notification(wechat_config, task_name, output_dir, elapsed_time, params.get("second_round_training", False), params.get("first_lora_adapter_path"))

        # 清理分布式训练
        if params.get("enable_distributed", False):
            torch.distributed.destroy_process_group()
            logger.info("🧹 分布式训练进程组已清理")

        # 完成 SwanLab 实验
        if swanlab_run is not None:
            try:
                swanlab.finish()
                logger.info("🦢 SwanLab 实验已完成")
            except Exception as e:
                logger.warning(f"⚠️ SwanLab 实验完成时出错: {str(e)}")

        return True

    except Exception as e:
        logger.error(f"❌ 训练过程中发生错误: {str(e)}")

        # 清理分布式训练（即使出错也要清理）
        if params.get("enable_distributed", False):
            try:
                torch.distributed.destroy_process_group()
                logger.info("🧹 分布式训练进程组已清理")
            except:
                pass

        # 发送错误通知（仅主进程发送）
        if is_main_process and email_config:
            send_error_notification(email_config, task_name, str(e))
        if is_main_process and wechat_config:
            send_wechat_error_notification(wechat_config, task_name, str(e))

        # 清理 SwanLab 实验（即使出错也要清理）
        if swanlab_run is not None:
            try:
                swanlab.finish()
                logger.info("🦢 SwanLab 实验已清理")
            except:
                pass

        return False

def split_dataset_for_evaluation(data, eval_split_ratio=0.1, random_seed=42):
    """分割数据集用于评估"""
    import random

    # 设置随机种子确保可重现
    random.seed(random_seed)

    # 随机打乱数据
    data_copy = data.copy()
    random.shuffle(data_copy)

    # 计算分割点
    total_size = len(data_copy)
    eval_size = int(total_size * eval_split_ratio)
    train_size = total_size - eval_size

    # 分割数据
    train_data = data_copy[:train_size]
    eval_data = data_copy[train_size:]

    logger.info(f"📊 数据集分割完成:")
    logger.info(f"   总数据量: {total_size}")
    logger.info(f"   训练数据: {train_size} ({(1-eval_split_ratio)*100:.1f}%)")
    logger.info(f"   评估数据: {eval_size} ({eval_split_ratio*100:.1f}%)")

    return train_data, eval_data

def prepare_dataset(data, data_format, tokenizer, max_length, enable_evaluation=False, eval_split_ratio=0.1):
    """准备训练数据集"""
    logger.info("📋 准备数据集...")

    # 如果启用评估，先分割数据
    if enable_evaluation:
        logger.info("🔄 启用阶段评估，正在分割数据集...")
        train_data, eval_data = split_dataset_for_evaluation(data, eval_split_ratio)
    else:
        train_data = data
        eval_data = None
        logger.info("📋 使用全部数据进行训练（未启用评估）")

    def process_data_to_dict(data_subset):
        """将数据转换为字典格式"""
        if data_format == "messages":
            # 处理messages格式（ChatML格式）
            prompts = []
            completions = []

            for item in data_subset:
                messages = item["messages"]
                # 找到user和assistant的消息
                user_content = ""
                assistant_content = ""

                for msg in messages:
                    if msg["role"] == "user":
                        user_content = msg["content"]
                    elif msg["role"] == "assistant":
                        assistant_content = msg["content"]

                if user_content and assistant_content:
                    prompts.append(user_content)
                    completions.append(assistant_content)

            return {
                "prompt": prompts,
                "completion": completions
            }
        elif data_format == "prompt-completion":
            return {
                "prompt": [item["prompt"] for item in data_subset],
                "completion": [item["completion"] for item in data_subset]
            }
        elif data_format == "instruction-output":
            return {
                "prompt": [item["instruction"] for item in data_subset],
                "completion": [item["output"] for item in data_subset]
            }
        elif data_format == "input-target":
            return {
                "prompt": [item["input"] for item in data_subset],
                "completion": [item["target"] for item in data_subset]
            }
        else:
            raise ValueError(f"不支持的数据格式: {data_format}")

    # 处理训练数据
    train_dataset_dict = process_data_to_dict(train_data)
    train_dataset = Dataset.from_dict(train_dataset_dict)

    # 处理评估数据（如果存在）
    eval_dataset = None
    if eval_data is not None:
        eval_dataset_dict = process_data_to_dict(eval_data)
        eval_dataset = Dataset.from_dict(eval_dataset_dict)

    def tokenize_function(examples):
        prompts = examples['prompt']
        completions = examples['completion']

        combined_texts = []
        for prompt, completion in zip(prompts, completions):
            combined_text = f"{prompt}{completion}"
            combined_texts.append(combined_text)

        tokenized = tokenizer(
            combined_texts,
            padding="max_length",
            max_length=max_length,
            truncation=True,
            return_tensors="pt"
        )

        # 准备标签
        labels = tokenized["input_ids"].clone()

        for i, (prompt, completion) in enumerate(zip(prompts, completions)):
            prompt_tokens = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)["input_ids"][0]
            prompt_len = len(prompt_tokens)

            if prompt_len < len(labels[i]):
                labels[i, :prompt_len] = -100

        tokenized["labels"] = labels
        return tokenized

    # 对训练数据进行tokenize
    tokenized_train_dataset = train_dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=["prompt", "completion"],
        num_proc=4
    )

    # 对评估数据进行tokenize（如果存在）
    tokenized_eval_dataset = None
    if eval_dataset is not None:
        logger.info("🔄 正在处理评估数据集...")
        tokenized_eval_dataset = eval_dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=["prompt", "completion"],
            num_proc=4
        )
        logger.info(f"✅ 评估数据集处理完成，样本数: {len(tokenized_eval_dataset)}")

    logger.info(f"✅ 训练数据集处理完成，样本数: {len(tokenized_train_dataset)}")

    if tokenized_eval_dataset is not None:
        return tokenized_train_dataset, tokenized_eval_dataset
    else:
        return tokenized_train_dataset, None

def send_start_notification(email_config, task_name, data_count, total_steps, test_mode, is_second_round=False):
    """发送训练开始通知"""
    try:
        if is_second_round:
            subject = f"🔄 {task_name} - 第二轮训练开始"
            content = f"""
智能自适应第二轮迭代训练已启动 🔄

任务名称: {task_name}
数据条数: {data_count}{'（测试模式）' if test_mode else ''}
总训练步数: {total_steps}
开始时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
训练类型: 第二轮迭代训练（基于第一轮结果）

训练正在进行中，将定期发送进度更新... 📊
"""
        else:
            subject = f"🚀 {task_name} - 训练开始"
            content = f"""
智能自适应首次训练已启动 🎯

任务名称: {task_name}
数据条数: {data_count}{'（测试模式）' if test_mode else ''}
总训练步数: {total_steps}
开始时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

训练正在进行中，将定期发送进度更新... 📊
"""

        message = MIMEMultipart()
        message['From'] = email_config["smtp_user"]
        message['To'] = email_config["email_to"]
        message['Subject'] = Header(subject, 'utf-8')
        message.attach(MIMEText(content, 'plain', 'utf-8'))

        smtp_obj = smtplib.SMTP_SSL(email_config["smtp_host"])
        smtp_obj.connect(email_config["smtp_host"], 465)
        smtp_obj.login(email_config["smtp_user"], email_config["smtp_pass"])
        smtp_obj.sendmail(email_config["smtp_user"], [email_config["email_to"]], message.as_string())
        smtp_obj.quit()

        logger.info("📧 开始通知邮件已发送")
    except Exception as e:
        logger.warning(f"邮件发送失败: {str(e)}")

def send_completion_notification(email_config, task_name, output_dir, elapsed_time, is_second_round=False):
    """发送训练完成通知"""
    try:
        hours = int(elapsed_time // 3600)
        minutes = int((elapsed_time % 3600) // 60)

        if is_second_round:
            subject = f"🎉 {task_name} - 第二轮训练完成"
            content = f"""
智能自适应第二轮迭代训练已完成 ✅

任务名称: {task_name}
完成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
训练耗时: {hours}小时{minutes}分钟
模型保存位置: {output_dir}
训练类型: 第二轮迭代训练

恭喜！您的第二轮迭代训练已成功完成 🎊
"""
        else:
            subject = f"🎉 {task_name} - 训练完成"
            content = f"""
智能自适应首次训练已完成 ✅

任务名称: {task_name}
完成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
训练耗时: {hours}小时{minutes}分钟
模型保存位置: {output_dir}

恭喜！您的模型训练已成功完成 🎊
"""

        message = MIMEMultipart()
        message['From'] = email_config["smtp_user"]
        message['To'] = email_config["email_to"]
        message['Subject'] = Header(subject, 'utf-8')
        message.attach(MIMEText(content, 'plain', 'utf-8'))

        smtp_obj = smtplib.SMTP_SSL(email_config["smtp_host"])
        smtp_obj.connect(email_config["smtp_host"], 465)
        smtp_obj.login(email_config["smtp_user"], email_config["smtp_pass"])
        smtp_obj.sendmail(email_config["smtp_user"], [email_config["email_to"]], message.as_string())
        smtp_obj.quit()

        logger.info("📧 完成通知邮件已发送")
    except Exception as e:
        logger.warning(f"邮件发送失败: {str(e)}")

def send_error_notification(email_config, task_name, error_msg):
    """发送错误通知"""
    try:
        subject = f"❌ {task_name} - 训练失败"
        content = f"""
智能自适应首次训练遇到错误 ⚠️

任务名称: {task_name}
错误时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
错误信息: {error_msg}

请检查日志文件获取详细信息。
"""

        message = MIMEMultipart()
        message['From'] = email_config["smtp_user"]
        message['To'] = email_config["email_to"]
        message['Subject'] = Header(subject, 'utf-8')
        message.attach(MIMEText(content, 'plain', 'utf-8'))

        smtp_obj = smtplib.SMTP_SSL(email_config["smtp_host"])
        smtp_obj.connect(email_config["smtp_host"], 465)
        smtp_obj.login(email_config["smtp_user"], email_config["smtp_pass"])
        smtp_obj.sendmail(email_config["smtp_user"], [email_config["email_to"]], message.as_string())
        smtp_obj.quit()

        logger.info("📧 错误通知邮件已发送")
    except Exception as e:
        logger.warning(f"邮件发送失败: {str(e)}")

def send_wechat_start_notification(wechat_config, task_name, data_count, total_steps, test_mode, is_second_round=False, first_lora_path=None):
    """发送微信训练开始通知"""
    try:
        notifier = WeChatNotifier(**wechat_config)

        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        task_id = f"train_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

        if is_second_round:
            title = f"🔄 {task_name} - 第二轮训练开始"
            task_info = f"数据条数: {data_count}{'（测试模式）' if test_mode else ''}"
            status = "第二轮训练启动"
            result = f"总训练步数: {total_steps}"
            time_info = f"开始时间: {current_time}"
            if first_lora_path:
                details = f"第二轮迭代训练已启动，基于第一轮适配器: {os.path.basename(first_lora_path)}"
            else:
                details = "第二轮迭代训练已启动，将定期发送进度更新"
        else:
            title = f"🚀 {task_name} - 训练开始"
            task_info = f"数据条数: {data_count}{'（测试模式）' if test_mode else ''}"
            status = "训练启动"
            result = f"总训练步数: {total_steps}"
            time_info = f"开始时间: {current_time}"
            details = "智能自适应首次训练已启动，将定期发送进度更新"

        success = notifier.send_notification(
            notification_type="ai_task_unified",
            title=title,
            task_info=task_info,
            status=status,
            result=result,
            time_info=time_info,
            details=details,
            task_id=task_id
        )

        if success:
            logger.info("📱 微信训练开始通知已发送")
        else:
            logger.warning("📱 微信训练开始通知发送失败")

    except Exception as e:
        logger.warning(f"微信训练开始通知发送异常: {str(e)}")

def send_wechat_completion_notification(wechat_config, task_name, output_dir, elapsed_time, is_second_round=False, first_lora_path=None):
    """发送微信训练完成通知"""
    try:
        notifier = WeChatNotifier(**wechat_config)

        hours = int(elapsed_time // 3600)
        minutes = int((elapsed_time % 3600) // 60)
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        task_id = f"train_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

        if is_second_round:
            title = f"🎉 {task_name} - 第二轮训练完成"
            task_info = f"任务名称: {task_name}"
            status = "第二轮训练完成"
            result = f"模型保存位置: {output_dir}"
            time_info = f"完成时间: {current_time} | 训练耗时: {hours}小时{minutes}分钟"
            if first_lora_path:
                details = f"恭喜！第二轮迭代训练已成功完成，基于: {os.path.basename(first_lora_path)}"
            else:
                details = "恭喜！您的第二轮迭代训练已成功完成"
        else:
            title = f"🎉 {task_name} - 训练完成"
            task_info = f"任务名称: {task_name}"
            status = "训练完成"
            result = f"模型保存位置: {output_dir}"
            time_info = f"完成时间: {current_time} | 训练耗时: {hours}小时{minutes}分钟"
            details = "恭喜！您的智能自适应首次训练已成功完成"

        success = notifier.send_notification(
            notification_type="complete",
            title=title,
            task_info=task_info,
            status=status,
            result=result,
            time_info=time_info,
            details=details,
            task_id=task_id
        )

        if success:
            logger.info("📱 微信训练完成通知已发送")
        else:
            logger.warning("📱 微信训练完成通知发送失败")

    except Exception as e:
        logger.warning(f"微信训练完成通知发送异常: {str(e)}")

def send_wechat_error_notification(wechat_config, task_name, error_msg):
    """发送微信训练错误通知"""
    try:
        notifier = WeChatNotifier(**wechat_config)

        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        task_id = f"train_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

        title = f"❌ {task_name} - 训练失败"
        task_info = f"任务名称: {task_name}"
        status = "训练失败"
        result = f"错误信息: {error_msg}"
        time_info = f"错误时间: {current_time}"
        details = "智能自适应首次训练遇到错误，请检查日志文件获取详细信息"

        success = notifier.send_notification(
            notification_type="error",
            title=title,
            task_info=task_info,
            status=status,
            result=result,
            time_info=time_info,
            details=details,
            task_id=task_id
        )

        if success:
            logger.info("📱 微信训练错误通知已发送")
        else:
            logger.warning("📱 微信训练错误通知发送失败")

    except Exception as e:
        logger.warning(f"微信训练错误通知发送异常: {str(e)}")

def check_training_completion(output_dir):
    """检查训练是否真正完成"""
    try:
        # 检查必要的文件是否存在
        required_files = [
            "adapter_config.json",
            "adapter_model.safetensors",
            "tokenizer.json",
            "tokenizer_config.json"
        ]

        for file_name in required_files:
            file_path = os.path.join(output_dir, file_name)
            if not os.path.exists(file_path):
                logger.warning(f"⚠️ 缺少必要文件: {file_name}")
                return False

        # 检查adapter_model.safetensors文件大小
        adapter_model_path = os.path.join(output_dir, "adapter_model.safetensors")
        if os.path.getsize(adapter_model_path) < 1024:  # 小于1KB可能有问题
            logger.warning("⚠️ adapter_model.safetensors文件过小，可能训练未完成")
            return False

        logger.info("✅ 训练完成检查通过")
        return True

    except Exception as e:
        logger.error(f"❌ 检查训练完成状态失败: {str(e)}")
        return False





if __name__ == "__main__":
    main()
