#!/usr/bin/env python3
"""
ERD自监督学习模型训练示例

使用示例:
python examples/train_model.py --erd_file data/erd/sample_erd.json --config config/qwen_3b_config.yaml
"""

import argparse
import json
import os
import sys
from pathlib import Path

# 添加src目录到路径
sys.path.append(str(Path(__file__).parent.parent / "src"))

from data.erd_parser import ERDParser
from data.data_generator import TrainingDataGenerator
from training.trainer import ERDTrainer


def main():
    parser = argparse.ArgumentParser(description="训练ERD自监督学习模型")
    parser.add_argument("--erd_file", type=str, required=True, help="ERD文件路径")
    parser.add_argument("--config", type=str, default="config/qwen_3b_config.yaml", help="配置文件路径")
    parser.add_argument("--output_dir", type=str, default="data/generated", help="输出目录")
    parser.add_argument("--max_samples", type=int, default=5000, help="最大样本数")
    
    args = parser.parse_args()
    
    print("🚀 开始ERD自监督学习模型训练")
    print(f"ERD文件: {args.erd_file}")
    print(f"配置文件: {args.config}")
    print(f"最大样本数: {args.max_samples}")
    
    # 1. 解析ERD
    print("\n📊 解析ERD文件...")
    erd_parser = ERDParser()
    erd_parser.parse_json(args.erd_file)
    
    stats = erd_parser.get_statistics()
    print(f"  - 表数量: {stats['total_tables']}")
    print(f"  - 字段数量: {stats['total_fields']}")
    print(f"  - 关系数量: {stats['total_relationships']}")
    print(f"  - 平均字段/表: {stats['avg_fields_per_table']:.1f}")
    
    # 2. 生成训练数据
    print("\n🔄 生成训练数据...")
    data_generator = TrainingDataGenerator(erd_parser)
    training_samples = data_generator.generate_all_samples(args.max_samples)
    
    print(f"  - 生成样本数: {len(training_samples)}")
    
    # 统计样本类型
    task_counts = {}
    for sample in training_samples:
        task_type = sample['task_type']
        task_counts[task_type] = task_counts.get(task_type, 0) + 1
    
    print("  - 样本分布:")
    for task_type, count in task_counts.items():
        print(f"    * {task_type}: {count}")
    
    # 3. 保存训练数据
    os.makedirs(args.output_dir, exist_ok=True)
    training_data_path = os.path.join(args.output_dir, "training_data.json")
    
    with open(training_data_path, 'w', encoding='utf-8') as f:
        json.dump(training_samples, f, ensure_ascii=False, indent=2)
    
    print(f"  - 训练数据已保存: {training_data_path}")
    
    # 4. 划分训练集和验证集
    split_idx = int(len(training_samples) * 0.8)
    train_data = training_samples[:split_idx]
    val_data = training_samples[split_idx:]
    
    print(f"  - 训练集: {len(train_data)} 样本")
    print(f"  - 验证集: {len(val_data)} 样本")
    
    # 5. 初始化训练器
    print("\n🧠 初始化模型训练器...")
    trainer = ERDTrainer(args.config)
    
    # 6. 加载模型
    print("📥 加载模型和分词器...")
    trainer.load_model_and_tokenizer()
    
    try:
        # 7. 开始训练
        print("\n🏋️ 开始训练...")
        trainer.train(train_data, val_data)

        # 8. 评估模型
        print("\n📈 评估模型...")
        eval_results = trainer.evaluate(val_data)

        # 9. 保存评估结果
        results_path = os.path.join(args.output_dir, "evaluation_results.json")
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(eval_results, f, ensure_ascii=False, indent=2)

        print(f"  - 评估结果已保存: {results_path}")

        print("\n✅ 训练完成！")
        print(f"模型保存位置: {trainer.config['output']['output_dir']}")

    except Exception as e:
        print(f"\n❌ 训练过程中出现错误: {e}")
        print("正在清理资源...")

    finally:
        # 确保SwanLab实验正确结束
        trainer.cleanup()


if __name__ == "__main__":
    main()
