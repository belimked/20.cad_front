#!/bin/bash

# RTX 4090双卡分布式训练启动脚本
# 基于实际生产经验优化，使用新版torchrun
# 作者：Claude 4.0 sonnet
# 版本：v2.0 - 兼容PyTorch新版分布式训练

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
}

# 显示帮助信息
show_help() {
    cat << EOF
🚀 RTX 4090双卡分布式训练脚本 (使用torchrun)

用法:
    $0 <数据文件路径> [选项]
    $0 --data_path <数据文件路径> [选项]

必需参数:
    数据文件路径        训练数据文件 (JSON或JSONL格式)
    --data_path PATH    训练数据文件路径 (与位置参数二选一)

基础训练参数:
    --model-path PATH   模型路径 (默认: /root/lanyun-tmp/modelscope_cache/qwen/Qwen3-8B)
    --output-dir PATH   输出目录 (默认: ./outputs/distributed_training_YYYYMMDD_HHMM)
    --epochs NUM        训练轮数 (默认: 1)
    --batch-size NUM    每卡批次大小 (默认: 16)
    --learning-rate LR  学习率 (默认: 1.5e-6)
    --master-port PORT  分布式通信端口 (默认: 29600)

高级训练参数:
    --gradient-accumulation-steps NUM   梯度累积步数 (默认: 4)
    --warmup-ratio RATIO               预热比例 (默认: 0.3)
    --weight-decay DECAY               权重衰减 (默认: 0.0)
    --max-grad-norm NORM               梯度裁剪阈值 (默认: 1.0)
    --lr-scheduler-type TYPE           学习率调度器 (默认: cosine)
    --save-steps NUM                   保存检查点步数 (默认: 50)
    --logging-steps NUM                日志记录步数 (默认: 20)
    --save-total-limit NUM             保存检查点数量限制 (默认: 3)

LoRA配置参数:
    --lora-r NUM                       LoRA rank (默认: 16)
    --lora-alpha NUM                   LoRA alpha (默认: 16)

第二轮迭代训练参数:
    --second-round              启用第二轮迭代训练模式
    --first-lora-path PATH      指定第一轮LoRA适配器路径
    --auto-discover-lora        自动发现最新的第一轮训练结果
    --combine-loras             组合第一轮和第二轮LoRA适配器
    --second-round-lr RATE      第二轮训练专用学习率 (默认: 5e-6)

运行控制参数:
    --test-mode         测试模式，只使用10%数据
    --enable-wechat     启用微信推送通知
    --skip-gpu-check    跳过GPU进程检查
    --background        后台运行训练
    --log-file PATH     指定日志文件路径 (默认: ./logs/training_YYYYMMDD_HHMM.log)
    --help, -h          显示此帮助信息

SwanLab实验跟踪参数:
    --enable-swanlab            启用SwanLab实验跟踪
    --swanlab-project NAME      SwanLab项目名称 (默认: qwen3-8b-distributed)
    --swanlab-experiment NAME   SwanLab实验名称 (默认: 自动生成)
    --swanlab-description TEXT  SwanLab实验描述
    --swanlab-tags TAG1 TAG2    SwanLab实验标签
    --swanlab-api-key KEY       SwanLab API Key (可选)

阶段评估参数:
    --enable-evaluation         启用阶段评估 (自动分割数据集)
    --eval-split-ratio RATIO    评估数据占比 (默认: 0.1, 即10%)
    --eval-steps STEPS          评估间隔步数 (默认: 100)
    --per-device-eval-batch-size NUM  评估批次大小（不设置则默认等于训练批次；建议从1起步）
    --eval-accumulation-steps NUM     评估累积步数（默认由训练脚本设为8，降低显存峰值）

EarlyStopping参数:
    --enable-early-stopping     启用EarlyStopping (基于评估指标自动停止训练)
    --early-stopping-patience NUM    EarlyStopping耐心值 (默认: 3)
    --early-stopping-threshold NUM   EarlyStopping改善阈值 (默认: 0.001)
    --early-stopping-metric METRIC   EarlyStopping监控指标 (默认: dual_loss)
    --early-stopping-train-metric METRIC  双指标模式训练指标 (默认: loss)
    --early-stopping-eval-metric METRIC   双指标模式评估指标 (默认: eval_loss)

示例:
    # 第一轮基础训练（位置参数）
    $0 data/your_data.jsonl

    # 第一轮基础训练（命名参数）
    $0 --data_path data/your_data.jsonl

    # 自定义参数的第一轮训练
    $0 data/your_data.jsonl --epochs 3 --batch-size 12 --learning-rate 2e-6
    $0 --data_path data/your_data.jsonl --epochs 3 --batch-size 12 --learning-rate 2e-6

    # 第二轮迭代训练 - 自动发现第一轮结果
    $0 data/your_data.jsonl --second-round --auto-discover-lora

    # 第二轮迭代训练 - 指定第一轮适配器路径
    $0 data/your_data.jsonl --second-round --first-lora-path ./outputs/first_training_20241201_1430

    # 第二轮训练 - 组合LoRA适配器
    $0 data/your_data.jsonl --second-round --combine-loras --second-round-lr 3e-6

    # 测试模式
    $0 data/your_data.jsonl --test-mode --enable-wechat

    # 后台运行
    $0 data/your_data.jsonl --background --enable-wechat

    # 启用SwanLab跟踪
    $0 data/your_data.jsonl --enable-swanlab --swanlab-project "my-qwen3-project"

    # 完整SwanLab配置
    $0 data/your_data.jsonl --enable-swanlab --swanlab-project "qwen3-experiments" \
       --swanlab-experiment "distributed-v1" --swanlab-description "分布式训练实验" \
       --swanlab-tags "distributed" "qwen3" "production"

    # 启用阶段评估
    $0 data/your_data.jsonl --enable-evaluation

    # 自定义评估配置
    $0 data/your_data.jsonl --enable-evaluation --eval-split-ratio 0.15 --eval-steps 50

    # 评估 + SwanLab 完整配置
    $0 data/your_data.jsonl --enable-evaluation --eval-split-ratio 0.1 --eval-steps 100 \
       --enable-swanlab --swanlab-project "qwen3-eval-experiments"

    # 启用双指标EarlyStopping
    $0 data/your_data.jsonl --enable-evaluation --enable-early-stopping

    # 自定义EarlyStopping配置
    $0 data/your_data.jsonl --enable-evaluation --enable-early-stopping \
       --early-stopping-patience 5 --early-stopping-threshold 0.0001

    # 单指标EarlyStopping模式
    $0 data/your_data.jsonl --enable-evaluation --enable-early-stopping \
       --early-stopping-metric eval_loss

    # 完整配置：评估 + 双指标EarlyStopping + SwanLab
    $0 data/your_data.jsonl --enable-evaluation --eval-split-ratio 0.1 --eval-steps 100 \
       --enable-early-stopping --early-stopping-patience 3 \
       --enable-swanlab --swanlab-project "qwen3-smart-training"

EOF
}

# 检查GPU数量
check_gpu_count() {
    local gpu_count
    gpu_count=$(/root/miniconda/bin/python -c "import torch; print(torch.cuda.device_count())" 2>/dev/null || echo "0")

    if [ "$gpu_count" -lt 2 ]; then
        print_error "检测到GPU数量: $gpu_count"
        print_error "分布式训练需要至少2块GPU"
        exit 1
    fi

    print_success "检测到GPU数量: $gpu_count"

    # 检查GPU类型
    local gpu_name
    gpu_name=$(/root/miniconda/bin/python -c "import torch; print(torch.cuda.get_device_name(0))" 2>/dev/null || echo "Unknown")
    print_info "GPU类型: $gpu_name"

    if [[ "$gpu_name" == *"4090"* ]]; then
        print_success "检测到RTX 4090，将使用优化配置"
    else
        print_warning "未检测到RTX 4090，将使用通用配置"
    fi
}

# 检查端口是否可用
check_port() {
    local port=$1
    if netstat -tuln 2>/dev/null | grep -q ":$port " || lsof -i :$port >/dev/null 2>&1; then
        print_error "端口 $port 已被占用"
        print_info "请使用 --master-port 指定其他端口"
        exit 1
    fi
    print_success "端口 $port 可用"
}

# 自动发现第一轮LoRA适配器
discover_first_lora() {
    print_info "🔍 自动搜索最新的第一轮训练LoRA适配器..."

    # 搜索路径列表
    local search_paths=(
        "./outputs"
        "trainning/new/outputs"
        "/root/lanyun-tmp/train/new/outputs"
    )

    local valid_lora_dirs=()

    # 在所有搜索路径中查找有效的LoRA适配器
    for search_path in "${search_paths[@]}"; do
        if [ -d "$search_path" ]; then
            while IFS= read -r -d '' dir; do
                local basename_dir=$(basename "$dir")
                # 排除second_开头的目录
                if [[ ! "$basename_dir" =~ ^second_ ]]; then
                    # 检查是否包含必要的LoRA文件
                    if [ -f "$dir/adapter_config.json" ] && [ -f "$dir/adapter_model.safetensors" ]; then
                        # 检查文件大小，避免选择损坏的文件
                        local adapter_size=$(stat -c%s "$dir/adapter_model.safetensors" 2>/dev/null || stat -f%z "$dir/adapter_model.safetensors" 2>/dev/null || echo 0)
                        if [ "$adapter_size" -gt 1000000 ]; then  # 至少1MB
                            valid_lora_dirs+=("$dir")
                        fi
                    fi
                fi
            done < <(find "$search_path" -maxdepth 1 -type d -print0 2>/dev/null)
        fi
    done

    if [ ${#valid_lora_dirs[@]} -eq 0 ]; then
        print_error "❌ 未找到有效的第一轮训练LoRA适配器"
        print_info "请确保以下文件存在："
        print_info "  - adapter_config.json"
        print_info "  - adapter_model.safetensors (大小 > 1MB)"
        print_info "搜索路径: ${search_paths[*]}"
        return 1
    fi

    # 按修改时间排序，选择最新的
    local latest_lora=""
    local latest_time=0

    for dir in "${valid_lora_dirs[@]}"; do
        if [ -d "$dir" ]; then
            local dir_time=$(stat -c %Y "$dir" 2>/dev/null || stat -f %m "$dir" 2>/dev/null || echo 0)
            if [ "$dir_time" -gt "$latest_time" ]; then
                latest_time=$dir_time
                latest_lora="$dir"
            fi
        fi
    done

    if [ -z "$latest_lora" ]; then
        print_error "❌ 无法确定最新的LoRA适配器"
        return 1
    fi

    FIRST_LORA_PATH="$latest_lora"

    # 显示发现的适配器信息
    print_success "✅ 自动发现最新LoRA适配器: $FIRST_LORA_PATH"
    print_info "📅 修改时间: $(date -d @$latest_time 2>/dev/null || date -r $latest_time 2>/dev/null || echo '未知')"

    # 如果有多个适配器，显示所有选项
    if [ ${#valid_lora_dirs[@]} -gt 1 ]; then
        print_info "📋 发现的所有LoRA适配器:"
        for dir in "${valid_lora_dirs[@]}"; do
            local dir_time=$(stat -c %Y "$dir" 2>/dev/null || stat -f %m "$dir" 2>/dev/null || echo 0)
            local time_str=$(date -d @$dir_time 2>/dev/null || date -r $dir_time 2>/dev/null || echo '未知时间')
            if [ "$dir" = "$FIRST_LORA_PATH" ]; then
                print_info "  ✓ $dir ($time_str) [已选择]"
            else
                print_info "    $dir ($time_str)"
            fi
        done
    fi

    return 0
}

# 解析参数
DATA_PATH=""
MODEL_PATH="/root/lanyun-tmp/modelscope_cache/qwen/Qwen3-8B"
OUTPUT_DIR=""
EPOCHS=2
BATCH_SIZE=16
LEARNING_RATE=4e-6
MASTER_PORT=29600
TEST_MODE=false
ENABLE_WECHAT=false
SKIP_GPU_CHECK=false
BACKGROUND=false
LOG_FILE=""

# 高级训练参数
GRADIENT_ACCUMULATION_STEPS=4
WARMUP_RATIO=0.15
WEIGHT_DECAY=0.01
MAX_GRAD_NORM=0.5
LR_SCHEDULER_TYPE="cosine"
SAVE_STEPS=50
LOGGING_STEPS=20
SAVE_TOTAL_LIMIT=3

# LoRA配置参数
LORA_R=16
LORA_ALPHA=16

# 第二轮训练参数
SECOND_ROUND=false
FIRST_LORA_PATH=""
AUTO_DISCOVER_LORA=false
COMBINE_LORAS=false
SECOND_ROUND_LR="5e-6"

# SwanLab参数
ENABLE_SWANLAB=false
SWANLAB_PROJECT="qwen3-8b-distributed"
SWANLAB_EXPERIMENT=""
SWANLAB_DESCRIPTION=""
SWANLAB_TAGS=""
SWANLAB_API_KEY=""

# 阶段评估参数
ENABLE_EVALUATION=false
EVAL_SPLIT_RATIO="0.1"
EVAL_STEPS="100"
PER_DEVICE_EVAL_BATCH_SIZE=""
EVAL_ACCUMULATION_STEPS=""

# EarlyStopping参数
ENABLE_EARLY_STOPPING=false
EARLY_STOPPING_PATIENCE="3"
EARLY_STOPPING_THRESHOLD="0.01"
EARLY_STOPPING_METRIC="dual_loss"
EARLY_STOPPING_TRAIN_METRIC="loss"
EARLY_STOPPING_EVAL_METRIC="eval_loss"

while [[ $# -gt 0 ]]; do
    case $1 in
        --help|-h)
            show_help
            exit 0
            ;;
        --model-path)
            MODEL_PATH="$2"
            shift 2
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --epochs)
            EPOCHS="$2"
            shift 2
            ;;
        --batch-size)
            BATCH_SIZE="$2"
            shift 2
            ;;
        --learning-rate)
            LEARNING_RATE="$2"
            shift 2
            ;;
        --master-port)
            MASTER_PORT="$2"
            shift 2
            ;;
        --gradient-accumulation-steps)
            GRADIENT_ACCUMULATION_STEPS="$2"
            shift 2
            ;;
        --warmup-ratio)
            WARMUP_RATIO="$2"
            shift 2
            ;;
        --weight-decay)
            WEIGHT_DECAY="$2"
            shift 2
            ;;
        --max-grad-norm)
            MAX_GRAD_NORM="$2"
            shift 2
            ;;
        --lr-scheduler-type)
            LR_SCHEDULER_TYPE="$2"
            shift 2
            ;;
        --save-steps)
            SAVE_STEPS="$2"
            shift 2
            ;;
        --logging-steps)
            LOGGING_STEPS="$2"
            shift 2
            ;;
        --save-total-limit)
            SAVE_TOTAL_LIMIT="$2"
            shift 2
            ;;
        --lora-r)
            LORA_R="$2"
            shift 2
            ;;
        --lora-alpha)
            LORA_ALPHA="$2"
            shift 2
            ;;
        --test-mode)
            TEST_MODE=true
            shift
            ;;
        --enable-wechat)
            ENABLE_WECHAT=true
            shift
            ;;
        --skip-gpu-check)
            SKIP_GPU_CHECK=true
            shift
            ;;
        --background)
            BACKGROUND=true
            shift
            ;;
        --log-file)
            LOG_FILE="$2"
            shift 2
            ;;
        --second-round)
            SECOND_ROUND=true
            shift
            ;;
        --first-lora-path)
            FIRST_LORA_PATH="$2"
            shift 2
            ;;
        --auto-discover-lora)
            AUTO_DISCOVER_LORA=true
            shift
            ;;
        --combine-loras)
            COMBINE_LORAS=true
            shift
            ;;
        --second-round-lr)
            SECOND_ROUND_LR="$2"
            shift 2
            ;;
        --enable-swanlab)
            ENABLE_SWANLAB=true
            shift
            ;;
        --swanlab-project)
            SWANLAB_PROJECT="$2"
            shift 2
            ;;
        --swanlab-experiment)
            SWANLAB_EXPERIMENT="$2"
            shift 2
            ;;
        --swanlab-description)
            SWANLAB_DESCRIPTION="$2"
            shift 2
            ;;
        --swanlab-tags)
            # 收集所有标签直到下一个选项
            SWANLAB_TAGS=""
            shift
            while [[ $# -gt 0 && ! "$1" =~ ^-- ]]; do
                if [ -z "$SWANLAB_TAGS" ]; then
                    SWANLAB_TAGS="$1"
                else
                    SWANLAB_TAGS="$SWANLAB_TAGS $1"
                fi
                shift
            done
            ;;
        --swanlab-api-key)
            SWANLAB_API_KEY="$2"
            shift 2
            ;;
        --enable-evaluation)
            ENABLE_EVALUATION=true
            shift
            ;;
        --eval-split-ratio)
            EVAL_SPLIT_RATIO="$2"
            shift 2
            ;;
        --eval-steps)
            EVAL_STEPS="$2"
            shift 2
            ;;
        --per-device-eval-batch-size)
            PER_DEVICE_EVAL_BATCH_SIZE="$2"
            shift 2
            ;;
        --eval-accumulation-steps)
            EVAL_ACCUMULATION_STEPS="$2"
            shift 2
            ;;
        --enable-early-stopping)
            ENABLE_EARLY_STOPPING=true
            shift
            ;;
        --early-stopping-patience)
            EARLY_STOPPING_PATIENCE="$2"
            shift 2
            ;;
        --early-stopping-threshold)
            EARLY_STOPPING_THRESHOLD="$2"
            shift 2
            ;;
        --early-stopping-metric)
            EARLY_STOPPING_METRIC="$2"
            shift 2
            ;;
        --early-stopping-train-metric)
            EARLY_STOPPING_TRAIN_METRIC="$2"
            shift 2
            ;;
        --early-stopping-eval-metric)
            EARLY_STOPPING_EVAL_METRIC="$2"
            shift 2
            ;;
        --data_path)
            DATA_PATH="$2"
            shift 2
            ;;
        -*)
            print_error "未知选项: $1"
            show_help
            exit 1
            ;;
        *)
            if [ -z "$DATA_PATH" ]; then
                DATA_PATH="$1"
            else
                print_error "多余的参数: $1"
                exit 1
            fi
            shift
            ;;
    esac
done

# 验证必需参数
if [ -z "$DATA_PATH" ]; then
    print_error "缺少数据文件路径"
    show_help
    exit 1
fi

if [ ! -f "$DATA_PATH" ]; then
    print_error "数据文件不存在: $DATA_PATH"
    exit 1
fi

# 第二轮训练验证逻辑
if [ "$SECOND_ROUND" = true ]; then
    print_info "🔄 启用第二轮迭代训练模式"

    # 处理第一轮LoRA适配器路径
    if [ -z "$FIRST_LORA_PATH" ] && [ "$AUTO_DISCOVER_LORA" = false ]; then
        print_info "未指定第一轮LoRA适配器路径，启用自动发现..."
        AUTO_DISCOVER_LORA=true
    fi

    if [ "$AUTO_DISCOVER_LORA" = true ]; then
        if ! discover_first_lora; then
            print_error "自动发现第一轮LoRA适配器失败"
            print_info "请使用 --first-lora-path 手动指定路径"
            exit 1
        fi
    fi

    # 验证第一轮LoRA适配器路径
    if [ ! -d "$FIRST_LORA_PATH" ]; then
        print_error "第一轮LoRA适配器路径不存在: $FIRST_LORA_PATH"
        exit 1
    fi

    # 验证LoRA文件完整性
    required_files=("adapter_config.json" "adapter_model.safetensors")
    for file in "${required_files[@]}"; do
        if [ ! -f "$FIRST_LORA_PATH/$file" ]; then
            print_error "缺少必要的LoRA文件: $FIRST_LORA_PATH/$file"
            exit 1
        fi
    done

    print_success "✅ 第一轮LoRA适配器验证通过"
fi

# 设置默认输出目录
if [ -z "$OUTPUT_DIR" ]; then
    TIMESTAMP=$(date +"%Y%m%d_%H%M")
    if [ "$SECOND_ROUND" = true ]; then
        OUTPUT_DIR="./outputs/second_round_training_${TIMESTAMP}"
    else
        OUTPUT_DIR="./outputs/distributed_training_${TIMESTAMP}"
    fi
fi

# 设置默认日志文件
if [ -z "$LOG_FILE" ]; then
    TIMESTAMP=$(date +"%Y%m%d_%H%M")
    LOG_FILE="./logs/training_${TIMESTAMP}.log"
fi

# 创建日志目录
mkdir -p "$(dirname "$LOG_FILE")"

if [ "$SECOND_ROUND" = true ]; then
    print_header "🔄 RTX 4090双卡第二轮迭代训练启动 (使用torchrun)"
else
    print_header "🚀 RTX 4090双卡分布式训练启动 (使用torchrun)"
fi
echo "=================================="

# 显示配置信息
print_info "基础配置信息:"
echo "  数据文件: $DATA_PATH"
echo "  模型路径: $MODEL_PATH"
echo "  输出目录: $OUTPUT_DIR"
echo "  训练轮数: $EPOCHS"
echo "  批次大小: $BATCH_SIZE (每卡)"
echo "  学习率: $LEARNING_RATE"
echo "  通信端口: $MASTER_PORT"
echo "  测试模式: $TEST_MODE"
echo "  微信通知: $ENABLE_WECHAT"
echo "  跳过GPU检查: $SKIP_GPU_CHECK"
echo "  后台运行: $BACKGROUND"
echo "  日志文件: $LOG_FILE"

print_info "高级训练配置:"
echo "  梯度累积步数: $GRADIENT_ACCUMULATION_STEPS"
echo "  预热比例: $WARMUP_RATIO"
echo "  权重衰减: $WEIGHT_DECAY"
echo "  梯度裁剪: $MAX_GRAD_NORM"
echo "  学习率调度器: $LR_SCHEDULER_TYPE"
echo "  保存步数: $SAVE_STEPS"
echo "  日志步数: $LOGGING_STEPS"
echo "  保存限制: $SAVE_TOTAL_LIMIT"

print_info "LoRA配置:"
echo "  LoRA rank: $LORA_R"
echo "  LoRA alpha: $LORA_ALPHA"

# SwanLab配置信息
if [ "$ENABLE_SWANLAB" = true ]; then
    echo ""
    print_info "SwanLab配置:"
    echo "  启用SwanLab: $ENABLE_SWANLAB"
    echo "  项目名称: $SWANLAB_PROJECT"
    echo "  实验名称: ${SWANLAB_EXPERIMENT:-'自动生成'}"
    echo "  实验描述: ${SWANLAB_DESCRIPTION:-'无'}"
    echo "  实验标签: ${SWANLAB_TAGS:-'无'}"
    echo "  API Key: ${SWANLAB_API_KEY:+已设置}"
fi

# 阶段评估配置信息
if [ "$ENABLE_EVALUATION" = true ]; then
    echo ""
    print_info "阶段评估配置:"
    echo "  启用评估: $ENABLE_EVALUATION"
    echo "  评估数据占比: ${EVAL_SPLIT_RATIO} (${EVAL_SPLIT_RATIO%.*}0%)"
    echo "  评估间隔: 每 $EVAL_STEPS 步"
fi

# EarlyStopping配置信息
if [ "$ENABLE_EARLY_STOPPING" = true ]; then
    echo ""
    print_info "EarlyStopping配置:"
    echo "  启用EarlyStopping: $ENABLE_EARLY_STOPPING"
    echo "  监控模式: $EARLY_STOPPING_METRIC"
    if [ "$EARLY_STOPPING_METRIC" = "dual_loss" ]; then
        echo "  训练指标: $EARLY_STOPPING_TRAIN_METRIC"
        echo "  评估指标: $EARLY_STOPPING_EVAL_METRIC"
        echo "  模式说明: 双指标联合监控，更智能的早停决策"
    else
        echo "  监控指标: $EARLY_STOPPING_METRIC"
        echo "  模式说明: 单指标监控模式"
    fi
    echo "  耐心值: $EARLY_STOPPING_PATIENCE"
    echo "  改善阈值: $EARLY_STOPPING_THRESHOLD"
fi

# 第二轮训练配置信息
if [ "$SECOND_ROUND" = true ]; then
    echo ""
    print_info "第二轮训练配置:"
    echo "  第二轮训练: $SECOND_ROUND"
    echo "  第一轮LoRA路径: $FIRST_LORA_PATH"
    echo "  自动发现LoRA: $AUTO_DISCOVER_LORA"
    echo "  组合LoRA: $COMBINE_LORAS"
    echo "  第二轮学习率: $SECOND_ROUND_LR"
fi

# 执行检查
print_info "执行预检查..."
check_gpu_count
check_port $MASTER_PORT

# 自动清理GPU显存
print_info "自动清理GPU显存..."
if [ -f "/root/lanyun-tmp/train/new/clear_gpu_memory.sh" ]; then
    print_info "🔥 执行GPU显存清理..."
    /root/lanyun-tmp/train/new/clear_gpu_memory.sh true  # 传递自动模式参数
    sleep 2
    print_success "GPU显存清理完成"
else
    print_warning "GPU清理脚本不存在，跳过自动清理"
    print_info "如果遇到显存不足，请手动执行: /root/lanyun-tmp/train/new/clear_gpu_memory.sh"
fi

# 创建输出目录
mkdir -p "$OUTPUT_DIR"
print_success "输出目录已创建: $OUTPUT_DIR"

# 设置环境变量以抑制 bitsandbytes 警告
export PYTHONWARNINGS="ignore::UserWarning:bitsandbytes.autograd._functions"

# 构建训练命令（使用新版torchrun，支持动态参数）
TRAIN_CMD="/root/miniconda/bin/torchrun \
--nproc_per_node=2 \
--master_port=$MASTER_PORT \
./first_time_training.py \
--data_path=$DATA_PATH \
--model_path=$MODEL_PATH \
--output_dir=$OUTPUT_DIR \
--num_epochs=$EPOCHS \
--per_device_train_batch_size=$BATCH_SIZE \
--gradient_accumulation_steps=$GRADIENT_ACCUMULATION_STEPS \
--learning_rate=$LEARNING_RATE \
--lr_scheduler_type=$LR_SCHEDULER_TYPE \
--warmup_ratio=$WARMUP_RATIO \
--weight_decay=$WEIGHT_DECAY \
--max_grad_norm=$MAX_GRAD_NORM \
--logging_steps=$LOGGING_STEPS \
--save_steps=$SAVE_STEPS \
--save_total_limit=$SAVE_TOTAL_LIMIT \
--lora_r=$LORA_R \
--lora_alpha=$LORA_ALPHA \
--enable_distributed"

if [ "$TEST_MODE" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --test_mode"
fi

if [ "$ENABLE_WECHAT" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --enable_wechat"
fi

if [ "$SKIP_GPU_CHECK" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --skip_gpu_check"
fi

# SwanLab参数
if [ "$ENABLE_SWANLAB" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --enable_swanlab"
    TRAIN_CMD="$TRAIN_CMD --swanlab_project=$SWANLAB_PROJECT"

    if [ -n "$SWANLAB_EXPERIMENT" ]; then
        TRAIN_CMD="$TRAIN_CMD --swanlab_experiment=$SWANLAB_EXPERIMENT"
    fi

    if [ -n "$SWANLAB_DESCRIPTION" ]; then
        TRAIN_CMD="$TRAIN_CMD --swanlab_description=\"$SWANLAB_DESCRIPTION\""
    fi

    if [ -n "$SWANLAB_TAGS" ]; then
        # 将标签转换为数组格式
        for tag in $SWANLAB_TAGS; do
            TRAIN_CMD="$TRAIN_CMD --swanlab_tags $tag"
        done
    fi

    if [ -n "$SWANLAB_API_KEY" ]; then
        TRAIN_CMD="$TRAIN_CMD --swanlab_api_key=$SWANLAB_API_KEY"
    fi
fi

# 阶段评估参数
if [ "$ENABLE_EVALUATION" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --enable_evaluation"
    TRAIN_CMD="$TRAIN_CMD --eval_split_ratio=$EVAL_SPLIT_RATIO"
    TRAIN_CMD="$TRAIN_CMD --eval_steps=$EVAL_STEPS"
    # 评估显存优化：若用户显式设置则传递，否则使用训练脚本默认（eval_batch=训练batch，accumulation=8）
    if [ -n "$PER_DEVICE_EVAL_BATCH_SIZE" ]; then
        TRAIN_CMD="$TRAIN_CMD --per_device_eval_batch_size=$PER_DEVICE_EVAL_BATCH_SIZE"
    fi
    if [ -n "$EVAL_ACCUMULATION_STEPS" ]; then
        TRAIN_CMD="$TRAIN_CMD --eval_accumulation_steps=$EVAL_ACCUMULATION_STEPS"
    fi
fi

# EarlyStopping参数
if [ "$ENABLE_EARLY_STOPPING" = true ]; then
    # 如果启用EarlyStopping但未启用评估，自动启用评估
    if [ "$ENABLE_EVALUATION" != true ]; then
        print_warning "EarlyStopping需要评估功能，自动启用评估"
        TRAIN_CMD="$TRAIN_CMD --enable_evaluation"
        TRAIN_CMD="$TRAIN_CMD --eval_split_ratio=0.1"
        TRAIN_CMD="$TRAIN_CMD --eval_steps=100"
    fi

    TRAIN_CMD="$TRAIN_CMD --enable_early_stopping"
    TRAIN_CMD="$TRAIN_CMD --early_stopping_patience=$EARLY_STOPPING_PATIENCE"
    TRAIN_CMD="$TRAIN_CMD --early_stopping_threshold=$EARLY_STOPPING_THRESHOLD"
    TRAIN_CMD="$TRAIN_CMD --early_stopping_metric=$EARLY_STOPPING_METRIC"

    # 如果是双指标模式，添加额外参数
    if [ "$EARLY_STOPPING_METRIC" = "dual_loss" ]; then
        TRAIN_CMD="$TRAIN_CMD --early_stopping_train_metric=$EARLY_STOPPING_TRAIN_METRIC"
        TRAIN_CMD="$TRAIN_CMD --early_stopping_eval_metric=$EARLY_STOPPING_EVAL_METRIC"
    fi
fi

# 第二轮训练参数
if [ "$SECOND_ROUND" = true ]; then
    TRAIN_CMD="$TRAIN_CMD --second_round_training"
    TRAIN_CMD="$TRAIN_CMD --first_lora_adapter_path=$FIRST_LORA_PATH"

    if [ "$COMBINE_LORAS" = true ]; then
        TRAIN_CMD="$TRAIN_CMD --combine_loras"
    fi

    # 使用第二轮训练专用学习率
    TRAIN_CMD="$TRAIN_CMD --override_learning_rate=$SECOND_ROUND_LR"
fi

print_info "训练命令:"
echo "$TRAIN_CMD"

# 后台运行模式
if [ "$BACKGROUND" = true ]; then
    print_success "启动后台分布式训练..."
    echo "=================================="
    print_info "训练命令: $TRAIN_CMD"
    print_info "日志文件: $LOG_FILE"
    print_info "输出目录: $OUTPUT_DIR"
    echo ""

    # 后台执行训练
    nohup bash -c "$TRAIN_CMD" > "$LOG_FILE" 2>&1 &
    TRAIN_PID=$!

    print_success "🚀 训练已在后台启动！"
    print_info "进程ID: $TRAIN_PID"
    print_info "日志文件: $LOG_FILE"
    print_info "输出目录: $OUTPUT_DIR"
    echo ""
    print_info "监控训练进度:"
    echo "  tail -f $LOG_FILE"
    echo ""
    print_info "停止训练:"
    echo "  kill $TRAIN_PID"
    echo ""
    print_info "检查进程状态:"
    echo "  ps aux | grep $TRAIN_PID"

    # 保存PID到文件
    echo $TRAIN_PID > "./logs/training_${TIMESTAMP}.pid"
    print_info "PID已保存到: ./logs/training_${TIMESTAMP}.pid"

else
    # 前台运行模式（原有逻辑）
    echo ""
    read -p "是否开始分布式训练? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "训练已取消"
        exit 0
    fi

    if [ "$SECOND_ROUND" = true ]; then
        print_success "开始RTX 4090双卡第二轮迭代训练..."
    else
        print_success "开始RTX 4090双卡分布式训练..."
    fi
    echo "=================================="

    # 执行训练
    eval $TRAIN_CMD

    if [ "$SECOND_ROUND" = true ]; then
        print_success "第二轮迭代训练完成！"
        print_info "第二轮LoRA适配器: $OUTPUT_DIR"
        print_info "第一轮LoRA适配器: $FIRST_LORA_PATH"
        print_info "💡 建议下一步: 使用 merge_lora_model.py 合并模型"
    else
        print_success "分布式训练完成！"
        print_info "输出目录: $OUTPUT_DIR"
    fi
fi
