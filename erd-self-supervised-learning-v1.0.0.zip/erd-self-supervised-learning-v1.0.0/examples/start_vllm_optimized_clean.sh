#!/bin/bash

# vLLM优化启动脚本 - 清理版本
# 专门用于4090服务器的vLLM服务启动，支持自动GPU检测和双卡配置

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# 配置参数
CONFIG_FILE="api/configs/vllm_config.json"
BASE_MODEL_PATH="/root/lanyun-tmp/modelscope_cache/qwen/Qwen2.5-3b"
LORA_DIR="/root/lanyun-tmp/train/new/25out"
VLLM_PORT=8000
LOG_DIR="/root/lanyun-tmp/train/new/vllm/logs"

# 检测Python路径
detect_python_path() {
    if [ -f "/root/miniconda/bin/python" ]; then
        echo "/root/miniconda/bin/python"
    elif [ -f "/root/miniconda3/bin/python" ]; then
        echo "/root/miniconda3/bin/python"
    elif command -v python3 &> /dev/null; then
        echo "python3"
    elif command -v python &> /dev/null; then
        echo "python"
    else
        log_error "找不到Python解释器"
        return 1
    fi
}

# 检查并安装 jq 工具
ensure_jq_installed() {
    if ! command -v jq &> /dev/null; then
        log_info "jq 工具未安装，正在尝试安装..."
        
        if command -v yum &> /dev/null; then
            yum install -y jq &> /dev/null
        elif command -v apt-get &> /dev/null; then
            apt-get update &> /dev/null && apt-get install -y jq &> /dev/null
        elif command -v dnf &> /dev/null; then
            dnf install -y jq &> /dev/null
        else
            log_error "无法自动安装 jq，请手动安装"
            return 1
        fi
        
        if command -v jq &> /dev/null; then
            log_info "✅ jq 工具安装成功"
        else
            log_error "❌ jq 工具安装失败"
            return 1
        fi
    fi
    return 0
}

# 检测GPU类型并智能配置
detect_gpu_and_optimize() {
    log_step "检测GPU类型并智能配置..."
    
    # 检测GPU信息
    local gpu_info=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | head -1)
    local gpu_count=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | wc -l)
    
    if [ -z "$gpu_info" ]; then
        log_error "无法检测GPU信息"
        return 1
    fi
    
    log_info "检测到GPU: $gpu_info (数量: $gpu_count)"
    
    # 确定GPU类型
    if [[ "$gpu_info" == *"RTX 4090"* ]]; then
        GPU_TYPE="RTX_4090"
    elif [[ "$gpu_info" == *"RTX 3090"* ]]; then
        GPU_TYPE="RTX_3090"
    else
        GPU_TYPE="DEFAULT"
    fi
    
    # 先加载配置文件设置
    load_gpu_config_from_json "$GPU_TYPE" "$gpu_count"
    
    # 然后根据配置文件的auto设置决定是否使用自动检测
    local config_tensor_parallel=$(jq -r '.service_config.tensor_parallel_size // 1' "$CONFIG_FILE" 2>/dev/null)
    
    if [ "$config_tensor_parallel" = "auto" ]; then
        log_info "🔧 配置文件设置为auto模式，使用智能GPU检测"
        # 智能配置：根据GPU数量自动调整
        configure_for_gpu_count "$GPU_TYPE" "$gpu_count"
    else
        log_info "📋 使用配置文件中的固定tensor_parallel_size设置"
    fi
    
    log_info "✅ $GPU_TYPE 智能配置已应用"
    log_info "GPU配置: 内存利用率=$GPU_MEMORY_UTILIZATION, 模型长度=$MAX_MODEL_LEN, 张量并行=$TENSOR_PARALLEL_SIZE"
    return 0
}

# 根据GPU数量智能配置
configure_for_gpu_count() {
    local gpu_type="$1"
    local gpu_count="$2"
    
    log_info "🔧 为 $gpu_count 张 $gpu_type 配置优化参数..."
    
    # 基础配置
    case "$gpu_type" in
        "RTX_4090")
            GPU_MEMORY_UTILIZATION=0.85
            MAX_MODEL_LEN=8192
            MAX_NUM_BATCHED_TOKENS=8192
            MAX_NUM_SEQS=256
            ENABLE_FLASH_ATTENTION="true"
            ;;
        "RTX_3090")
            GPU_MEMORY_UTILIZATION=0.8
            MAX_MODEL_LEN=4096
            MAX_NUM_BATCHED_TOKENS=4096
            MAX_NUM_SEQS=128
            ENABLE_FLASH_ATTENTION="true"
            ;;
        *)
            GPU_MEMORY_UTILIZATION=0.8
            MAX_MODEL_LEN=4096
            MAX_NUM_BATCHED_TOKENS=4096
            MAX_NUM_SEQS=128
            ENABLE_FLASH_ATTENTION="true"
            ;;
    esac
    
    # 根据GPU数量调整配置
    if [ "$gpu_count" -eq 1 ]; then
        # 单卡配置
        TENSOR_PARALLEL_SIZE=1
        ENABLE_RAY_OPTIMIZATION="false"
        DISTRIBUTED_BACKEND="none"
        log_info "📱 自动检测: 单卡配置, 无分布式后端"
        
    elif [ "$gpu_count" -eq 2 ]; then
        # 双卡配置
        TENSOR_PARALLEL_SIZE=2
        ENABLE_RAY_OPTIMIZATION="false"  # 双卡用MP更稳定
        DISTRIBUTED_BACKEND="mp"
        # 设置CUDA设备可见性
        export CUDA_VISIBLE_DEVICES="0,1"
        export VLLM_WORKER_MULTIPROC_METHOD="spawn"
        log_info "🔗 自动检测: 双卡配置, MP分布式后端"
        
    else
        # 多卡配置（3卡及以上）
        TENSOR_PARALLEL_SIZE="$gpu_count"
        ENABLE_RAY_OPTIMIZATION="true"  # 多卡用Ray更好
        DISTRIBUTED_BACKEND="ray"
        # 设置所有GPU可见
        local cuda_devices=$(seq -s, 0 $((gpu_count-1)))
        export CUDA_VISIBLE_DEVICES="$cuda_devices"
        export RAY_DISABLE_DOCKER_CPU_WARNING=1
        export RAY_USE_MULTIPROCESSING_CPU_COUNT=1
        log_info "🚀 自动检测: 多卡配置, Ray分布式后端, GPU: $cuda_devices"
    fi
    
    log_info "⚙️ 自动检测最终配置: ${gpu_count}卡 $gpu_type, 张量并行=$TENSOR_PARALLEL_SIZE, 后端=$DISTRIBUTED_BACKEND"
}

# 从配置文件加载GPU优化配置
load_gpu_config_from_json() {
    local gpu_type="$1"
    local gpu_count="$2"
    
    if [ ! -f "$CONFIG_FILE" ]; then
        log_error "配置文件不存在，使用默认GPU配置"
        return 1
    fi
    
    # 检查并安装 jq 工具
    if ! ensure_jq_installed; then
        log_error "jq 工具不可用，使用默认GPU配置"
        return 1
    fi
    
    # 从配置文件读取基础配置
    MAX_LORAS=$(jq -r '.service_config.max_loras // 10' "$CONFIG_FILE" 2>/dev/null)
    MAX_LORA_RANK=$(jq -r '.service_config.max_lora_rank // 32' "$CONFIG_FILE" 2>/dev/null)
    
    # 从配置文件读取GPU优化配置
    local profile_path=".gpu_optimization.gpu_profiles.$gpu_type"
    
    # 读取GPU配置参数
    local config_gpu_memory=$(jq -r "$profile_path.gpu_memory_utilization // 0.85" "$CONFIG_FILE" 2>/dev/null)
    local config_max_model_len=$(jq -r "$profile_path.max_model_len // 8192" "$CONFIG_FILE" 2>/dev/null)
    local config_max_batched_tokens=$(jq -r "$profile_path.max_num_batched_tokens // 8192" "$CONFIG_FILE" 2>/dev/null)
    local config_max_seqs=$(jq -r "$profile_path.max_num_seqs // 256" "$CONFIG_FILE" 2>/dev/null)
    local config_flash_attention=$(jq -r "$profile_path.enable_flash_attention // true" "$CONFIG_FILE" 2>/dev/null)
    local config_auto_tensor_parallel=$(jq -r "$profile_path.auto_tensor_parallel // false" "$CONFIG_FILE" 2>/dev/null)
    
    # 应用配置
    GPU_MEMORY_UTILIZATION="$config_gpu_memory"
    MAX_MODEL_LEN="$config_max_model_len"
    MAX_NUM_BATCHED_TOKENS="$config_max_batched_tokens"
    MAX_NUM_SEQS="$config_max_seqs"
    ENABLE_FLASH_ATTENTION="$config_flash_attention"
    
    log_info "📋 从配置文件加载GPU优化配置: $gpu_type"
    return 0
}

# 检查基础模型
check_base_model() {
    log_step "检查基础模型..."
    
    if [ ! -d "$BASE_MODEL_PATH" ]; then
        log_error "基础模型不存在: $BASE_MODEL_PATH"
        return 1
    fi
    
    if [ ! -f "$BASE_MODEL_PATH/config.json" ]; then
        log_error "模型配置文件不存在: $BASE_MODEL_PATH/config.json"
        return 1
    fi
    
    log_info "✅ 基础模型检查通过: $BASE_MODEL_PATH"
    return 0
}

# 发现LoRA适配器
discover_lora_adapters() {
    log_step "发现LoRA适配器..."
    
    local lora_count=0
    local lora_modules=""
    
    if [ ! -d "$LORA_DIR" ]; then
        log_info "LoRA目录不存在，以基础模型模式启动"
        export LORA_COUNT=0
        return 0
    fi
    
    # 扫描LoRA适配器
    for dir in "$LORA_DIR"/*; do
        if [ -d "$dir" ] && [ -f "$dir/adapter_config.json" ]; then
            local adapter_name=$(basename "$dir")
            log_info "发现LoRA适配器: $adapter_name"
            
            if [ -n "$lora_modules" ]; then
                lora_modules="$lora_modules $adapter_name=$dir"
            else
                lora_modules="$adapter_name=$dir"
            fi
            
            lora_count=$((lora_count + 1))
        fi
    done
    
    if [ $lora_count -gt 0 ]; then
        log_info "✅ 发现 $lora_count 个LoRA适配器"
        export LORA_MODULES="$lora_modules"
        export LORA_COUNT=$lora_count
    else
        log_info "未发现LoRA适配器，以基础模型模式启动"
        export LORA_COUNT=0
    fi
    
    return 0
}

# 启动vLLM服务
start_vllm_service() {
    log_step "启动vLLM服务..."

    # 检测Python路径
    PYTHON_PATH=$(detect_python_path)
    if [ $? -ne 0 ]; then
        return 1
    fi
    log_info "✅ 使用Python路径: $PYTHON_PATH"

    # 检查端口占用
    if netstat -tuln | grep -q ":$VLLM_PORT "; then
        log_error "端口 $VLLM_PORT 已被占用"
        log_info "尝试停止现有vLLM服务..."
        pkill -f "vllm.entrypoints.openai.api_server"
        sleep 5
    fi

    # 创建日志目录
    mkdir -p "$LOG_DIR"

    # 构建启动命令
    local cmd="$PYTHON_PATH -m vllm.entrypoints.openai.api_server"
    cmd="$cmd --model $BASE_MODEL_PATH"
    cmd="$cmd --tensor-parallel-size $TENSOR_PARALLEL_SIZE"
    cmd="$cmd --gpu-memory-utilization $GPU_MEMORY_UTILIZATION"
    cmd="$cmd --max-model-len $MAX_MODEL_LEN"
    cmd="$cmd --max-num-batched-tokens $MAX_NUM_BATCHED_TOKENS"
    cmd="$cmd --max-num-seqs $MAX_NUM_SEQS"
    cmd="$cmd --port $VLLM_PORT"
    cmd="$cmd --host 0.0.0.0"
    cmd="$cmd --served-model-name qwen"
    cmd="$cmd --trust-remote-code"

    # Flash Attention和KV缓存优化
    if [ "$ENABLE_FLASH_ATTENTION" = "true" ]; then
        cmd="$cmd --kv-cache-dtype auto"
        log_info "✅ 启用Flash Attention优化"
    fi

    # 智能分布式后端选择
    if [ "$DISTRIBUTED_BACKEND" = "ray" ]; then
        cmd="$cmd --distributed-executor-backend ray"
        log_info "✅ 启用Ray分布式后端（多卡优化）"
    elif [ "$DISTRIBUTED_BACKEND" = "mp" ]; then
        cmd="$cmd --distributed-executor-backend mp"
        log_info "✅ 启用MP分布式后端（双卡优化）"
    elif [ "$TENSOR_PARALLEL_SIZE" -gt 1 ]; then
        cmd="$cmd --distributed-executor-backend mp"
        log_info "⚠️ 备用MP分布式后端"
    else
        log_info "📱 单卡模式：无需分布式后端"
    fi

    # 如果有LoRA适配器，添加LoRA支持
    if [ "${LORA_COUNT:-0}" -gt 0 ]; then
        cmd="$cmd --enable-lora"
        cmd="$cmd --max-lora-rank $MAX_LORA_RANK"
        cmd="$cmd --max-loras $MAX_LORAS"
        cmd="$cmd --max-cpu-loras $((MAX_LORAS * 2))"
        cmd="$cmd --lora-modules"

        # 使用JSON格式的LoRA模块参数
        for module in $LORA_MODULES; do
            adapter_name=$(echo "$module" | cut -d'=' -f1)
            adapter_path=$(echo "$module" | cut -d'=' -f2)
            json_config="{\"name\": \"$adapter_name\", \"path\": \"$adapter_path\", \"base_model_name\": \"qwen\"}"
            cmd="$cmd '$json_config'"
        done

        log_info "启用LoRA支持，加载 $LORA_COUNT 个适配器"
    else
        log_info "基础模型模式，不启用LoRA"
    fi

    log_info "🚀 vLLM优化配置总览:"
    log_info "  GPU类型: $GPU_TYPE"
    log_info "  GPU内存利用率: $GPU_MEMORY_UTILIZATION"
    log_info "  最大模型长度: $MAX_MODEL_LEN"
    log_info "  张量并行大小: $TENSOR_PARALLEL_SIZE"
    log_info "  分布式后端: $DISTRIBUTED_BACKEND"
    log_info "  服务端口: $VLLM_PORT"

    # 记录启动命令到日志
    local log_file="$LOG_DIR/vllm_optimized.log"
    echo "$(date '+%Y-%m-%d %H:%M:%S') 启动命令: $cmd" >> "$log_file"

    # 启动服务
    log_info "🚀 启动vLLM服务..."
    nohup bash -c "$cmd" >> "$log_file" 2>&1 &
    local vllm_pid=$!
    echo $vllm_pid > "$LOG_DIR/vllm.pid"

    log_info "vLLM服务已启动 (PID: $vllm_pid)"
    log_info "日志文件: $log_file"

    # 等待服务启动
    log_info "等待vLLM服务启动..."
    local max_wait=300
    local wait_time=0

    while [ $wait_time -lt $max_wait ]; do
        if curl -s --connect-timeout 5 "http://localhost:$VLLM_PORT/health" > /dev/null; then
            log_info "✅ vLLM服务启动成功"
            log_info "服务地址: http://localhost:$VLLM_PORT"

            # 显示GPU使用情况
            log_info "=== GPU使用情况 ==="
            nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits

            return 0
        fi

        sleep 5
        wait_time=$((wait_time + 5))
        echo -n "."
    done

    echo ""
    log_error "❌ vLLM服务启动超时"
    log_error "请检查日志: tail -f $log_file"
    return 1
}

# 停止vLLM服务
stop_vllm_service() {
    log_step "停止vLLM服务..."

    if [ -f "$LOG_DIR/vllm.pid" ]; then
        local vllm_pid=$(cat "$LOG_DIR/vllm.pid")
        if kill -0 $vllm_pid 2>/dev/null; then
            kill $vllm_pid
            log_info "✅ vLLM服务已停止 (PID: $vllm_pid)"
        else
            log_info "vLLM服务进程不存在"
        fi
        rm -f "$LOG_DIR/vllm.pid"
    fi

    # 强制杀死vLLM进程
    pkill -f "vllm.entrypoints.openai.api_server" 2>/dev/null || true
    log_info "✅ vLLM服务清理完成"
}

# 检查vLLM服务状态
check_vllm_status() {
    log_step "检查vLLM服务状态..."

    if curl -s --connect-timeout 5 "http://localhost:$VLLM_PORT/health" > /dev/null; then
        log_info "✅ vLLM服务运行正常"

        # 获取模型信息
        local models=$(curl -s "http://localhost:$VLLM_PORT/v1/models" | jq -r '.data[].id' 2>/dev/null || echo "无法获取")
        log_info "可用模型: $models"

        # 显示GPU使用情况
        log_info "=== GPU使用情况 ==="
        nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu --format=csv,noheader,nounits

        return 0
    else
        log_error "❌ vLLM服务未运行或无响应"
        return 1
    fi
}

# 主函数
main() {
    case "${1:-start}" in
        start)
            log_info "🚀 启动vLLM优化服务..."

            # 检查基础模型
            check_base_model || exit 1

            # 发现LoRA适配器
            discover_lora_adapters

            # 检测GPU并优化配置
            detect_gpu_and_optimize || exit 1

            # 启动vLLM服务
            start_vllm_service || exit 1

            log_info "🎉 vLLM服务启动完成"
            ;;
        stop)
            stop_vllm_service
            ;;
        restart)
            log_info "🔄 重启vLLM服务..."
            stop_vllm_service
            sleep 3
            main start
            ;;
        status)
            check_vllm_status
            ;;
        gpu)
            detect_gpu_and_optimize
            ;;
        gpu-test)
            # 测试GPU检测功能（用于调试）
            log_step "测试GPU检测功能..."
            echo "=== GPU检测测试 ==="
            local gpu_info=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | head -1)
            local gpu_count=$(nvidia-smi --query-gpu=name --format=csv,noheader,nounits 2>/dev/null | wc -l)
            echo "检测到GPU: $gpu_info (数量: $gpu_count)"

            if [[ "$gpu_info" == *"RTX 4090"* ]]; then
                echo "GPU类型: RTX_4090"
            elif [[ "$gpu_info" == *"RTX 3090"* ]]; then
                echo "GPU类型: RTX_3090"
            else
                echo "GPU类型: DEFAULT"
            fi
            ;;
        *)
            echo "用法: $0 {start|stop|restart|status|gpu|gpu-test}"
            echo ""
            echo "  start     - 启动vLLM服务"
            echo "  stop      - 停止vLLM服务"
            echo "  restart   - 重启vLLM服务"
            echo "  status    - 检查服务状态"
            echo "  gpu       - 检测GPU并配置"
            echo "  gpu-test  - 测试GPU检测功能"
            exit 1
            ;;
    esac
}

# 检查依赖
check_dependencies() {
    local missing_deps=()

    if ! command -v nvidia-smi &> /dev/null; then
        missing_deps+=("nvidia-smi")
    fi

    if ! detect_python_path &> /dev/null; then
        missing_deps+=("python")
    fi

    if [ ${#missing_deps[@]} -ne 0 ]; then
        log_error "缺少依赖: ${missing_deps[*]}"
        return 1
    fi

    return 0
}

# 脚本入口
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    # 检查依赖
    check_dependencies || exit 1

    # 运行主函数
    main "$@"
fi
