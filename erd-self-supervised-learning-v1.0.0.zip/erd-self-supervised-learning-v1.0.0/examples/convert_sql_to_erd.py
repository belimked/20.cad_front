#!/usr/bin/env python3
"""
SQL转ERD转换示例

将SQL文件转换为ERD JSON格式

使用示例:
python examples/convert_sql_to_erd.py --sql_file data/erd/cost.sql --output data/erd/cost_erd.json
"""

import argparse
import json
import sys
from pathlib import Path

# 添加src目录到路径
sys.path.append(str(Path(__file__).parent.parent / "src"))

from utils.sql_to_erd_converter import SQLToERDConverter


def main():
    parser = argparse.ArgumentParser(description="将SQL文件转换为ERD JSON格式")
    parser.add_argument("--sql_file", type=str, required=True, help="SQL文件路径")
    parser.add_argument("--output", type=str, required=True, help="输出ERD JSON文件路径")
    
    args = parser.parse_args()
    
    print("🔄 开始转换SQL文件到ERD格式")
    print(f"输入文件: {args.sql_file}")
    print(f"输出文件: {args.output}")
    
    # 创建转换器
    converter = SQLToERDConverter()
    
    # 转换SQL文件
    try:
        erd_data = converter.parse_sql_file(args.sql_file)
        
        # 统计信息
        print(f"\n📊 转换完成统计:")
        print(f"  - 表数量: {len(erd_data['tables'])}")
        print(f"  - 关系数量: {len(erd_data['relationships'])}")
        
        # 显示表列表
        print(f"\n📋 表列表:")
        for i, table in enumerate(erd_data['tables'][:10], 1):  # 只显示前10个
            field_count = len(table['fields'])
            print(f"  {i:2d}. {table['name']} ({field_count}个字段)")
        
        if len(erd_data['tables']) > 10:
            print(f"  ... 还有 {len(erd_data['tables']) - 10} 个表")
        
        # 显示关系列表
        print(f"\n🔗 关系列表:")
        for i, rel in enumerate(erd_data['relationships'][:10], 1):  # 只显示前10个
            print(f"  {i:2d}. {rel['from_table']}.{rel['from_field']} -> {rel['to_table']}.{rel['to_field']}")
        
        if len(erd_data['relationships']) > 10:
            print(f"  ... 还有 {len(erd_data['relationships']) - 10} 个关系")
        
        # 保存ERD JSON文件
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(erd_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n✅ ERD文件已保存: {args.output}")
        
        # 生成统计报告
        stats_file = output_path.with_suffix('.stats.json')
        stats = {
            'total_tables': len(erd_data['tables']),
            'total_relationships': len(erd_data['relationships']),
            'total_fields': sum(len(table['fields']) for table in erd_data['tables']),
            'avg_fields_per_table': sum(len(table['fields']) for table in erd_data['tables']) / len(erd_data['tables']) if erd_data['tables'] else 0,
            'tables_with_relationships': len(set([rel['from_table'] for rel in erd_data['relationships']] + [rel['to_table'] for rel in erd_data['relationships']])),
            'table_list': [{'name': table['name'], 'field_count': len(table['fields']), 'description': table.get('description', '')} for table in erd_data['tables']]
        }
        
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        
        print(f"📈 统计报告已保存: {stats_file}")
        
        print(f"\n🎯 现在可以使用这个ERD文件进行训练:")
        print(f"python examples/train_model.py --erd_file {args.output}")
        
    except Exception as e:
        print(f"❌ 转换失败: {str(e)}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
