"""
训练数据生成器

基于ERD信息自动生成训练样本
"""

import random
import json
from typing import Dict, List, Tuple, Optional
from .erd_parser import ERDParser, Relationship, TableInfo


class TrainingDataGenerator:
    """训练数据生成器"""
    
    def __init__(self, erd_parser: ERDParser):
        self.erd_parser = erd_parser
        self.question_templates = self._load_question_templates()
        self.sql_templates = self._load_sql_templates()
    
    def generate_all_samples(self, max_samples: int = 5000) -> List[Dict]:
        """生成所有训练样本"""
        samples = []
        
        # 1. 基础关系样本 (40%)
        basic_samples = self._generate_basic_relationship_samples(int(max_samples * 0.4))
        samples.extend(basic_samples)
        
        # 2. 路径发现样本 (30%)
        path_samples = self._generate_path_discovery_samples(int(max_samples * 0.3))
        samples.extend(path_samples)
        
        # 3. SQL生成样本 (20%)
        sql_samples = self._generate_sql_samples(int(max_samples * 0.2))
        samples.extend(sql_samples)
        
        # 4. 负样本 (10%)
        negative_samples = self._generate_negative_samples(int(max_samples * 0.1))
        samples.extend(negative_samples)
        
        # 打乱顺序
        random.shuffle(samples)
        
        return samples[:max_samples]
    
    def _generate_basic_relationship_samples(self, num_samples: int) -> List[Dict]:
        """生成基础关系样本"""
        samples = []
        relationships = self.erd_parser.relationships
        
        for _ in range(num_samples):
            if not relationships:
                break
                
            rel = random.choice(relationships)
            
            # 随机选择问题模板
            templates = [
                f"{rel.from_table}和{rel.to_table}怎么关联？",
                f"如何从{rel.from_table}查询{rel.to_table}的信息？",
                f"{rel.from_table}表和{rel.to_table}表的关系是什么？",
                f"要关联{rel.from_table}和{rel.to_table}需要用什么字段？"
            ]
            
            question = random.choice(templates)
            
            # 生成答案
            rel_type_map = {
                "one_to_one": "一对一",
                "one_to_many": "一对多", 
                "many_to_many": "多对多"
            }
            
            rel_type = rel_type_map.get(rel.relationship_type, "一对多")
            
            answer = f"{rel.from_table}通过{rel.from_field}字段与{rel.to_table}的{rel.to_field}字段关联，关系类型为{rel_type}。"
            
            # 添加SQL示例
            sql_example = f"SELECT * FROM {rel.from_table} a JOIN {rel.to_table} b ON a.{rel.from_field} = b.{rel.to_field}"
            answer += f"\nSQL示例: {sql_example}"
            
            sample = {
                "task_type": "basic_relationship",
                "instruction": "分析数据库表关联关系",
                "input": self._format_schema_context() + f"\n问题: {question}",
                "output": answer,
                "metadata": {
                    "from_table": rel.from_table,
                    "to_table": rel.to_table,
                    "relationship_type": rel.relationship_type
                }
            }
            
            samples.append(sample)
        
        return samples
    
    def _generate_path_discovery_samples(self, num_samples: int) -> List[Dict]:
        """生成路径发现样本"""
        samples = []
        table_names = self.erd_parser.get_table_names()
        
        for _ in range(num_samples):
            if len(table_names) < 2:
                break
                
            # 随机选择两个表
            from_table, to_table = random.sample(table_names, 2)
            
            # 查找路径
            paths = self.erd_parser.find_relationship_path(from_table, to_table, max_hops=3)
            
            if not paths:
                continue
            
            # 选择最短路径
            shortest_path = min(paths, key=len)
            
            question = f"如何从{from_table}查询到{to_table}的信息？"
            
            if len(shortest_path) == 2:
                answer = f"可以直接关联：{' -> '.join(shortest_path)}"
            else:
                answer = f"需要通过间接关联：{' -> '.join(shortest_path)}"
            
            # 生成详细的关联说明
            path_details = []
            for i in range(len(shortest_path) - 1):
                current_table = shortest_path[i]
                next_table = shortest_path[i + 1]
                
                # 查找这两个表之间的关系
                rel = self._find_relationship(current_table, next_table)
                if rel:
                    path_details.append(f"{current_table}.{rel.from_field} = {next_table}.{rel.to_field}")
            
            if path_details:
                answer += f"\n关联条件: {' AND '.join(path_details)}"
            
            sample = {
                "task_type": "path_discovery",
                "instruction": "分析数据库表关联路径",
                "input": self._format_schema_context() + f"\n问题: {question}",
                "output": answer,
                "metadata": {
                    "from_table": from_table,
                    "to_table": to_table,
                    "path_length": len(shortest_path),
                    "path": shortest_path
                }
            }
            
            samples.append(sample)
        
        return samples
    
    def _generate_sql_samples(self, num_samples: int) -> List[Dict]:
        """生成SQL样本"""
        samples = []
        
        sql_templates = [
            {
                "question": "查询每个{table1}的{table2}数量",
                "sql": "SELECT a.*, COUNT(b.id) as {table2}_count FROM {table1} a LEFT JOIN {table2} b ON a.{key1} = b.{key2} GROUP BY a.{key1}"
            },
            {
                "question": "查询{table1}和对应的{table2}信息",
                "sql": "SELECT a.*, b.* FROM {table1} a JOIN {table2} b ON a.{key1} = b.{key2}"
            },
            {
                "question": "查询没有{table2}的{table1}",
                "sql": "SELECT a.* FROM {table1} a LEFT JOIN {table2} b ON a.{key1} = b.{key2} WHERE b.{key2} IS NULL"
            }
        ]
        
        for _ in range(num_samples):
            relationships = self.erd_parser.relationships
            if not relationships:
                break
                
            rel = random.choice(relationships)
            template = random.choice(sql_templates)
            
            question = template["question"].format(
                table1=rel.from_table,
                table2=rel.to_table
            )
            
            sql = template["sql"].format(
                table1=rel.from_table,
                table2=rel.to_table,
                key1=rel.from_field,
                key2=rel.to_field
            )
            
            sample = {
                "task_type": "sql_generation",
                "instruction": "根据需求生成SQL查询",
                "input": self._format_schema_context() + f"\n需求: {question}",
                "output": f"SQL查询:\n```sql\n{sql}\n```",
                "metadata": {
                    "tables_involved": [rel.from_table, rel.to_table],
                    "query_type": "join"
                }
            }
            
            samples.append(sample)
        
        return samples
    
    def _generate_negative_samples(self, num_samples: int) -> List[Dict]:
        """生成负样本"""
        samples = []
        table_names = self.erd_parser.get_table_names()
        
        for _ in range(num_samples):
            if len(table_names) < 2:
                break
                
            # 随机选择两个没有关系的表
            table1, table2 = random.sample(table_names, 2)
            
            # 检查是否真的没有关系
            paths = self.erd_parser.find_relationship_path(table1, table2, max_hops=2)
            if paths:
                continue  # 有关系，跳过
            
            question = f"{table1}和{table2}怎么关联？"
            answer = f"{table1}和{table2}之间没有直接或间接的关联关系。这两个表在当前数据库设计中是独立的。"
            
            sample = {
                "task_type": "negative_relationship",
                "instruction": "分析数据库表关联关系",
                "input": self._format_schema_context() + f"\n问题: {question}",
                "output": answer,
                "metadata": {
                    "table1": table1,
                    "table2": table2,
                    "has_relationship": False
                }
            }
            
            samples.append(sample)
        
        return samples
    
    def _format_schema_context(self) -> str:
        """格式化schema上下文"""
        context = "数据库Schema信息:\n"
        
        for table_name, table_info in self.erd_parser.tables.items():
            fields_str = ", ".join([
                f"{field.name}({field.data_type})" + 
                ("*PK" if field.is_primary_key else "") +
                ("*FK" if field.is_foreign_key else "")
                for field in table_info.fields
            ])
            context += f"- {table_name}({fields_str})\n"
        
        return context.strip()
    
    def _find_relationship(self, table1: str, table2: str) -> Optional[Relationship]:
        """查找两个表之间的关系"""
        for rel in self.erd_parser.relationships:
            if (rel.from_table == table1 and rel.to_table == table2) or \
               (rel.from_table == table2 and rel.to_table == table1):
                return rel
        return None
    
    def _load_question_templates(self) -> List[str]:
        """加载问题模板"""
        return [
            "{table1}和{table2}怎么关联？",
            "如何从{table1}查询{table2}的信息？",
            "{table1}表和{table2}表的关系是什么？",
            "要关联{table1}和{table2}需要用什么字段？"
        ]
    
    def _load_sql_templates(self) -> List[Dict]:
        """加载SQL模板"""
        return [
            {
                "type": "join",
                "template": "SELECT * FROM {table1} a JOIN {table2} b ON a.{key1} = b.{key2}"
            },
            {
                "type": "left_join",
                "template": "SELECT * FROM {table1} a LEFT JOIN {table2} b ON a.{key1} = b.{key2}"
            },
            {
                "type": "count",
                "template": "SELECT a.*, COUNT(b.id) FROM {table1} a LEFT JOIN {table2} b ON a.{key1} = b.{key2} GROUP BY a.{key1}"
            }
        ]
