"""
关系分析器

分析ERD中的表关系模式
"""

from typing import Dict, List, Set, Tuple
from .erd_parser import ERDParser, Relationship
import networkx as nx


class RelationshipAnalyzer:
    """关系分析器"""
    
    def __init__(self, erd_parser: ERDParser):
        self.erd_parser = erd_parser
        self.graph = self._build_relationship_graph()
    
    def _build_relationship_graph(self) -> nx.DiGraph:
        """构建关系图"""
        graph = nx.DiGraph()
        
        # 添加所有表作为节点
        for table_name in self.erd_parser.get_table_names():
            graph.add_node(table_name)
        
        # 添加关系作为边
        for rel in self.erd_parser.relationships:
            graph.add_edge(rel.from_table, rel.to_table, relationship=rel)
        
        return graph
    
    def find_central_tables(self, top_k: int = 5) -> List[Tuple[str, int]]:
        """查找中心表（连接度最高的表）"""
        degree_centrality = nx.degree_centrality(self.graph.to_undirected())
        
        # 按中心度排序
        sorted_tables = sorted(degree_centrality.items(), key=lambda x: x[1], reverse=True)
        
        return [(table, int(centrality * len(self.graph.nodes))) for table, centrality in sorted_tables[:top_k]]
    
    def find_relationship_clusters(self) -> List[List[str]]:
        """查找关系集群"""
        undirected_graph = self.graph.to_undirected()
        
        # 使用连通分量查找集群
        clusters = list(nx.connected_components(undirected_graph))
        
        return [list(cluster) for cluster in clusters if len(cluster) > 1]
    
    def analyze_relationship_patterns(self) -> Dict:
        """分析关系模式"""
        patterns = {
            "one_to_one": 0,
            "one_to_many": 0,
            "many_to_many": 0,
            "self_reference": 0
        }
        
        for rel in self.erd_parser.relationships:
            if rel.from_table == rel.to_table:
                patterns["self_reference"] += 1
            else:
                patterns[rel.relationship_type] += 1
        
        return patterns
    
    def get_table_importance_score(self, table_name: str) -> float:
        """计算表的重要性分数"""
        if table_name not in self.graph:
            return 0.0
        
        # 基于多个指标计算重要性
        degree = self.graph.degree(table_name)
        in_degree = self.graph.in_degree(table_name)
        out_degree = self.graph.out_degree(table_name)
        
        # 归一化分数
        max_degree = max(dict(self.graph.degree()).values()) if self.graph.nodes else 1
        
        importance = (degree / max_degree) * 0.5 + (in_degree / max_degree) * 0.3 + (out_degree / max_degree) * 0.2
        
        return importance
