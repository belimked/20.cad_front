"""
ERD解析器

解析ERD文件，提取表结构、关系等信息
"""

import json
import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque


@dataclass
class TableField:
    """表字段信息"""
    name: str
    data_type: str
    is_primary_key: bool = False
    is_foreign_key: bool = False
    is_nullable: bool = True
    default_value: Optional[str] = None
    description: Optional[str] = None


@dataclass
class TableInfo:
    """表信息"""
    name: str
    fields: List[TableField]
    description: Optional[str] = None
    
    def get_primary_keys(self) -> List[str]:
        """获取主键字段"""
        return [field.name for field in self.fields if field.is_primary_key]
    
    def get_foreign_keys(self) -> List[str]:
        """获取外键字段"""
        return [field.name for field in self.fields if field.is_foreign_key]


@dataclass
class Relationship:
    """表关系信息"""
    from_table: str
    to_table: str
    from_field: str
    to_field: str
    relationship_type: str  # "one_to_one", "one_to_many", "many_to_many"
    description: Optional[str] = None


class ERDParser:
    """ERD解析器"""
    
    def __init__(self):
        self.tables: Dict[str, TableInfo] = {}
        self.relationships: List[Relationship] = []
    
    def parse_json(self, file_path: str) -> None:
        """解析JSON格式的ERD文件"""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 解析表信息
        if 'tables' in data:
            for table_data in data['tables']:
                self._parse_table(table_data)
        
        # 解析关系信息
        if 'relationships' in data:
            for rel_data in data['relationships']:
                self._parse_relationship(rel_data)
    
    def _parse_table(self, table_data: Dict) -> None:
        """解析单个表信息"""
        table_name = table_data['name']
        fields = []
        
        for field_data in table_data.get('fields', []):
            field = TableField(
                name=field_data['name'],
                data_type=field_data.get('type', 'VARCHAR'),
                is_primary_key=field_data.get('is_primary_key', False),
                is_foreign_key=field_data.get('is_foreign_key', False),
                is_nullable=field_data.get('is_nullable', True),
                default_value=field_data.get('default_value'),
                description=field_data.get('description')
            )
            fields.append(field)
        
        table = TableInfo(
            name=table_name,
            fields=fields,
            description=table_data.get('description')
        )
        
        self.tables[table_name] = table
    
    def _parse_relationship(self, rel_data: Dict) -> None:
        """解析关系信息"""
        relationship = Relationship(
            from_table=rel_data['from_table'],
            to_table=rel_data['to_table'],
            from_field=rel_data['from_field'],
            to_field=rel_data['to_field'],
            relationship_type=rel_data.get('type', 'one_to_many'),
            description=rel_data.get('description')
        )
        
        self.relationships.append(relationship)
    
    def get_table_names(self) -> List[str]:
        """获取所有表名"""
        return list(self.tables.keys())
    
    def get_table_info(self, table_name: str) -> Optional[TableInfo]:
        """获取指定表的信息"""
        return self.tables.get(table_name)
    
    def get_relationships_for_table(self, table_name: str) -> List[Relationship]:
        """获取指定表的所有关系"""
        return [
            rel for rel in self.relationships 
            if rel.from_table == table_name or rel.to_table == table_name
        ]
    
    def find_relationship_path(self, from_table: str, to_table: str, max_hops: int = 3) -> List[List[str]]:
        """查找两个表之间的关联路径"""
        if from_table == to_table:
            return [[from_table]]
        
        # 使用BFS查找最短路径
        queue = deque([(from_table, [from_table])])
        visited = {from_table}
        paths = []
        
        while queue and len(paths) < 10:  # 最多返回10条路径
            current_table, path = queue.popleft()
            
            if len(path) > max_hops:
                continue
            
            # 查找当前表的所有关联表
            for rel in self.relationships:
                next_table = None
                if rel.from_table == current_table:
                    next_table = rel.to_table
                elif rel.to_table == current_table:
                    next_table = rel.from_table
                
                if next_table and next_table not in visited:
                    new_path = path + [next_table]
                    
                    if next_table == to_table:
                        paths.append(new_path)
                    else:
                        queue.append((next_table, new_path))
                        visited.add(next_table)
        
        return paths
    
    def get_statistics(self) -> Dict:
        """获取ERD统计信息"""
        total_fields = sum(len(table.fields) for table in self.tables.values())
        total_relationships = len(self.relationships)
        
        return {
            "total_tables": len(self.tables),
            "total_fields": total_fields,
            "total_relationships": total_relationships,
            "avg_fields_per_table": total_fields / len(self.tables) if self.tables else 0
        }
