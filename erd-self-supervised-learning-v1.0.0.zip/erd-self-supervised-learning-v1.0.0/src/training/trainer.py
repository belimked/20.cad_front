"""
ERD模型训练器

基于Qwen2.5-3B的LoRA微调训练
"""

import os
import yaml
import torch
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    EarlyStoppingCallback,
    TrainerCallback,
    TrainerState,
    TrainerControl
)
from peft import LoraConfig, get_peft_model, TaskType
from datasets import Dataset

# 可选依赖：SwanLab
try:
    import swanlab
    SWANLAB_AVAILABLE = True
except ImportError:
    SWANLAB_AVAILABLE = False
    print("⚠️  SwanLab未安装，将跳过实验跟踪功能")

# 完全禁用wandb
import os
os.environ["WANDB_DISABLED"] = "true"
os.environ["WANDB_MODE"] = "disabled"
os.environ["WANDB_SILENT"] = "true"


class ProgressInfoCallback(TrainerCallback):
    """训练进度信息回调"""

    def __init__(self):
        self.start_time = None
        self.step_times = []

    def on_train_begin(self, args, state, control, **kwargs):
        """训练开始时记录开始时间"""
        self.start_time = time.time()
        print("🚀 训练开始，进度信息将定期更新...")

    def on_log(self, args, state, control, **kwargs):
        """每次日志记录时显示进度信息"""
        if self.start_time is None:
            return

        current_time = time.time()
        elapsed = current_time - self.start_time

        # 计算平均步时间
        if state.global_step > 0:
            avg_step_time = elapsed / state.global_step
            self.step_times.append(avg_step_time)

            # 保持最近100步的平均时间
            if len(self.step_times) > 100:
                self.step_times = self.step_times[-100:]

            # 使用最近步数的平均时间来预测
            recent_avg_time = sum(self.step_times[-20:]) / len(self.step_times[-20:]) if len(self.step_times) >= 20 else avg_step_time
        else:
            recent_avg_time = 0

        # 计算剩余时间
        remaining_steps = state.max_steps - state.global_step
        remaining_seconds = remaining_steps * recent_avg_time
        remaining_hours = int(remaining_seconds // 3600)
        remaining_minutes = int((remaining_seconds % 3600) // 60)

        # 预计完成时间
        completion_time = datetime.now() + timedelta(seconds=remaining_seconds)

        # 获取当前损失
        current_loss = "N/A"
        if state.log_history:
            for log_entry in reversed(state.log_history):
                if 'loss' in log_entry:
                    current_loss = f"{log_entry['loss']:.6f}"
                    break

        # 格式化进度信息
        progress_info = f"""
🚀 训练进度更新:
📊 当前步数: {state.global_step}/{state.max_steps} ({state.global_step/state.max_steps*100:.2f}%)
⏱️  已用时间: {elapsed/3600:.2f}小时
⚡ 平均步时间: {recent_avg_time:.2f}秒/步
⏳ 预估剩余: {remaining_hours}小时{remaining_minutes}分钟
🎯 预计完成: {completion_time.strftime('%Y-%m-%d %H:%M:%S')}
📉 当前损失: {current_loss}
{'='*50}"""

        print(progress_info)

    def on_train_end(self, args, state, control, **kwargs):
        """训练结束时显示总结信息"""
        if self.start_time is None:
            return

        total_time = time.time() - self.start_time
        avg_step_time = total_time / state.global_step if state.global_step > 0 else 0

        summary_info = f"""
🎉 训练完成总结:
⏱️  总训练时间: {total_time/3600:.2f}小时
📊 总训练步数: {state.global_step}
⚡ 平均步时间: {avg_step_time:.2f}秒/步
🏁 完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*50}"""

        print(summary_info)


class ERDTrainer:
    """ERD模型训练器"""
    
    def __init__(self, config_path: str):
        """初始化训练器"""
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        
        self.model = None
        self.tokenizer = None
        self.trainer = None
        
        # 初始化SwanLab（如果可用）
        self.swanlab_run = None
        if SWANLAB_AVAILABLE:
            try:
                # 生成带时间戳的项目名称
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                project_name = f"erd-self-supervised-{timestamp}"
                experiment_name = f"erd_training_{self.config['output']['run_name']}_{timestamp}"

                self.swanlab_run = swanlab.init(
                    project=project_name,
                    experiment_name=experiment_name,
                    config=self.config
                )
                print(f"✅ SwanLab实验跟踪已启用")
                print(f"📊 项目名称: {project_name}")
                print(f"🧪 实验名称: {experiment_name}")
            except Exception as e:
                print(f"⚠️  SwanLab初始化失败: {e}")
                self.swanlab_run = None
        else:
            print("ℹ️  使用本地日志记录（SwanLab未安装）")
    
    def load_model_and_tokenizer(self):
        """加载模型和分词器"""
        model_name = self.config['model']['name']
        model_dir = None  # 初始化变量

        # 定义缓存目录
        cache_base_dir = "/root/lanyun-tmp/modelscope_cache"
        local_cache_dir = "./cache/modelscope"

        # 检查是否在服务器环境
        is_server = os.path.exists("/root/lanyun-tmp")
        cache_dir = cache_base_dir if is_server else local_cache_dir

        # 检查模型是否已缓存
        cached_model_path = None
        if model_name == "Qwen/Qwen2.5-3B-Instruct":
            # 检查服务器缓存路径
            server_cached_path = "/root/lanyun-tmp/modelscope_cache/models--Qwen--Qwen2.5-3B-Instruct"
            if os.path.exists(server_cached_path) and os.path.isdir(server_cached_path):
                # 检查是否包含必要的模型文件
                required_files = ["config.json", "pytorch_model.bin", "tokenizer.json"]
                if all(os.path.exists(os.path.join(server_cached_path, f)) for f in required_files):
                    cached_model_path = server_cached_path
                    print(f"✅ 发现已缓存的模型: {cached_model_path}")

        # 如果找到缓存模型，直接使用
        if cached_model_path:
            model_dir = cached_model_path
            print(f"✅ 使用缓存模型: {model_dir}")
        else:
            # 尝试使用 ModelScope 下载模型
            try:
                from modelscope import snapshot_download
                # 将 HuggingFace 模型名转换为 ModelScope 格式
                modelscope_name = model_name
                if model_name == "Qwen/Qwen2.5-3B-Instruct":
                    modelscope_name = "qwen/Qwen2.5-3B-Instruct"

                # 使用 ModelScope 下载到指定缓存目录
                print(f"🔄 下载模型到缓存: {cache_dir}")
                model_dir = snapshot_download(modelscope_name, cache_dir=cache_dir)
                print(f"✅ 使用 ModelScope 下载模型: {modelscope_name}")
                print(f"📁 模型缓存路径: {model_dir}")

                # 加载分词器
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_dir,
                    trust_remote_code=True,
                    padding_side="right"
                )
            except ImportError:
                print("⚠️  ModelScope 未安装，使用 HuggingFace Hub")
                # 加载分词器
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_name,
                    trust_remote_code=True,
                    padding_side="right"
                )
            except Exception as e:
                print(f"⚠️  ModelScope 下载失败: {e}")
                print("回退到 HuggingFace Hub")
                # 加载分词器
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_name,
                    trust_remote_code=True,
                    padding_side="right"
                )

        # 如果使用缓存模型但没有分词器，单独加载分词器
        if cached_model_path and not hasattr(self, 'tokenizer'):
            print("🔄 单独加载分词器...")
            self.tokenizer = AutoTokenizer.from_pretrained(
                cached_model_path,
                trust_remote_code=True,
                padding_side="right"
            )
        
        # 设置pad_token
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # 加载模型
        dtype = torch.bfloat16 if self.config['hardware']['mixed_precision'] == 'bf16' else torch.float16

        # 检查Flash Attention 2是否可用
        try:
            import flash_attn
            attn_impl = "flash_attention_2" if torch.cuda.is_available() else None
        except ImportError:
            attn_impl = None

        # 加载模型（使用相同的路径或名称）
        try:
            if model_dir is not None:
                # 如果使用了 ModelScope，使用本地路径
                print(f"✅ 从 ModelScope 缓存加载模型: {model_dir}")
                self.model = AutoModelForCausalLM.from_pretrained(
                    model_dir,
                    torch_dtype=dtype,
                    device_map="auto",
                    trust_remote_code=True,
                    attn_implementation=attn_impl
                )
            else:
                # 否则使用原始模型名
                print(f"✅ 从 HuggingFace Hub 加载模型: {model_name}")
                self.model = AutoModelForCausalLM.from_pretrained(
                    model_name,
                    torch_dtype=dtype,
                    device_map="auto",
                    trust_remote_code=True,
                    attn_implementation=attn_impl
                )
        except Exception as e:
            print(f"⚠️  模型加载失败: {e}")
            # 回退到原始方法
            print("🔄 尝试回退到原始模型名")
            self.model = AutoModelForCausalLM.from_pretrained(
                self.config['model']['name'],
                torch_dtype=dtype,
                device_map="auto",
                trust_remote_code=True,
                attn_implementation=attn_impl
            )
        
        # 配置LoRA
        lora_config = LoraConfig(
            r=self.config['lora']['r'],
            lora_alpha=self.config['lora']['lora_alpha'],
            target_modules=self.config['lora']['target_modules'],
            lora_dropout=self.config['lora']['lora_dropout'],
            bias=self.config['lora']['bias'],
            task_type=TaskType.CAUSAL_LM
        )
        
        # 应用LoRA
        self.model = get_peft_model(self.model, lora_config)
        
        # 启用梯度检查点
        if self.config['hardware']['gradient_checkpointing']:
            self.model.gradient_checkpointing_enable()
        
        print(f"模型加载完成: {model_name}")
        print(f"可训练参数: {self.model.get_nb_trainable_parameters()}")
    
    def prepare_dataset(self, training_data: List[Dict]) -> Dataset:
        """准备训练数据集"""
        
        def format_sample(sample):
            """格式化单个样本"""
            instruction = sample.get('instruction', '')
            input_text = sample.get('input', '')
            output_text = sample.get('output', '')
            
            # 构建对话格式
            prompt = f"<|im_start|>system\n{instruction}<|im_end|>\n<|im_start|>user\n{input_text}<|im_end|>\n<|im_start|>assistant\n{output_text}<|im_end|>"
            
            return prompt
        
        # 格式化所有样本
        formatted_texts = [format_sample(sample) for sample in training_data]
        
        # 分词
        def tokenize_function(examples):
            tokenized = self.tokenizer(
                examples['text'],
                truncation=True,
                padding=False,
                max_length=self.config['model']['max_length'],
                return_tensors=None
            )
            
            # 设置labels
            tokenized['labels'] = tokenized['input_ids'].copy()
            
            return tokenized
        
        # 创建数据集
        dataset = Dataset.from_dict({'text': formatted_texts})
        tokenized_dataset = dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=dataset.column_names
        )
        
        return tokenized_dataset
    
    def train(self, training_data: List[Dict], validation_data: Optional[List[Dict]] = None):
        """开始训练"""
        
        # 准备数据集
        train_dataset = self.prepare_dataset(training_data)
        eval_dataset = None
        if validation_data:
            eval_dataset = self.prepare_dataset(validation_data)
        
        # 数据整理器
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False,
            pad_to_multiple_of=8
        )
        
        # 训练参数
        training_args = TrainingArguments(
            output_dir=self.config['output']['output_dir'],
            run_name=self.config['output']['run_name'],
            
            # 训练设置
            num_train_epochs=self.config['training'].get('num_train_epochs', 3),
            max_steps=self.config['training']['max_steps'],
            per_device_train_batch_size=self.config['training']['batch_size'],
            gradient_accumulation_steps=self.config['training']['gradient_accumulation_steps'],
            
            # 优化器设置
            learning_rate=float(self.config['training']['learning_rate']),
            warmup_steps=self.config['training']['warmup_steps'],
            lr_scheduler_type="cosine",
            
            # 保存和评估
            save_steps=self.config['training']['save_steps'],
            eval_steps=self.config['training']['eval_steps'],
            logging_steps=self.config['training']['logging_steps'],
            save_total_limit=self.config['output']['save_total_limit'],
            load_best_model_at_end=self.config['output']['load_best_model_at_end'],
            
            # 硬件设置
            bf16=self.config['hardware']['mixed_precision'] == 'bf16',
            fp16=self.config['hardware']['mixed_precision'] == 'fp16',
            dataloader_num_workers=self.config['hardware']['dataloader_num_workers'],
            
            # 其他设置
            remove_unused_columns=False,
            report_to=["swanlab"] if SWANLAB_AVAILABLE and self.swanlab_run else [],  # 使用SwanLab或禁用外部日志
            
            # 评估设置
            eval_strategy="steps" if eval_dataset else "no",  # 修复参数名
            metric_for_best_model=self.config['training'].get('metric_for_best_model', "eval_loss") if eval_dataset else None,
            greater_is_better=self.config['training'].get('greater_is_better', False) if eval_dataset else None,
        )
        
        # 准备回调函数
        callbacks = []

        # 添加进度信息回调
        progress_callback = ProgressInfoCallback()
        callbacks.append(progress_callback)
        print("✅ 训练进度信息回调已启用")

        # 添加早停回调（如果配置了）
        if eval_dataset and self.config['training'].get('early_stopping_patience'):
            early_stopping_callback = EarlyStoppingCallback(
                early_stopping_patience=self.config['training']['early_stopping_patience'],
                early_stopping_threshold=self.config['training'].get('early_stopping_threshold', 0.0)
            )
            callbacks.append(early_stopping_callback)
            print(f"✅ 早停机制已启用: patience={self.config['training']['early_stopping_patience']}, threshold={self.config['training'].get('early_stopping_threshold', 0.0)}")

        # 创建训练器
        self.trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            data_collator=data_collator,
            tokenizer=self.tokenizer,
            callbacks=callbacks,
        )
        
        # 开始训练
        print("开始训练...")
        self.trainer.train()
        
        # 保存最终模型
        final_model_path = os.path.join(self.config['output']['output_dir'], "final_model")
        self.trainer.save_model(final_model_path)
        self.tokenizer.save_pretrained(final_model_path)
        
        print(f"训练完成，模型保存至: {final_model_path}")

        # 注意：不在这里结束SwanLab实验，等到所有评估完成后再结束
    
    def evaluate(self, test_data: List[Dict]) -> Dict:
        """评估模型"""
        if not self.trainer:
            raise ValueError("模型尚未训练，请先调用train()方法")

        test_dataset = self.prepare_dataset(test_data)

        # 临时禁用SwanLab回调以避免错误
        original_callbacks = self.trainer.callback_handler.callbacks.copy()
        swanlab_callbacks = [cb for cb in original_callbacks if 'swanlab' in str(type(cb)).lower()]

        # 移除SwanLab回调
        for cb in swanlab_callbacks:
            self.trainer.callback_handler.callbacks.remove(cb)

        try:
            # 运行评估
            eval_results = self.trainer.evaluate(test_dataset)

            print("评估结果:")
            for key, value in eval_results.items():
                print(f"  {key}: {value}")

        finally:
            # 恢复原始回调
            self.trainer.callback_handler.callbacks = original_callbacks

            # 现在结束SwanLab实验
            if self.swanlab_run:
                self.swanlab_run.finish()
                print("✅ SwanLab实验已结束")

        return eval_results

    def cleanup(self):
        """清理资源，结束SwanLab实验"""
        if self.swanlab_run:
            try:
                self.swanlab_run.finish()
                print("✅ SwanLab实验已结束")
            except Exception as e:
                print(f"⚠️  SwanLab实验结束时出现警告: {e}")
            finally:
                self.swanlab_run = None

    def save_model(self, save_path: str):
        """保存模型"""
        if not self.model:
            raise ValueError("模型尚未加载")
        
        os.makedirs(save_path, exist_ok=True)
        
        # 保存LoRA权重
        self.model.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        
        # 保存配置
        config_path = os.path.join(save_path, "training_config.yaml")
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.config, f, ensure_ascii=False)
        
        print(f"模型已保存至: {save_path}")
    
    def load_model(self, model_path: str):
        """加载已训练的模型"""
        from peft import PeftModel
        
        # 加载基础模型
        base_model_name = self.config['model']['name']

        # 检查Flash Attention 2是否可用
        try:
            import flash_attn
            attn_impl = "flash_attention_2" if torch.cuda.is_available() else None
        except ImportError:
            attn_impl = None

        base_model = AutoModelForCausalLM.from_pretrained(
            base_model_name,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
            attn_implementation=attn_impl
        )
        
        # 加载LoRA权重
        self.model = PeftModel.from_pretrained(base_model, model_path)
        
        # 加载分词器
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True
        )
        
        print(f"模型已从 {model_path} 加载")
