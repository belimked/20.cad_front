"""
SQL转ERD转换器

将SQL DDL语句转换为ERD JSON格式
"""

import re
import json
from typing import Dict, List, Tuple, Optional


class SQLToERDConverter:
    """SQL转ERD转换器"""
    
    def __init__(self):
        self.tables = {}
        self.relationships = []
    
    def parse_sql_file(self, file_path: str) -> Dict:
        """解析SQL文件"""
        with open(file_path, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        # 提取所有CREATE TABLE语句
        table_statements = self._extract_create_table_statements(sql_content)
        
        # 解析每个表
        for table_sql in table_statements:
            self._parse_table_statement(table_sql)
        
        # 分析外键关系
        self._analyze_foreign_keys()
        
        return self._generate_erd_json()
    
    def _extract_create_table_statements(self, sql_content: str) -> List[str]:
        """提取CREATE TABLE语句"""
        # 匹配CREATE TABLE语句（包括多行）
        pattern = r'create\s+table\s+(\w+)\s*\((.*?)\)\s*(?:comment\s*[\'"].*?[\'"])?(?:\s*row_format\s*=\s*\w+)?;'
        matches = re.findall(pattern, sql_content, re.IGNORECASE | re.DOTALL)
        
        table_statements = []
        for table_name, table_body in matches:
            table_statements.append(f"CREATE TABLE {table_name} ({table_body})")
        
        return table_statements
    
    def _parse_table_statement(self, table_sql: str) -> None:
        """解析单个表语句"""
        # 提取表名
        table_name_match = re.search(r'CREATE\s+TABLE\s+(\w+)', table_sql, re.IGNORECASE)
        if not table_name_match:
            return
        
        table_name = table_name_match.group(1)
        
        # 提取表体
        table_body_match = re.search(r'\((.*)\)', table_sql, re.DOTALL)
        if not table_body_match:
            return
        
        table_body = table_body_match.group(1)
        
        # 解析字段
        fields = self._parse_fields(table_body)
        
        # 提取表注释
        comment_match = re.search(r'comment\s*[\'"]([^\'\"]*)[\'"]', table_sql, re.IGNORECASE)
        table_comment = comment_match.group(1) if comment_match else None
        
        self.tables[table_name] = {
            'name': table_name,
            'fields': fields,
            'description': table_comment
        }
    
    def _parse_fields(self, table_body: str) -> List[Dict]:
        """解析表字段"""
        fields = []
        
        # 分割字段定义（处理多行和逗号分隔）
        lines = table_body.split('\n')
        current_field = ""
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # 跳过约束定义
            if line.lower().startswith(('constraint', 'primary key', 'key ', 'index ', 'unique')):
                continue
            
            # 处理字段定义
            if line.endswith(','):
                current_field += line[:-1]
                field_info = self._parse_single_field(current_field.strip())
                if field_info:
                    fields.append(field_info)
                current_field = ""
            elif ',' in line:
                parts = line.split(',')
                current_field += parts[0]
                field_info = self._parse_single_field(current_field.strip())
                if field_info:
                    fields.append(field_info)
                current_field = ""
                # 处理剩余部分
                for part in parts[1:]:
                    if part.strip():
                        field_info = self._parse_single_field(part.strip())
                        if field_info:
                            fields.append(field_info)
            else:
                current_field += line
                if current_field.strip():
                    field_info = self._parse_single_field(current_field.strip())
                    if field_info:
                        fields.append(field_info)
                    current_field = ""
        
        return fields
    
    def _parse_single_field(self, field_def: str) -> Optional[Dict]:
        """解析单个字段定义"""
        if not field_def or field_def.lower().startswith(('constraint', 'primary key', 'key ', 'index')):
            return None
        
        # 基本字段模式：字段名 数据类型 [约束] [注释]
        pattern = r'(\w+)\s+([^\s]+)(?:\s+(.*))?'
        match = re.match(pattern, field_def)
        
        if not match:
            return None
        
        field_name = match.group(1)
        data_type = match.group(2)
        constraints = match.group(3) or ""
        
        # 解析约束
        is_primary_key = 'primary key' in constraints.lower() or 'auto_increment' in constraints.lower()
        is_foreign_key = 'foreign key' in constraints.lower() or self._is_likely_foreign_key(field_name)
        is_nullable = 'not null' not in constraints.lower()
        
        # 提取默认值
        default_match = re.search(r'default\s+([^\s]+)', constraints, re.IGNORECASE)
        default_value = default_match.group(1) if default_match else None
        
        # 提取注释
        comment_match = re.search(r'comment\s*[\'"]([^\'\"]*)[\'"]', constraints, re.IGNORECASE)
        description = comment_match.group(1) if comment_match else None
        
        return {
            'name': field_name,
            'type': data_type,
            'is_primary_key': is_primary_key,
            'is_foreign_key': is_foreign_key,
            'is_nullable': is_nullable,
            'default_value': default_value,
            'description': description
        }
    
    def _is_likely_foreign_key(self, field_name: str) -> bool:
        """判断字段是否可能是外键"""
        # 常见的外键命名模式
        fk_patterns = [
            r'.*_id$',  # 以_id结尾
            r'.*id$',   # 以id结尾
            r'pro_id',  # 项目ID
            r'pv_id',   # 材料类型ID
            r'.*_no$',  # 以_no结尾
        ]
        
        for pattern in fk_patterns:
            if re.match(pattern, field_name, re.IGNORECASE):
                return True
        
        return False
    
    def _analyze_foreign_keys(self) -> None:
        """分析外键关系"""
        # 基于字段名推断关系
        for table_name, table_info in self.tables.items():
            for field in table_info['fields']:
                if field['is_foreign_key'] and not field['is_primary_key']:
                    # 尝试找到对应的主表
                    referenced_table = self._find_referenced_table(field['name'])
                    if referenced_table:
                        relationship = {
                            'from_table': table_name,
                            'to_table': referenced_table,
                            'from_field': field['name'],
                            'to_field': self._find_primary_key(referenced_table),
                            'type': 'many_to_one',
                            'description': f"{table_name}通过{field['name']}关联{referenced_table}"
                        }
                        self.relationships.append(relationship)
    
    def _find_referenced_table(self, field_name: str) -> Optional[str]:
        """根据字段名查找引用的表"""
        # 移除常见后缀
        base_name = re.sub(r'(_id|_no|id)$', '', field_name, flags=re.IGNORECASE)
        
        # 查找匹配的表名
        for table_name in self.tables.keys():
            if base_name.lower() in table_name.lower() or table_name.lower() in base_name.lower():
                return table_name
        
        # 特殊映射
        special_mappings = {
            'pro_id': 'mstb_project',
            'pv_id': 'mstb_material_type',
            'vendor_id': 'mstb_vendor',
            'con_id': 'mstb_contract'
        }
        
        return special_mappings.get(field_name.lower())
    
    def _find_primary_key(self, table_name: str) -> str:
        """查找表的主键字段"""
        if table_name not in self.tables:
            return 'id'
        
        for field in self.tables[table_name]['fields']:
            if field['is_primary_key']:
                return field['name']
        
        return 'id'
    
    def _generate_erd_json(self) -> Dict:
        """生成ERD JSON"""
        return {
            'database_name': '成本管理系统',
            'description': '包含项目管理、材料采购、成本核算等功能的企业级成本管理系统',
            'tables': list(self.tables.values()),
            'relationships': self.relationships
        }
