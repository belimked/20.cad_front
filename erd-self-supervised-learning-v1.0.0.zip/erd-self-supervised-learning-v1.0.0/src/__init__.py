"""
ERD自监督学习项目

基于ERD（实体关系图）的自监督学习系统
"""

__version__ = "1.0.0"
__author__ = "Claude 4.0 sonnet"
__description__ = "ERD Self-Supervised Learning System"
